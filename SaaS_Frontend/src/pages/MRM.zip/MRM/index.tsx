import React, { useEffect, useState } from "react";
import axios from "../../apis/axios.global";
//mui
import {
  Box,
  Tooltip,
  Grid,
  FormControl,
  MenuItem,
  TextField,
  Menu,
  Paper,
  InputAdornment,
  IconButton,
  TablePagination,
  TableRow,
  InputLabel,
  Select,
} from "@material-ui/core";
import {
  Table,
  Divider,
  Switch,
  Tag,
  Checkbox,
  Button,
  Pagination,
  Dropdown,
  Space,
} from "antd";
import { ReactComponent as OrgSettingsIcon } from "assets/moduleIcons/module-setting.svg";
import PermContactCalendarOutlinedIcon from "@material-ui/icons/PermContactCalendarOutlined";
import AddIcon from "@material-ui/icons/Add";
import useStyles from "./styles";
import "./tableStyles.css";
import getAppUrl from "../../utils/getAppUrl";
import MrmModal from "./Modal/MrmModal";
import { CalendarOutlined } from "@ant-design/icons";
import ScheduleDrawer from "./Drawer/ScheduleDrawer";
import { useLocation } from "react-router-dom";
import moment from "moment";
import { Autocomplete } from "@material-ui/lab";
import { useSnackbar } from "notistack";
import MoreVertIcon from "@material-ui/icons/MoreVert";
import { ColumnsType } from "antd/es/table";
import ActionPoint from "./Drawer/ActionPoint";
import { useNavigate } from "react-router-dom";
import ModuleHeader from "components/Navigation/ModuleHeader";
import { Tabs, Tab } from "@material-ui/core";
import { ReactComponent as AllDocIcon } from "../../assets/documentControl/All-Doc.svg";
import TableChartIcon from "@material-ui/icons/TableChart";
import MailIcon from "@material-ui/icons/Mail";
import checkRoles from "../../utils/checkRoles";
import SearchIcon from "../../assets/SearchIcon.svg";
import { ReactComponent as MRMLogo } from "../../assets/MRM/mrm.svg";
import { ReactComponent as CreateIcon } from "../../assets/MRM/addIcon.svg";
import { ReactComponent as ActionPointIcon } from "../../assets/MRM/actionPoint.svg";
import { ReactComponent as CalendarIcon } from "../../assets/MRM/calendar.svg";
import { ReactComponent as KeyAgendaIcon } from "../../assets/MRM/keyAgenda.svg";
import { ReactComponent as SendMinuteIcon } from "../../assets/MRM/sendMinute.svg";
import { ReactComponent as SendInviteIcon } from "../../assets/MRM/sendInvite.svg";
import { ReactComponent as MrmIcon } from "../../assets/MRM/mrmIcon.svg";
import { ReactComponent as SelectedTabArrow } from "assets/icons/SelectedTabArrow.svg";
import AddMrmActionPoint from "./Drawer/AddMrmActionPoint";
import EditMrmActionPoint from "./Drawer/EditMrmActionPoint";
import YearComponent from "components/Yearcomponent";
import getYearFormat from "utils/getYearFormat";
import { currentAuditYear } from "recoil/atom";
import CloseIcon from "@material-ui/icons/Close";
import MRMKeyAgenda from "./MRMKeyAgenda";
import CalendarMRM from "./CalendarMRM";
import CalendarModal from "./Modal/CalendarModal";
import { API_LINK } from "config";
import MailOutlineIcon from "@material-ui/icons/MailOutline";
import PictureAsPdfOutlinedIcon from "@material-ui/icons/PictureAsPdfOutlined";
import { ReactComponent as CustomEditIcon } from "assets/documentControl/Edit.svg";
import { ReactComponent as CustomDeleteICon } from "assets/documentControl/Delete.svg";
import type { PaginationProps, DropdownProps, MenuProps } from "antd";
import {
  deleteMeeting,
  getAllMeeting,
  getMeetingById,
  getMyActionPoints,
  getMyMeeting,
} from "apis/mrmmeetingsApi";
import DeleteIcon from "@material-ui/icons/Delete";
import MrmAddMeetings from "./Drawer/MeetingCreating";
import MrmEditingMeetings from "./Drawer/MeetingEditing";
import { Delete, Edit, PermContactCalendar } from "@material-ui/icons";
import AddCircleOutlineIcon from "@material-ui/icons/AddCircleOutline";
import MultiUserDisplay from "components/MultiUserDisplay";
import Popconfirm from "antd/lib/popconfirm";
import {
  deleteActionPoint,
  getActionPointMeetingById,
  getAllActionPointsData,
} from "apis/mrmActionpoint";
import { useRecoilState } from "recoil";
import { documentTypeFormData } from "recoil/atom";
import { getOrganizationData } from "apis/orgApi";
import HindalcoLogoSvg from "assets/logo/HindalcoLogoSvg.svg";
import printJS from "print-js";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import { Console } from "console";

const allOption = { id: "All", locationName: "All" };

export interface IKeyAgenda {
  _id: string;
  meetingName: string;
  meetingdate: any;
  organizer: any;
  attendees: any;
  decision: any;
  agenda: any;
}
let addMonthyColumns: any = [];

const MRM = () => {
  const classes = useStyles();
  const [dataSource, setDataSource] = useState<any[]>([]);
  const [openScheduleDrawer, setOpenScheduleDrawer] = useState<boolean>(false);
  const realmName = getAppUrl();
  const navigate = useNavigate();
  const [mode, setMode] = useState<any>("Create");
  const [openAction, setOpenAction] = useState(false);
  const [openMeeting, setOpenMeeting] = useState(false);
  const [locationOptions, setLocationOptions] = useState<any[]>([]);
  const [locationNameUnit, setLocationNameUnit] = useState<any>("");
  const [expandDataValues, setExpandDataValues] = useState<any>({});
  const [mrmEditOptions, setMrmEditOptions] = useState<any>("");
  const [actionPointDataSource, setActionPointDataSource] = useState<any[]>([]);
  const [statusMode, setStatusMode] = useState<any>();
  const [openModal, setOpenModal] = useState({
    open: false,
    data: {},
  });
  const [meetingDataById, setMeetingDataById] = useState<any>();
  const [actionPointsPdfData, setActionPointsPdfData] = useState<any>();
  const [openActionPointDrawer, setOpenActionPointDrawer] = useState({
    open: false,
    data: {},
  });

  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const [unitId, setUnitId] = useState<string>("");
  const [actionUnitId, setActionUnitId] = useState<string>("");
  const [meetingUnitId, setMeetingUnitId] = useState<string>("");

  const [selectedData, setSelectedData] = useState<any>({});
  const [currentYear, setCurrentYear] = useState<any>();
  const [dataSourceFilter, setDataSourceFilter] = useState<any[]>([]);
  const [ownerSourceFilter, setOwnerSourceFilter] = useState<any[]>([]);
  const [scheduleData, setScheduleData] = useState<any[]>([]);
  const [openActionPointEditDrawer, setOpenActionPointEditDrawer] = useState({
    open: false,
    data: {},
    checkOwner: false,
  });
  const [filter, setFilter] = useState<string>("");

  const [value, setValue] = useState(5);

  const [searchValue, setSearchValue] = useState<string>("");
  const [searchMeetingValue, setMeetingSearchValue] = useState<string>("");
  const [searchActionPointValue, setActionPointSearchValue] =
    useState<string>("");
  const [myActionPoint, setMyactionPoint] = useState(false);
  const [addKeyAgenda, setAddKeyAgenda] = useState<boolean>(false);
  const [viewCalendar, setViewCalendar] = useState<boolean>(false);
  const [calendarData, setCalendarData] = useState<any[]>([]);
  const [loadMeeting, setLoadMeeting] = useState(false);
  const [loadActionPoint, setLoadActionPoint] = useState(false);
  const [calendarModalInfo, setCalendarModalInfo] = useState<any>({
    open: false,
    data: {},
    mode: "create",
    calendarFor: "MRM",
  });
  const [page, setPage] = useState<any>(0);
  const [pageLimit, setPageLimit] = useState<any>(10);
  const [countMeeting, setCountMeeting] = useState<number>(0);
  const [meetingsDataApi, setMeetingsDataApi] = useState<any[]>([]);
  const [meetingObjectData, setMeetingObjectData] = useState<any[]>([]);
  const [checkAccess, setCheckAccess] = useState(false);
  const userDetail = JSON.parse(sessionStorage.getItem("userDetails") || "{}");
  const locationState = useLocation();
  const orgId = sessionStorage.getItem("orgId");
  const { enqueueSnackbar } = useSnackbar();
  const [mrmActionPointAdd, setMrmActionPointAdd] = useState(false);
  const [mrmActionPointEdit, setMrmActionPointEdit] = useState(false);
  const [submitButtonStatus, setSubmitButtonStatus] = useState(false);
  const [mrmActionId, setMrmActionId] = useState<any>();
  const [owner, setOwner] = useState(false);

  const handlerActionAddOpen = (data: any) => {
    setMrmActionId(data);
    setMrmActionPointAdd(true);
  };

  const handlerActionAddClose = () => {
    setMrmActionPointAdd(false);
  };

  const [actionRowData, setActionRowData] = useState<any>();

  const ROWS_PER_PAGE = 10;

  const handlerActionEditOpen = (data: any, Read: any) => {
    // console.log("data", data);
    getMeetingById(data?.allData?.meetingId).then((response: any) => {
      if (data?.allData?.meetingId === response.data._id)
        setDataSourceFilter(response.data);
      setActionRowData(data);
      setMrmActionPointEdit(true);

      if (Read === "ReadOnly") {
        setReadMode(true);
      } else {
        setReadMode(false);
      }
    });
  };

  const handlerActionEditClose = () => {
    setMrmActionPointEdit(false);
  };

  useEffect(() => {
    getMRMValues(unitId, "", currentYear, pageMrm, pageLimitMrm);
    const meetingObjectData =
      meetingsDataApi &&
      meetingsDataApi?.map((item: any, index) => {
        let Data = {
          id: item._id,
          meetingName: item.meetingName,
          createdBy: item.createdBy,
          agenda: item.agenda?.map((ele: any) => ele.agenda),
        };
        return Data;
      });
    setMeetingObjectData(meetingObjectData);
  }, [meetingUnitId]);
  useEffect(() => {
    // getyear();
    getMRMValues(unitId, "", currentYear, pageMrm, pageLimitMrm);
    getDataTableMeetings();
  }, []);

  useEffect(() => {
    getDataTableMeetings();
  }, [meetingUnitId, openMeeting]);

  useEffect(() => {
    if (!!currentYear) {
      getLocationOptions();
      getUserInfo();
      getMRMValues(unitId, "", currentYear, pageMrm, pageLimitMrm);
      getDataTableMeetings();
      //checkowner();
    }
  }, [currentYear]);

  useEffect(() => {
    getDataTableMeetingsAll();
  }, []);

  useEffect(() => {
    if (loadMeeting === true) {
      getDataTableMeetingsAll();
      getDataTableMeetings();
    }
  }, [loadMeeting]);

  useEffect(() => {
    getDataTableMeetingsAll();
    getDataTableMeetings();
  }, [pageLimit, page]);

  const getDataTableMeetingsAll = () => {
    const payload: any = {
      unitId: meetingUnitId,
      orgId: orgId,
      page: page,
      limit: pageLimit,
      currentYear: currentYear,
    };
    getMyMeeting(payload).then((response: any) => {
      setMeetingsDataApi(response?.data);
      setLoadMeeting(false);
    });
  };

  const getDataTableMeetings = () => {
    const payload: any = {
      unitId: meetingUnitId,
      orgId: orgId,
      page: page,
      limit: pageLimit,
      currentYear: currentYear,
    };
    if (!openMeeting) {
      getAllMeeting(payload).then((response: any) => {
        setMeetingsDataApi(response?.data);
        setCountMeeting(response?.data?.length);
        setLoadMeeting(false);
      });
    } else {
      getMyMeeting(payload).then((response: any) => {
        setMeetingsDataApi(response?.data);
        setCountMeeting(response?.data?.length);
        setLoadMeeting(false);
      });
    }
  };

  const [pageAction, setPageAction] = useState<any>(0);
  const [pageLimitAction, setPageLimitAction] = useState<any>(10);
  const [countAction, setCountAction] = useState<number>(0);
  const [pagePlan, setPagePlan] = useState<any>(1);
  const [rowsPerPagePlan, setRowsPerPagePlan] = useState(10);
  const [countPlan, setCountPlan] = useState<number>(0);

  const handlePaginationAction = (
    page: any,
    pageSize: any = pageLimitAction
  ) => {
    setPageAction(page);
    setPageLimitAction(pageSize);
    getActionPoints();
  };

  useEffect(() => {
    getActionPoints();
  }, [openAction, actionUnitId]);

  useEffect(() => {
    if (!!currentYear) getActionPoints();
  }, [pageAction, pageLimitAction]);

  useEffect(() => {
    if (loadActionPoint === true) {
      getActionPoints();
      getAllActionPointData();
    }
  }, [loadActionPoint]);

  const getAllActionPointData = () => {
    const payload = {
      orgId: orgId,
      page: pageAction,
      limit: pageLimitAction,
      unitId: actionUnitId,
      currentYear: currentYear,
    };
    getAllActionPointsData(payload)
      .then((response: any) => {
        if (response.status == 200) {
          setActionPointDataSource(response?.data);
          setCountAction(response?.data?.length);
          setLoadActionPoint(false);
        } else {
          enqueueSnackbar("error fetching Action Points");
        }
      })
      .catch((error: any) => {
        enqueueSnackbar("error fetching Action Points");
      });
  };
  const getActionPoints = () => {
    const payload = {
      orgId: orgId,
      page: pageAction,
      limit: pageLimitAction,
      unitId: actionUnitId,
      currentYear: currentYear,
    };
    if (!openAction) {
      getAllActionPointsData(payload)
        .then((response: any) => {
          if (response.status == 200) {
            setActionPointDataSource(response?.data);
            setCountAction(response?.data?.length);
            setLoadActionPoint(false);
          } else {
            enqueueSnackbar("error fetching Action Points");
          }
        })
        .catch((error: any) => {
          enqueueSnackbar("error fetching Action Points");
        });
    } else {
      getMyActionPoints(payload)
        .then((response: any) => {
          if (response.status == 200) {
            setActionPointDataSource(response.data);
            setCountAction(response?.data?.length);
            setLoadActionPoint(false);
          } else {
            enqueueSnackbar("error fetching Action Points");
          }
        })
        .catch((error: any) => {
          enqueueSnackbar("error fetching Action Points");
        });
    }
  };

  const [drawerOpen, setDrawerOpen] = useState(false);
  const [valueById, setValueById] = useState<any>();

  const handleDrawerOpen = (data: any, index: any, Read: any) => {
    setValueById(data?.value?._id);
    setDrawerOpen(true);
    setAnchorEl(null);
    const filterById = data?.value?._id;
    const filteredObject = calendarData?.find(
      (item) => item?.id === filterById
    );
    setDataSourceFilter(filteredObject);
    setOwnerSourceFilter(data);
    if (Read === "ReadOnly") {
      setReadMode(true);
    } else {
      setReadMode(false);
    }
  };

  const handleDrawerClose = () => {
    setDrawerOpen(false);
  };

  const [editDrawerOpen, setEditDrawerOpen] = useState(false);
  const [editDataMeeting, setEditDataMeeting] = useState<any[]>([]);
  const [readMode, setReadMode] = useState(false);

  const handleEditDrawerOpen = (data: any, Read: any) => {
    setEditDataMeeting(data);

    getMeetingById(data?._id).then((response: any) => {
      setDataSourceFilter(response?.data);

      if (response?.data) {
        if (Read === "ReadOnly") {
          setReadMode(true);
        } else {
          setReadMode(false);
        }
        setEditDrawerOpen(true);
        setAnchorEl(null);
      }
    });
  };

  const handleEditDrawerClose = () => {
    setEditDrawerOpen(false);
  };

  useEffect(() => {
    if (locationState?.state && locationState?.state?.action === "Create") {
      handleDrawerOpen(
        locationState?.state?.data,
        locationState?.state?.index,
        "Edit"
      );
      setDataSourceFilter(locationState?.state?.data);
      setValueById(locationState?.state?.id);
      setValue(locationState?.state?.valueId);
    }
    if (locationState?.state && locationState?.state?.action === "Edit") {
      handleEditDrawerOpen(locationState?.state?.data, "Edit");
      setDataSourceFilter(locationState?.state?.data);
      setValueById(locationState?.state?.id);
      setValue(locationState?.state?.valueId);
    }
  }, [locationState]);

  const checkowner = async (id: any) => {
    const checkstatus = await axios.get(
      `/api/mrm/getAllAgendOwnersByMeetingType/${id}`
    );

    setCheckAccess(checkstatus.data.access);
  };

  const getUserInfo = async () => {
    const userInfo = await axios.get("/api/user/getUserInfo");
    if (userInfo.status === 200 || userInfo.status === 201) {
      if (
        userInfo?.data &&
        userInfo?.data?.locationId &&
        userInfo.data.locationId
      ) {
        // if (!unitId && !actionUnitId) {
        setUnitId(userInfo.data.locationId);
        getMRMValues(
          userInfo.data.locationId,
          "",
          currentYear,
          pageMrm,
          pageLimitMrm
        );
        setActionUnitId(userInfo.data.locationId);
        setMeetingUnitId(userInfo.data.locationId);
        getDataTableMeetings();
        // }
      } else {
        getMRMValues("All", "", currentYear, pageMrm, pageLimitMrm);
        setUnitId("All");
        setActionUnitId("All");
        setMeetingUnitId("All");
        getDataTableMeetings();
      }
    }
  };

  const showTotalPlan: PaginationProps["showTotal"] = (total) =>
    `Total ${total} items`;

  const handlePaginationPlan = (page: any, pageSize: any = rowsPerPagePlan) => {
    setPagePlan(page);
    setRowsPerPagePlan(pageSize);
    // getAllAuditPlanDetails(currentYear);
  };

  const handleDrawer = (data: any, values: any) => {
    setMrmEditOptions(values);
    setScheduleData(data);
    setOpenScheduleDrawer(!openScheduleDrawer);

    if (openScheduleDrawer || expandDataValues?._id) {
      getMRMValues(unitId, "", currentYear, pageMrm, pageLimitMrm);
    }
    try {
      if (data) {
        const newData = {
          unit: data?.value?.unitId,
          decisionPoints: data?.value?.decision,
          system: data?.value?.systemId,
          meetingTitle: data?.value?.meetingName,
          meetingType: data?.value?.meetingType,
          // date: data?.value?.meetingdate,
          period: data?.value?.period,
          organizer: data?.userName,
          meetingDescription: data?.value?.description,
          agendaformeetingType: data?.value?.keyAgendaId,
          dataValue: data?.value?.keyAgendaId,
          // attendees: data?.value?.attendees,
          meetingMOM: data?.value?.notes,
          //date: data?.value?.date,
          owners: data?.value?.owner,
          agendaowner: data?.value?.agendaowner,
          startDate: data.value?.date?.startDate,
          toDate: data.value?.date?.endDate,
          _id: data?.value?._id,
          files: data?.value?.files,
        };
        setExpandDataValues(newData);
      }
    } catch (error) {
      console.log("error", error);
    }
  };
  const handleCloseActionPoint = () => {
    setOpenActionPointEditDrawer({
      open: false,
      data: {},
      checkOwner: false,
    });
    setOpenActionPointDrawer({
      open: false,
      data: {},
    });
    getMRMValues(unitId, "", currentYear, pageMrm, pageLimitMrm);
  };
  const [pageMrm, setPageMrm] = useState<any>(1);
  const [pageLimitMrm, setPageLimitMrm] = useState<any>(10);
  const [count, setCount] = useState<number>(0);

  const handlePagination = (page: any, pageSize: any = pageLimitMrm) => {
    setPageMrm(page);
    setPageLimitMrm(pageSize);
    getMRMValues(unitId, "mrm", currentYear, pageMrm, pageLimitMrm);
  };

  const showTotal: PaginationProps["showTotal"] = (total) =>
    `Total ${total} items`;

  const showTotalAction: PaginationProps["showTotal"] = (total) =>
    `Total ${total} items`;

  const showTotalMeeting: PaginationProps["showTotal"] = (total) =>
    `Total ${total} items`;

  const getLocationOptions = async () => {
    await axios(`/api/location/getLocationsForOrg/${realmName}`)
      .then((res) => {
        setLocationOptions(res.data);
      })
      .catch((err) => console.error(err));
  };

  const handleOpenModal = () => {
    setOpenModal({
      open: true,
      data: {},
    });
  };

  const handleCloseModal = () => {
    setOpenModal({
      open: false,
      data: {},
    });
  };

  const handleMeetingMail = async (id: any) => {
    try {
      const mail = await axios.post(`/api/mrm/sendInvite/${id}`);
      if (mail.status == 201) {
        enqueueSnackbar("Email sent successfuly", { variant: "success" });
      }
    } catch (error) {
      enqueueSnackbar("Error sending email", { variant: "error" });
    }
  };

  const handleMail = async (data: any) => {
    try {
      const mail = await axios.post(
        `/api/mrm/sendAgendOwnerMail/${data?.value?._id}`
      );
      if (mail.status == 201) {
        enqueueSnackbar("Email sent successfuly", { variant: "success" });
      }
    } catch (error) {
      enqueueSnackbar("Error sending email", { variant: "error" });
    }
  };
  const getMRMValues = async (
    unitId: any,
    tabValue: string,
    currentYear: any,
    pageMrm: any,
    pageLimitMrm: any
  ) => {
    try {
      let newPayload = {
        orgId: orgId,
        locationId: unitId,
        currentYear: currentYear,
        page: pageMrm,
        limit: pageLimitMrm,
      };
      const res = await axios.get("/api/mrm/getScheduleDetails", {
        params: newPayload,
      });
      setCount(res?.data?.length);
      if (res.status === 200 || res.status === 201) {
        let data = res.data;
        for (let i = 0; i < data?.length; i++) {
          let value = data[i];
          value.key = i;
        }

        let actionPointData = [],
          newData = [];
        for (let i = 0; i < data?.length; i++) {
          let value = data[i];

          let actionPoints = value?.value.actionPointdata;

          newData.push({
            id: value?.value?._id,
            title: value?.value?.meetingName ?? "-",
            start: value?.value?.meetingdate ? value?.value?.meetingdate : "-",
            end: value?.value?.meetingdate ? value?.value?.meetingdate : "-",
            allDay: false,
            className: "audit-entry",
            textColor: "#000000",
            allData: value, // url: `/audit/auditreport/newaudit/${item._id}`,
          });

          for (let j = 0; j < actionPoints?.length; j++) {
            let newValue = actionPoints[j];
            actionPointData.push({
              actionPoint: newValue.actionPoint,
              status: newValue.status,
              owner: newValue.owner,
              meetingName: value.value.meetingName,
              dueDate: newValue.dueDate,
              allData: newValue,
              systemData: value?.systemData || [],
            });
          }
        }
        setCalendarData([...newData]);

        if (tabValue?.length && tabValue === "mrm") {
          setDataSource(data);
        } else if (tabValue === "action") {
          // setActionPointDataSource(actionPointData);
        } else {
          setDataSource(data);
          // setActionPointDataSource(actionPointData);
        }
        // enqueueSnackbar(`Data Fetched Successfully!`, {
        //   variant: "success",
        // });
      }
    } catch (error) {
      // enqueueSnackbar(`!`, {
      //   variant: "error",
      // });
    }
  };

  const handleLocation = (event: any, values: any) => {
    if (values && values?.id) {
      setUnitId(values?.id);
      getMRMValues(values?.id, "mrm", currentYear, pageMrm, pageLimitMrm);
      getDataTableMeetings();
    }
  };

  const handleActionLocation = (event: any, values: any) => {
    if (values && values?.id) {
      setActionUnitId(values?.id);
      //getMRMValues(values?.id, "mrm", currentYear, pageMrm, pageLimitMrm);
      // getDataTableMeetings();
      getActionPoints();
    }
  };
  const handleMeetingLocation = (event: any, values: any) => {
    if (values && values?.id) {
      setMeetingUnitId(values?.id);
      // getMRMValues(values?.id, "mrm", currentYear, pageMrm, pageLimitMrm);
      getDataTableMeetings();
    }
  };

  const handleEditActionPoint = (values: any) => {
    let allOwners: any = [],
      checkOwner = false;
    if (values?.owner && values.owner?.length) {
      for (let k = 0; k < values.owner?.length; k++) {
        let ownerValues = values.owner[k];
        allOwners.push(ownerValues?.id);
      }
    }

    if (allOwners.includes(userDetail?.id)) {
      checkOwner = true;
    }
    setOpenActionPointEditDrawer({
      open: true,
      data: values,
      checkOwner: checkOwner,
    });
  };

  // const handlerActionPointDelete = (data: any) => {
  //   const dataActionRemove = actionPointDataSource.filter(
  //     (item: any) => item._id !== data._id
  //   );
  //   setActionPointDataSource(dataActionRemove);
  //   deleteActionPoint(data._id).then((response: any) => {
  //     if (response.status === 200) {
  //       enqueueSnackbar(`Deleted Schedule Successfully!`, {
  //         variant: "success",
  //       });
  //     }
  //   });
  // };

  const subColumns: ColumnsType<IKeyAgenda> = [
    {
      title: "Action Points",
      dataIndex: "actionPoint",
      // width: 250,
      render: (_: any, data: any, index: number) => (
        <>
          <div
            style={{ textDecoration: "underline" }}
            onClick={() => handleEditActionPoint(data)}
          >
            {data?.actionPoint}
          </div>
        </>
      ),
    },
    {
      title: "Action Owner",
      dataIndex: "owner",
      // width: 250,
      render: (_: any, data: any, index: number) => (
        <>
          {data?.owner &&
            data.owner?.length &&
            data.owner.map((values: any) => <div>{values?.username}</div>)}
        </>
      ),
    },
    {
      title: "Status",
      dataIndex: "status",
      width: 150,
      render: (_: any, data: any, index: number) => (
        <>
          <Tag
            style={{ backgroundColor: data?.status ? "#F2BB00" : "#003566" }}
            key={data.status}
          >
            {data.status ? "Open" : "Close"}
          </Tag>
        </>
      ),
    },
  ];

  const columns: ColumnsType<IKeyAgenda> = [
    {
      title: "MRM Title",
      dataIndex: "value",
      width: 400,
      render: (_: any, data: any, index: number) => (
        <>
          <div
            onClick={() => {
              setMode("Edit");
              handleDrawer(data, "ReadOnly");
              setStatusMode("edit");
            }}
            style={{ textDecoration: "underline" }}
          >
            {data?.value?.meetingName}
          </div>
        </>
      ),
    },
    // Table.EXPAND_COLUMN,
    {
      title: "Scheduled Dates",
      dataIndex: "value",
      width: 150,
      render: (_: any, data: any, index: number) => {
        const parts = data?.value?.date?.startDate.split("-");
        const formattedDate = `${parts[2]}/${parts[1]}/${parts[0]}`;
        const parts1 = data?.value?.date?.endDate.split("-");
        const formattedDate1 = `${parts1[2]}/${parts1[1]}/${parts1[0]}`;
        return (
          <>
            {formattedDate} - {formattedDate1}
          </>
        );
      },
    },
    {
      title: "Owner",
      dataIndex: "userName",
      width: 150,
    },
    {
      title: "Agenda Items",
      dataIndex: "value",
      width: 150,
      render: (_: any, data: any, index: number) => {
        const items: MenuProps["items"] = [];
        data?.value?.keyAgendaId?.map((item: any) => {
          items.push({
            key: item?.id,
            label: item?.agenda,
          });
        });
        return (
          <Dropdown menu={{ items }}>
            <a onClick={(e) => e.preventDefault()}>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                  width: "auto",
                  paddingLeft: "5px",
                  paddingRight: "5px",
                  justifyContent: "space-between",
                  height: "30px",
                  backgroundColor: "#F4F6F9",
                  borderRadius: "5px",
                  color: "black",
                }}
              >
                <span
                  style={{
                    width: "100px",
                    whiteSpace: "nowrap",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                  }}
                >
                  {data?.value?.keyAgendaId[0]?.agenda}
                </span>{" "}
                <ExpandMoreIcon style={{ color: "#B2BABB" }} />
              </div>
            </a>
          </Dropdown>
        );
      },
    },
  ];

  // if (showData) {
  columns.push({
    title: "Action",
    dataIndex: "value",
    width: 50,
    render: (_: any, data: any, index: any) => (
      <div style={{ display: "flex", gap: "10px" }}>
        <IconButton
          style={{ padding: "0px" }}
          onClick={() => {
            if (data?.access) {
              handleDrawerOpen(data, index, "Edit");
            } else {
              enqueueSnackbar("Not authorized to create Meeting", {
                variant: "error",
              });
            }
          }}
        >
          <Tooltip title="Create Meeting" placement="bottom">
            <CreateIcon style={{ marginRight: "4px", height: "18px" }} />
          </Tooltip>
        </IconButton>
        <IconButton
          style={{ padding: "0px" }}
          onClick={() => {
            //actionForSchedule(data?.value?._id);

            if (data.access) {
              handleDrawer(data, "Edit");
              setStatusMode("edit");
            } else {
              enqueueSnackbar("Not authorized to Edit", { variant: "error" });
            }
          }}
        >
          <Tooltip title="Edit Schedule" placement="bottom">
            <CustomEditIcon style={{ marginRight: "4px", height: "19px" }} />
          </Tooltip>
        </IconButton>
        {/* <IconButton onClick={() => handleMail(data)}>
          <Tooltip title="Send Mail" placement="bottom">
            <MailOutlineIcon style={{ marginRight: "4px", height: "20px" }} />
          </Tooltip>
        </IconButton> */}
        <IconButton style={{ padding: "0px" }}>
          <Popconfirm
            placement="top"
            title={"Are you sure to delete Schedule Meeting"}
            onConfirm={() => {
              if (data.access || showData) {
                handleDeleteSchedule(data);
              } else {
                enqueueSnackbar("Not authorized to Schedule Meeting", {
                  variant: "error",
                });
              }
            }}
            okText="Yes"
            cancelText="No"
            // disabled={showData ? false : true}
          >
            <Tooltip title="Delete Schedule" placement="bottom">
              <CustomDeleteICon
                style={{ marginRight: "4px", height: "19px" }}
              />
            </Tooltip>
          </Popconfirm>
        </IconButton>
      </div>
    ),
  });
  // }

  const actionPointColumns: ColumnsType<IKeyAgenda> = [
    {
      title: "Action Items",
      dataIndex: "actionPoint",
      width: 250,
      render: (_: any, data: any, index: number) => (
        <>
          <div
            style={{ textDecoration: "underline" }}
            // onClick={() => handleEditActionPoint(data)}
            onClick={() => {
              handlerActionEditOpen(data, "ReadOnly");
            }}
          >
            {data?.actionPoint}
          </div>
        </>
      ),
    },
    // {
    //   title: "System",
    //   dataIndex: "systemData",
    //   // width: 250,
    //   render: (_: any, data: any, index: number) => (
    //     <>
    //       {data?.systemData &&
    //         data.systemData.length &&
    //         data.systemData.map((values: any) => <div>{values?.name}</div>)}
    //     </>
    //   ),
    // },
    {
      title: "MRM Meeting Name",
      dataIndex: "meetingName",
      width: 250,
      render: (_: any, data: any, index: number) => (
        <>{data.meetingId.meetingName}</>
      ),
    },
    {
      title: "Responsible Person",
      dataIndex: "Responsible Person",
      width: 160,
      render: (_: any, data: any, index: number) => (
        <>
          <div>
            {data?.owner &&
              data.owner?.length &&
              data.owner?.map((item: any, index: number) => (
                <React.Fragment key={index}>
                  {item?.username || ""}
                  {index < data.owner?.length - 1 && ", "}
                </React.Fragment>
              ))}
          </div>
        </>
      ),
    },

    {
      title: "Status",
      dataIndex: "status",
      width: 100,
      render: (_: any, data: any, index: number) => (
        <>
          {/* {data?.value?.actionPointdata && data?.value?.actionPointdata && data.value.actionPointdata.map((item: any) => ( */}
          <Tag
            style={{
              backgroundColor: data?.status ? "#D4E6F1" : "#FADBD8",
              color: "black",
            }}
            key={data.status}
          >
            {data.status ? "Open" : "Close"}
          </Tag>
          {/* ))} */}
        </>
      ),
    },
    {
      title: "Due Date",
      dataIndex: "dueDate",
      width: 100,
      render: (_: any, data: any, index: number) => (
        <>{moment(data?.dueDate).format("DD-MM-YYYY")}</>
      ),
    },
    {
      title: "Actions",
      dataIndex: "actions",
      width: 80,
      render: (_: any, data: any, index: number) => (
        <>
          <div style={{ display: "flex", alignItems: "left" }}>
            {(isOrgAdmin ||
              data?.owner?.some((owner: any) => owner.id === userDetail.id) ||
              data?.createdBy === userDetail.id ||
              (isMR && actionUnitId === userDetail.location.id)) && (
              <IconButton
                style={{ padding: "0px" }}
                onClick={() => {
                  handlerActionEditOpen(data, "Edit");
                }}
              >
                <CustomEditIcon
                  style={{
                    marginRight: "2px",
                    fontSize: "15px",
                    height: "20px",
                  }}
                />
              </IconButton>
            )}
            {(isOrgAdmin ||
              data?.owner?.some((owner: any) => owner.id === userDetail?.id) ||
              (isMR && actionUnitId === userDetail.location.id) ||
              data?.createdBy === userDetail?.id) && (
              <IconButton>
                <Popconfirm
                  placement="top"
                  title={"Are you sure to delete Action Points"}
                  onConfirm={() => {
                    if (
                      showData ||
                      data?.owner?.some(
                        (owner: any) => owner?.id === userDetail?.id
                      )
                    ) {
                      handleDeleteActionPoint(data);
                    } else {
                      enqueueSnackbar(`You are not authorized to delete`, {
                        variant: "error",
                      });
                    }
                  }}
                  okText="Yes"
                  cancelText="No"
                  // disabled={showData ? false : true}
                >
                  <CustomDeleteICon
                    style={{
                      fontSize: "15px",
                      marginRight: "2px",
                      height: "20px",
                    }}
                  />
                </Popconfirm>
              </IconButton>
            )}
          </div>
        </>
      ),
    },
  ];

  const createHandler = (record: any = {}) => {
    if (!value) {
      handleDrawer(undefined, "Direct");
      setStatusMode("Create");
    }
    if (value === 6) {
      if (showData) {
        setAddKeyAgenda(true);
      }
    }
  };

  const configHandler = () => {
    navigate("/mrm/keyagenda");
  };

  const filterHandler = () => {
    // navigate("/processdocuments/documenttype");
  };

  const handleOpenMenu = (
    event: React.MouseEvent<HTMLButtonElement>,
    data: any
  ) => {
    setAnchorEl(event.currentTarget);
    setSelectedData({ ...data });
  };

  const handleActionPoint = () => {
    setOpenActionPointDrawer({
      open: true,
      data: selectedData,
    });
    handleCloseMenu();
  };
  const handleDeleteSchedule = async (data: any) => {
    const id = data.value._id;

    // const filterData = dataSource?.filter((item:any)=>item.key === data.key)
    // setDataSource(filterData)
    // console.log("filterData",filterData)
    try {
      const res = await axios.delete(
        `${API_LINK}/api/mrm/deleteSchedule/${id}`
      );
      if (res.status === 200) {
        enqueueSnackbar(`Deleted Schedule Successfully!`, {
          variant: "success",
        });
      }
      getMRMValues(unitId, "", currentYear, pageMrm, pageLimitMrm);
    } catch (error) {
      enqueueSnackbar(`Error in deleting!`, {
        variant: "error",
      });
    }
  };
  const handleDeleteActionPoint = async (data: any) => {
    const id = data._id;

    try {
      // const res = await axios.delete(
      //   `${API_LINK}/api/mrm/deleteActionPoint/${id}`
      // );
      // if (res.status === 200) {
      //   enqueueSnackbar(`Deleted ActionPoint Successfully!`, {
      //     variant: "success",
      //   });
      // }
      // getActionPoints();
      const filterByData = actionPointDataSource.filter(
        (item: any) => item._id !== id
      );
      setActionPointDataSource(filterByData);
      deleteActionPoint(id).then((response: any) => {
        if (response.Status === 200 || response.Status === 201) {
          enqueueSnackbar(`Action Point Deleted`, {
            variant: "error",
          });
        }
      });
    } catch (error) {
      enqueueSnackbar(`Something went wrong!`, {
        variant: "error",
      });
    }
  };

  const handleCloseMenu = () => {
    setAnchorEl(null);
  };

  const handleChange = (event: any, newValue: any) => {
    setValue(newValue);
  };

  const getSelectedItem = () => {
    const item = [allOption, ...locationOptions].find((opt: any) => {
      if (opt.id === unitId) return opt;
    });
    return item || {};
  };

  const getSelectedActionItem = () => {
    const item = [allOption, ...locationOptions].find((opt: any) => {
      if (opt.id === actionUnitId) return opt;
    });
    return item || {};
  };
  const getSelectedMeetingItem = () => {
    const item = [allOption, ...locationOptions].find((opt: any) => {
      if (opt.id === meetingUnitId) return opt;
    });
    return item || {};
  };
  const sendInvite = async () => {
    setAnchorEl(null);
    enqueueSnackbar(
      `Your request is saving in background. Once it complete system will notify for same!`,
      {
        variant: "info",
      }
    );
    const res = await axios.post("/api/mrm/sendInvite", selectedData);
    if (res.status === 200 || res.status === 201) {
      enqueueSnackbar(`Invite Send Successfully!`, {
        variant: "success",
      });
    }
  };

  // const onStatusChange = async () => {
  //   try {
  //     let res;
  //     if (myActionPoint) {
  //       let newPayload = {
  //         orgId: orgId,
  //         locationId: "All",
  //       };
  //       res = await axios.get("/api/mrm/getScheduleDetails", {
  //         params: newPayload,
  //       });
  //     } else {
  //       let payload = {
  //         orgId: orgId,
  //         userId: userDetail?.id || "",
  //       };
  //       res = await axios.get("/api/mrm/getOwnScheduleDetails", {
  //         params: payload,
  //       });
  //     }

  //     if (res.status === 200 || res.status === 201) {
  //       let data = res.data;
  //       for (let i = 0; i < data.length; i++) {
  //         let value = data[i];
  //         value.key = i;
  //       }

  //       let actionPointData = [],
  //         newData = [];
  //       for (let i = 0; i < data.length; i++) {
  //         let value = data[i];

  //         let actionPoints = value?.value.actionPointdata;

  //         newData.push({
  //           id: value?.value?._id,
  //           title: value?.value?.meetingName ?? "-",
  //           start: value?.value?.meetingdate ? value?.value?.meetingdate : "-",
  //           allDay: false,
  //           className: "audit-entry",
  //           textColor: "#000000",
  //           allData: value, // url: `/audit/auditreport/newaudit/${item._id}`,
  //         });

  //   for (let j = 0; j < actionPoints?.length; j++) {
  //     let newValue = actionPoints[j];
  //     actionPointData.push({
  //       actionPoint: newValue.actionPoint,
  //       status: newValue.status,
  //       owner: newValue.owner,
  //       meetingName: value.value.meetingName,
  //       dueDate: newValue.dueDate,
  //       allData: newValue,
  //       systemData: value?.systemData || [],
  //     });
  //   }
  // }
  // setCalendarData([...newData]);
  // setDataSource(data);
  // setActionPointDataSource(actionPointData);
  // enqueueSnackbar(`Data Added Successfully!`, {
  //     variant: "success",
  // });
  //     setMyactionPoint(!myActionPoint);
  //   }
  // } catch (error) {
  //   console.log(error);
  // enqueueSnackbar(`!`, {
  //   variant: "error",
  // });
  // }
  // };
  //         for (let j = 0; j < actionPoints.length; j++) {
  //           let newValue = actionPoints[j];
  //           actionPointData.push({
  //             actionPoint: newValue.actionPoint,
  //             status: newValue.status,
  //             owner: newValue.owner,
  //             meetingName: value.value.meetingName,
  //             dueDate: newValue.dueDate,
  //             allData: newValue,
  //             systemData: value?.systemData || [],
  //           });
  //         }
  //       }
  //       setCalendarData([...newData]);
  //       setDataSource(data);
  //       setActionPointDataSource(actionPointData);
  //       // enqueueSnackbar(`Data Added Successfully!`, {
  //       //     variant: "success",
  //       // });
  //       setMyactionPoint(!myActionPoint);
  //     }
  //   } catch (error) {
  //     console.log(error);
  //     // enqueueSnackbar(`!`, {
  //     //   variant: "error",
  //     // });
  //   }
  // };
  // console.log("expand data values", expandDataValues);

  const handleCheck = async (tabValue: string) => {
    let newPayload = {
      text: searchValue,
      orgId: orgId,
      page: pageMrm,
      limit: pageLimitMrm,
    };

    let res = await axios.get("/api/mrm/search", { params: newPayload });
    if (res.status === 200 || res.status === 201) {
      let data = res.data;
      for (let i = 0; i < data?.length; i++) {
        let value = data[i];
        value.key = i;
      }

      // let actionPointDataValue = [];
      // for (let i = 0; i < data?.length; i++) {
      //   let value = data[i];

      //   let actionPoints = value?.value.actionPointdata;

      //   for (let j = 0; j < actionPoints?.length; j++) {
      //     let newValue = actionPoints[j];
      //     actionPointDataValue.push({
      //       actionPoint: newValue.actionPoint,
      //       status: newValue.status,
      //       owner: newValue.owner,
      //       meetingName: value.value.meetingName,
      //       dueDate: newValue.dueDate,
      //       allData: newValue,
      //       systemData: value?.systemData || [],
      //     });
      //   }
      // }

      if (tabValue === "mrm") {
        setDataSource(data);
        setCount(data?.length);
      } else {
        // setActionPointDataSource(actionPointDataValue);
      }

      // enqueueSnackbar(`Data Added Successfully!`, {
      //     variant: "success",
      // });
    }
  };

  const handleMeetingSearch = async (searchValue: string) => {
    let newPayload = {
      text: searchValue,
      orgId: orgId,
      page: page,
      limit: pageLimit,
    };
    try {
      let res = await axios.get("/api/mrm/searchMeetings", {
        params: newPayload,
      });
      setMeetingsDataApi(res?.data);
    } catch (error) {
      enqueueSnackbar(`Meeting search failed!`, {
        variant: "error",
      });
      return error;
    }
  };
  const handleActionPointSearch = async (searchValue: string) => {
    let newPayload = {
      text: searchValue,
      orgId: orgId,
      page: pageAction,
      limit: pageLimitAction,
    };
    try {
      let res = await axios.get("/api/mrm/searchActionPoint", {
        params: newPayload,
      });
      setActionPointDataSource(res?.data);
    } catch (error) {
      enqueueSnackbar(`Action Point search failed!`, {
        variant: "error",
      });
      return error;
    }
  };
  const handleSearchChange = (e: any) => {
    e.preventDefault();
    setSearchValue(e.target.value);
  };
  const handleMeetingSearchChange = (e: any) => {
    e.preventDefault();
    setMeetingSearchValue(e.target.value);
  };
  const handleActionPointSearchChange = (e: any) => {
    e.preventDefault();
    setActionPointSearchValue(e.target.value);
  };

  const handleClickDiscard = () => {
    setSearchValue("");
    setMeetingSearchValue("");
    setActionPointSearchValue("");
    getMRMValues(unitId, "", currentYear, pageMrm, pageLimitMrm);
    getDataTableMeetings();
  };

  const toggleCalendarModal = (data: any = {}) => {
    setCalendarModalInfo({
      ...calendarModalInfo,
      open: !calendarModalInfo.open,
      data: data,
    });
  };

  const handlerMeetingDelete = (id: any) => {
    deleteMeeting(id).then((response: any) => {
      if (response.status === 200) {
        enqueueSnackbar(`Deleted Meeting Successfully!`, {
          variant: "success",
        });
      } else {
        enqueueSnackbar(`error occured!`, {
          variant: "error",
        });
      }
    });
    getDataTableMeetings();
  };

  const actionForSchedule = async (id: any) => {
    try {
      const result = await axios.get(`/api/mrm/getOwnerForSchedule/${id}`);

      setOwner(result?.data);
    } catch (error) {
      enqueueSnackbar("Error fetching the owner for schedule", {
        variant: "error",
      });
    }
  };
  // const newactionForSchedule = async (id: any) => {
  //   try {
  //     const result = await axios.get(`/api/mrm/getOwnerForSchedule/${id}`);
  //     console.log("result in action", result);
  //     return result.data;
  //   } catch (error) {
  //     enqueueSnackbar("Error fetching the owner for schedule", {
  //       variant: "error",
  //     });
  //   }
  // };

  const meetingsTableHeaders: ColumnsType<IKeyAgenda> = [
    {
      title: "Meeting Title",
      dataIndex: "MeetingTitle",
      width: 350,
      render: (_: any, data: any) => (
        <>
          <div
            style={{ textDecoration: "underline" }}
            onClick={() => {
              handleEditDrawerOpen(data, "ReadOnly");
            }}
          >
            {data?.meetingName}
          </div>
        </>
      ),
    },
    {
      title: "Meeting Date & Time",
      dataIndex: "MeetingDate",
      width: 150,
      render: (_: any, data: any) => {
        const dateTime = new Date(data?.meetingdate);
        const [datePart, timePart] = data?.meetingdate.split("T");
        const date = datePart.split("-").reverse().join("-");
        const time = timePart.slice(0, 5);
        return (
          <div style={{ display: "flex", gap: "10px" }}>
            <span>{date}</span>
            <span>{time}</span>
          </div>
        );
      },
    },
    {
      title: "Agenda",
      dataIndex: "Agenda",
      width: 150,
      render: (_: any, data: any) => {
        const items: MenuProps["items"] = [];
        data.agenda.map((item: any) => {
          items.push({
            key: item?.id,
            label: item?.agenda,
          });
        });
        return (
          <>
            <Dropdown menu={{ items }}>
              <a onClick={(e) => e.preventDefault()}>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "8px",
                    width: "auto",
                    paddingLeft: "5px",
                    paddingRight: "5px",
                    justifyContent: "space-between",
                    height: "30px",
                    backgroundColor: "#F4F6F9",
                    borderRadius: "5px",
                    color: "black",
                  }}
                >
                  <span
                    style={{
                      width: "100px",
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {data?.agenda[0]?.agenda}
                  </span>{" "}
                  <ExpandMoreIcon style={{ color: "#B2BABB" }} />
                </div>
              </a>
            </Dropdown>
          </>
        );
      },
    },
    {
      title: "Meeting Owner",
      dataIndex: "AgendaOwner",
      width: 150,
      render: (_: any, data: any) => <>{data?.createdBy?.username}</>,
    },
    {
      title: "Actions",
      dataIndex: "actions",
      width: 100,
      render: (_: any, data: any) => {
        return (
          <>
            <div
              style={{
                display: "flex",
                justifyContent: "left",
                alignItems: "center", // Change "left" to "center" for vertical alignment
              }}
            >
              <IconButton
                onClick={() => {
                  //  actionForSchedule(data?.meetingSchedule._id);
                  if (data?.access) {
                    handleEditDrawerOpen(data, "Edit");
                  } else {
                    enqueueSnackbar(`Not authorized to Edit Meeting`, {
                      variant: "error",
                    });
                  }
                }}
              >
                <Tooltip title="Edit Meeting" placement="bottom">
                  <CustomEditIcon
                    style={{
                      marginRight: "2px",
                      fontSize: "15px",
                      height: "20px",
                    }}
                  />
                </Tooltip>
              </IconButton>

              <Popconfirm
                placement="top"
                title={"Are you sure to delete Meeting"}
                onConfirm={() => {
                  //actionForSchedule(data?.meetingSchedule?._id);
                  if (data?.access) {
                    handlerMeetingDelete(data?._id);
                  } else {
                    enqueueSnackbar(`Not authorized to delete Meeting`, {
                      variant: "error",
                    });
                  }
                }}
                okText="Yes"
                cancelText="No"
              >
                <Tooltip title="Delete Meeting" placement="bottom">
                  <CustomDeleteICon
                    style={{
                      fontSize: "15px",
                      marginRight: "2px",
                      height: "20px",
                    }}
                  />
                </Tooltip>
              </Popconfirm>

              <IconButton
                onClick={() => {
                  // actionForSchedule(data?.meetingSchedule._id);
                  if (data?.access) {
                    handleMeetingMail(data._id);
                  } else {
                    enqueueSnackbar(`Not authorized to send Mail`, {
                      variant: "error",
                    });
                  }
                }}
              >
                <Tooltip title="Send Mail" placement="bottom">
                  <MailOutlineIcon
                    style={{
                      marginRight: "2px",
                      fontSize: "20px",
                      height: "20px",
                    }}
                  />
                </Tooltip>
              </IconButton>
              {/* <Divider type="vertical" style={{ color: "black" }} /> */}
              <IconButton
                onClick={() => {
                  // actionForSchedule(data?.meetingSchedule._id);
                  if (data?.access) {
                    handlerActionAddOpen(data);
                  } else {
                    enqueueSnackbar(`Not authorized to create Action Point`, {
                      variant: "error",
                    });
                  }
                }}
              >
                <Tooltip title="Add Action Point" placement="bottom">
                  <AddCircleOutlineIcon
                    style={{ marginRight: "4px", fontSize: "22px" }}
                  />
                </Tooltip>
              </IconButton>
              <IconButton
                onClick={() => {
                  handleGetMrmReports(data);
                }}
              >
                <Tooltip title="Download Pdf" placement="bottom">
                  <PictureAsPdfOutlinedIcon
                    style={{ marginRight: "4px", fontSize: "22px" }}
                  />
                </Tooltip>
              </IconButton>
            </div>
          </>
        );
      },
    },
  ];

  const handlePaginationMeeting = (page: any, pageSize: any = pageLimit) => {
    setPage(page);
    setPageLimit(pageSize);
    getDataTableMeetings();
  };

  const [tableColumns, setTableColumns] = useState([]);
  const [dataSourceMrm, setDataSourceMrm] = useState<any[]>([]);
  const [selectedUnit, setSelectedUnit] = useState<string>("");
  const [units, setUnits] = useState<any[]>([]);
  const [systemData, setSystemData] = useState<any[]>([]);
  const [selectedSystem, setSelectedSystem] = useState<any[]>([]);
  const [suggestions, setSuggestions] = React.useState([]);
  const [formData, setFormData] = useRecoilState(documentTypeFormData);
  const [loading, setLoading] = useState<boolean>(false);
  const [settings, setSettings] = useState<string>("");
  const [auditYear, setAuditYear] = useRecoilState<any>(currentAuditYear);
  const isOrgAdmin = checkRoles("ORG-ADMIN");
  const isMR = checkRoles("MR");

  const unitSystemData = {
    unit: locationNameUnit,
    system: selectedSystem,
  };

  const showData = isOrgAdmin || isMR;

  useEffect(() => {
    getyear();
    getHeaderData();
  }, []);

  const getyear = async () => {
    const currentyear = await getYearFormat(new Date().getFullYear());
    setCurrentYear(currentyear);
  };
  const getHeaderData = () => {
    getOrganizationData(realmName).then((response: any) => {
      setAuditYear(response?.data?.auditYear);
    });
  };

  const checkOwnerAccess = (id: any) => {
    try {
      const result = axios.get(`/api/mrm/getAllAgendOwnersByMeetingType/${id}`);
    } catch (error) {
      return error;
    }
  };
  const monthsColumns = [
    {
      title: "Apr",
      dataIndex: "mrmData",
      key: "mrmData",
      align: "center",
      render: (_: any, data: any, index: any) => (
        <div style={{ textAlign: "center" }}>
          <Checkbox
            disabled={
              isOrgAdmin || (isMR && userDetail.location.id === selectedUnit)
                ? false
                : true
            }
            onChange={(event) => handleCheckBox(event, data, index, 0)}
            key="april"
            checked={
              data?.mrmData?.mrmPlanData && data?.mrmData?.mrmPlanData[0]
            }
          />
        </div>
      ),
    },
    {
      title: "May",
      dataIndex: "mrmData",
      key: "mrmData",
      align: "center",
      render: (_: any, data: any, index: any) => (
        <div style={{ textAlign: "center" }}>
          <Checkbox
            disabled={
              isOrgAdmin || (isMR && userDetail.location.id === selectedUnit)
                ? false
                : true
            }
            onChange={(event) => handleCheckBox(event, data, index, 1)}
            checked={
              data?.mrmData?.mrmPlanData && data?.mrmData?.mrmPlanData[1]
            }
          />
        </div>
      ),
    },
    {
      title: "June",
      dataIndex: "mrmData",
      key: "mrmData",
      align: "center",
      render: (_: any, data: any, index: any) => (
        <div style={{ textAlign: "center" }}>
          <Checkbox
            disabled={
              isOrgAdmin || (isMR && userDetail.location.id === selectedUnit)
                ? false
                : true
            }
            onChange={(event) => handleCheckBox(event, data, index, 2)}
            checked={
              data?.mrmData?.mrmPlanData && data?.mrmData?.mrmPlanData[2]
            }
          />
        </div>
      ),
    },
    {
      title: "July",
      dataIndex: "mrmData",
      key: "mrmData",
      align: "center",
      render: (_: any, data: any, index: any) => (
        <div style={{ textAlign: "center" }}>
          <Checkbox
            disabled={
              isOrgAdmin || (isMR && userDetail.location.id === selectedUnit)
                ? false
                : true
            }
            onChange={(event) => handleCheckBox(event, data, index, 3)}
            checked={
              data?.mrmData?.mrmPlanData && data?.mrmData?.mrmPlanData[3]
            }
          />
        </div>
      ),
    },
    {
      title: "Aug",
      dataIndex: "mrmData",
      key: "mrmData",
      align: "center",
      render: (_: any, data: any, index: any) => (
        <div style={{ textAlign: "center" }}>
          <Checkbox
            disabled={
              isOrgAdmin || (isMR && userDetail.location.id === selectedUnit)
                ? false
                : true
            }
            onChange={(event) => handleCheckBox(event, data, index, 4)}
            checked={
              data?.mrmData?.mrmPlanData && data?.mrmData?.mrmPlanData[4]
            }
          />
        </div>
      ),
    },
    {
      title: "Sep",
      dataIndex: "mrmData",
      key: "mrmData",
      align: "center",
      render: (_: any, data: any, index: any) => (
        <div style={{ textAlign: "center" }}>
          <Checkbox
            disabled={
              isOrgAdmin || (isMR && userDetail.location.id === selectedUnit)
                ? false
                : true
            }
            onChange={(event) => handleCheckBox(event, data, index, 5)}
            checked={
              data?.mrmData?.mrmPlanData && data?.mrmData?.mrmPlanData[5]
            }
          />
        </div>
      ),
    },
    {
      title: "Oct",
      dataIndex: "mrmData",
      key: "mrmData",
      align: "center",
      render: (_: any, data: any, index: any) => (
        <div style={{ textAlign: "center" }}>
          <Checkbox
            disabled={
              isOrgAdmin || (isMR && userDetail.location.id === selectedUnit)
                ? false
                : true
            }
            onChange={(event) => handleCheckBox(event, data, index, 6)}
            checked={
              data?.mrmData?.mrmPlanData && data?.mrmData?.mrmPlanData[6]
            }
          />
        </div>
      ),
    },
    {
      title: "Nov",
      dataIndex: "mrmData",
      key: "mrmData",
      align: "center",
      render: (_: any, data: any, index: any) => (
        <div style={{ textAlign: "center" }}>
          <Checkbox
            disabled={
              isOrgAdmin || (isMR && userDetail.location.id === selectedUnit)
                ? false
                : true
            }
            onChange={(event) => handleCheckBox(event, data, index, 7)}
            checked={
              data?.mrmData?.mrmPlanData && data?.mrmData?.mrmPlanData[7]
            }
          />
        </div>
      ),
    },
    {
      title: "Dec",
      dataIndex: "mrmData",
      key: "mrmData",
      align: "center",
      render: (_: any, data: any, index: any) => (
        <div style={{ textAlign: "center" }}>
          <Checkbox
            disabled={
              isOrgAdmin || (isMR && userDetail.location.id === selectedUnit)
                ? false
                : true
            }
            onChange={(event) => handleCheckBox(event, data, index, 8)}
            checked={
              data?.mrmData?.mrmPlanData && data?.mrmData?.mrmPlanData[8]
            }
          />
        </div>
      ),
    },
    {
      title: "Jan",
      dataIndex: "mrmData",
      key: "mrmData",
      align: "center",
      render: (_: any, data: any, index: any) => (
        <div style={{ textAlign: "center" }}>
          <Checkbox
            disabled={
              isOrgAdmin || (isMR && userDetail.location.id === selectedUnit)
                ? false
                : true
            }
            onChange={(event) => handleCheckBox(event, data, index, 9)}
            checked={
              data?.mrmData?.mrmPlanData && data?.mrmData?.mrmPlanData[9]
            }
          />
        </div>
      ),
    },
    {
      title: "Feb",
      dataIndex: "mrmData",
      key: "mrmData",
      align: "center",
      render: (_: any, data: any, index: any) => (
        <div style={{ textAlign: "center" }}>
          <Checkbox
            disabled={
              isOrgAdmin || (isMR && userDetail.location.id === selectedUnit)
                ? false
                : true
            }
            onChange={(event) => handleCheckBox(event, data, index, 10)}
            checked={
              data?.mrmData?.mrmPlanData && data?.mrmData?.mrmPlanData[10]
            }
          />
        </div>
      ),
    },
    {
      title: "Mar",
      dataIndex: "mrmData",
      key: "mrmData",
      align: "center",
      render: (_: any, data: any, index: any) => (
        <div style={{ textAlign: "center" }}>
          <Checkbox
            style={{ borderColor: "grey" }}
            disabled={
              isOrgAdmin || (isMR && userDetail.location.id === selectedUnit)
                ? false
                : true
            }
            onChange={(event) => handleCheckBox(event, data, index, 11)}
            checked={
              data?.mrmData?.mrmPlanData && data?.mrmData?.mrmPlanData[11]
            }
          />
        </div>
      ),
    },
  ];

  const columnsMrm = [
    {
      title: "Meeting Type",
      dataIndex: "name",
      key: "name",
      width: 120,
      render: (_: any, data: any) => <>{data?.name}</>,
    },
    {
      title: "Owners",
      dataIndex: "owner",
      key: "owner",
      width: 100,
      render: (_: any, data: any) => (
        <>
          {data?.owner?.map((item: any) => {
            return <div>{item?.username}</div>;
          })}
        </>
      ),
    },
  ];

  const actionsMrm = [
    {
      title: "Action",
      dataIndex: "Action",
      key: "Action",
      width: 100,
      render: (_: any, data: any) => {
        const buttonStatusAction = data?.mrmData?.mrmPlanData.includes(true);
        return (
          <>
            {buttonStatusAction && (
              <div style={{ display: "flex", gap: "10px" }}>
                {(showData ||
                  data?.owner?.some(
                    (owner: any) => owner.id === userDetail.id
                  )) && (
                  <IconButton>
                    <Tooltip title="Create Meeting Schedule" placement="bottom">
                      <CreateIcon
                        style={{ marginRight: "4px", height: "18px" }}
                        onClick={() => {
                          handleDrawer(data, "MrmPlan");
                        }}
                      />
                    </Tooltip>
                  </IconButton>
                )}
              </div>
            )}
          </>
        );
      },
    },
  ];
  if (settings && settings.length) {
    if (settings === "Jan - Dec") {
      let newData = monthsColumns.splice(0, 9);
      addMonthyColumns = [
        ...columnsMrm,
        ...monthsColumns,
        ...newData,
        ...actionsMrm,
      ];
    } else {
      addMonthyColumns = [...columnsMrm, ...monthsColumns, ...actionsMrm];
    }
  }

  // const handleTextChange = (e: any) => {
  //   getSuggestionList(e.target.value, "normal");
  // };

  // const getSuggestionList = (value: any, type: string) => {
  //   typeAheadValue = value;
  //   typeAheadType = type;
  //   debouncedSearch();
  // };

  // const debouncedSearch = debounce(() => {
  //   getData(typeAheadValue, typeAheadType);
  // }, 400);

  const getData = async (value: string, type: string) => {
    try {
      let res = await axios.get(
        `api/user/doctype/filterusers/${realmName}/${"allusers"}?email=${value}`
      );
      setSuggestions(res.data);
    } catch (err) {
      console.log(err);
    }
  };

  const handleChangeParticipants = (data: any, values: any, index: number) => {
    const newData = { ...values };
    if (newData.mrmData) {
      newData.mrmData.participants = [...data];
    }
    const newDataSource = [...dataSource];
    newDataSource[index] = newData;
    setDataSourceMrm(newDataSource);
  };

  useEffect(() => {
    getUnits();
    orgdata();
  }, []);

  useEffect(() => {
    if (!!currentYear) {
      getKeyAgendaValues(selectedUnit, selectedSystem);
    }
  }, [currentYear]);
  useEffect(() => {
    getKeyAgendaValues(selectedUnit, selectedSystem);
  }, [selectedSystem]);

  const orgdata = async () => {
    const response = await axios.get(`/api/organization/${realmName}`);

    if (response.status === 200 || response.status === 201) {
      setSettings(response?.data?.fiscalYearQuarters);
    }
  };
  const getUnits = async () => {
    setLoading(true);
    await axios(`/api/location/getLocationsForOrg/${realmName}`)
      .then((res) => {
        setUnits(res?.data);
        setLoading(false);
      })
      .catch((err) => {
        setLoading(false);
        console.error(err);
      });
  };

  const getKeyAgendaValues = async (units: any, data: any) => {
    try {
      setLoading(true);
      //get api

      const payload = {
        orgId: orgId,
        unitId: [units],
        applicationSystemID: [data],
        currentYear: currentYear,
        page: pagePlan,
        limit: rowsPerPagePlan,
      };
      const res = await axios.get("/api/keyagenda/getkeyAgendaMRMByUnit", {
        params: payload,
      });

      if (res.status === 200 || res.status === 201) {
        const data = res.data;
        const keyAgendaData: any = [];
        data?.map((item: any) => {
          if ("mrmData" in item) {
            keyAgendaData.push(item);
          } else {
            keyAgendaData.push({
              ...item,
              mrmData: {
                participants: [],
                mrmPlanData: [
                  false,
                  false,
                  false,
                  false,
                  false,
                  false,
                  false,
                  false,
                  false,
                  false,
                  false,
                  false,
                ],
              },
            });
          }
        });
        setDataSourceMrm(keyAgendaData);
        setLoading(false);
        setCountPlan(keyAgendaData?.length);
      }
      // getkeyAgendaMRMByUnit
    } catch (error) {
      console.log(error);
      setLoading(false);
      // enqueueSnackbar(`!`, {
      //   variant: "error",
      // });
    }
  };

  // const handleCheckBox = (
  //   event: any,
  //   values: any,
  //   index: number,
  //   key: number
  // ) => {
  //   const newObj = { ...values };
  //   if (newObj.mrmData && newObj.mrmData.mrmPlanData) {
  //     newObj.mrmData.mrmPlanData[key] = event?.target?.checked;
  //   }
  //   const newDataSource = [...dataSource];
  //   newDataSource[index] = newObj;
  //   setDataSource(newDataSource);
  // };
  const handleCheckBox = (
    event: any,
    values: any,
    index: number,
    key: number
  ) => {
    setDataSourceMrm((prevDataSource) => {
      const newDataSource = [...prevDataSource];
      const newObj = { ...values };

      if (newObj.mrmData && newObj.mrmData.mrmPlanData) {
        newObj.mrmData.mrmPlanData[key] = event?.target?.checked;
      }

      newDataSource[index] = newObj;
      return newDataSource;
    });
    setSubmitButtonStatus(true);
  };

  const handleOk = () => {
    if (showData) {
      const updateArray: any = [];
      const addArray: any = [];

      const newdataSource = [...dataSourceMrm];
      newdataSource.map((item) => {
        if (item?.mrmData?._id) {
          delete item.mrmData?.keyAgendaId;
          updateArray.push({ ...item.mrmData, fiscalYear: settings });
        } else {
          addArray.push({
            ...item.mrmData,
            keyAgendaId: item?._id,
            unitId: selectedUnit,
            momPlanYear: auditYear,
            organizationId: orgId,
            currentYear: currentYear,
            fiscalYear: settings,
          });
        }
      });

      if (addArray.length) {
        addMRMData(addArray);
      }

      if (updateArray.length) {
        updateMRMData(updateArray);
      }
    }
    handleCloseModal();
  };

  const addMRMData = async (data: any) => {
    try {
      const res = await axios.post("/api/mrm", data);
      if (res.status === 200 || res.status === 201) {
        enqueueSnackbar(`Data Added Successfully!`, {
          variant: "success",
        });
      }
    } catch (err) {
      console.log(err);
    }
  };

  const updateMRMData = async (data: any) => {
    try {
      const res = await axios.patch(`/api/mrm`, data);
      if (res.status === 200 || res.status === 201) {
        enqueueSnackbar(`Data Added Successfully!`, {
          variant: "success",
        });
      }
    } catch (err) {
      console.log(err);
    }
  };

  const handleChangeUnit = (event: React.ChangeEvent<{ value: any }>) => {
    setLocationNameUnit(event.target.value as string);
    setSelectedUnit(event.target.value as string);

    if (selectedSystem && selectedSystem.length) {
      getKeyAgendaValues(event.target.value, selectedSystem);
    } else {
      getApplicationSystems(event.target.value);
    }
  };

  // const handleChangeSystem = (event: React.ChangeEvent<{ value: any }>) => {
  //   setSelectedSystem(event.target.value as string);
  //   getKeyAgendaValues(selectedUnit, event.target.value);
  // };
  const handleChangeSystem = (event: any) => {
    setSelectedSystem(event.target.value);
    // console.log("target value", event.target.value);
    // if (selectedSystem && selectedUnit) {
    //   getKeyAgendaValues(selectedUnit, selectedSystem);
    // }
  };

  const getApplicationSystems = async (locationId: any) => {
    let encodedSystems = encodeURIComponent(JSON.stringify(locationId));
    const { data } = await axios.get(
      `api/systems/displaySystems/${encodedSystems}`
    );
    setSystemData([...data]);
  };

  const handleGetMrmReports = async (val: any) => {
    getActionPointMeetingById(val._id).then((response: any) => {
      setActionPointsPdfData(response?.data);
    });

    getMeetingById(val._id).then((response: any) => {
      setMeetingDataById(response?.data);
    });

    if (meetingDataById && actionPointsPdfData) {
      try {
        const pdfMeetingData = {
          meetingTitle: val?.meetingName,
          meetingDate: val?.meetingdate,
          meetingOwner: val?.createdBy?.username,
          meetingVenue: meetingDataById?.venue,
          participants: val?.participants,
          actionPointsData: actionPointsPdfData,
        };
        const tableHeaderStyle = "color: #003566;";
        const tableBg = "background-color: #D5F5E3;";
        const tableTitles =
          "color: #003566; font-size: 15px !important; font-weight: 900;";
        const headers =
          "text-align: center; margin: auto; font-size: 22px; font-weight: 600; letter-spacing: 0.6px; color: #003566;";
        let consolidated = `<html>
        <head>
          <title>meeting pdf</title>
          <link rel="preconnect" href="https://fonts.googleapis.com">
           <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
          <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">
          <style>
            * {
              font-family: 'Poppins', sans-serif;
            }
    
            table {
              border-collapse: collapse;
              width: 100%;
              margin-bottom: 20px;
            }
            td,
            th {
              border: 1px solid black;
              padding: 8px;
              text-align: left;
              font-size: 15px !important;
            },
          </style>
        </head>
        <body>
         <div>
         <table>
         <tr>
           <td style="width: 100px;">
             <img src="${HindalcoLogoSvg}" alt="Hindalco Logo" width="100px" height="100px" />
           </td>
           <td colspan="3"  style="${headers}">
             HINDALCO INDUSTRIES LIMITED<br />
             MINUTES OF MEETING
           </td>
         </tr>
         <tr>
           <td colspan="1" style="${tableTitles}>
             <b style="font-size: 15px !important;">  TITLE </b> 
           </td>
           <td colspan="3">${pdfMeetingData?.meetingTitle}</td>
         </tr>
         <tr>
           <td colspan="1" style="${tableTitles}>
             <b style="font-size: 15px !important;">  DATE </b> : 
           </td>
           <td colspan="3">${pdfMeetingData?.meetingDate
             .split("T")[0]
             .split("-")
             .reverse()
             .join("-")}</td>
         </tr>
         <tr>
         <td colspan="1" style="${tableTitles}>
           <b style="font-size: 15px !important;">  OWNER </b> 
         </td>
         <td colspan="3">${pdfMeetingData?.meetingOwner}</td>
       </tr>
       <tr>
       <td colspan="1" style="${tableTitles}>
         <b style="font-size: 15px !important;">  VENUE </b>
       </td>
       <td colspan="3"> ${pdfMeetingData?.meetingVenue}</td>
     </tr>
     <tr>
     <td colspan="1" style="${tableTitles}>
       <b style="font-size: 15px !important;"> PARTICIPANTS </b>
     </td>
     <td colspan="3">
     ${val?.createdBy?.username}
     </td>
    </tr>
    </table>
     <table>
     <thead>
      <tr style="${tableBg}">
      <th style="${tableHeaderStyle}">AGENDA</th>
      <th style="${tableHeaderStyle}">DECISION POINT</th>
      <th style="${tableHeaderStyle}">ACTION ITEM</th>
      <th style="${tableHeaderStyle}">OWNER</th>
      <th style="${tableHeaderStyle}">DUE BY</th>
      </tr>
      <div>
      </thead>
      <tbody>
      ${actionPointsPdfData.map(
        (item: any) => `<tr>
      <td>${item?.agenda}</td>
      <td>${item?.decisionPoint}</td>
      <td>${item?.actionPoint}</td>
      <td>${item?.owner?.map((item: any) => item?.username)}</td>
      <td>${item?.dueDate.split("-")[2].split("T")[0]}-${
          item?.dueDate.split("-")[1]
        }-${item?.dueDate.split("-")[0]}</td>
     </tr> `
      )}
      </tbody>
      </div>
   </table>
         </div>
        </body>
      </html>`;
        printJS({
          type: "raw-html",
          printable: consolidated,
        });
      } catch (err) {
        console.log(err);
      }
    }
  };

  return (
    <>
      {/* <Box
        sx={{ width: "100%", bgcolor: "background.paper", marginTop: "8px" }}
      >
        <div className={classes.tabWrapper}>
          <Tabs
            value={value}
            onChange={handleChange}
            indicatorColor="primary"
            textColor="primary"
            style={{ marginLeft: "2px" }}
          >
            <Tab
              onClick={() => {
                setFilter((prev) => (prev === "mydocuments" ? "" : ""));
                setSearchValue("");
              }}
              label={
                <>
                  <MRMLogo
                    // fill={value === 0 ? "#334D6E" : "#000"}
                    className={classes.docNavIconStyle}
                  />
                  <span
                    className={`${classes.docNavText} ${
                      value === 0 ? classes.selectedTab : ""
                    }`}
                    style={{ marginLeft: "8px" }}
                  >
                    MRM LIST
                  </span>
                </>
              }
            />
            <Divider type="vertical" className={classes.docNavDivider} />
            <Tab
              onClick={() => {
                setFilter("myDistributedDocuments");
                setSearchValue("");
              }}
              label={
                <>
                  <ActionPointIcon
                    // fill={value === 1 ? "#334D6E" : "#000"}
                    className={classes.docNavIconStyle}
                  />
                  <span
                    className={`${classes.docNavText}
                     ${value === 1 ? classes.selectedTab : ""}`}
                    style={{ marginLeft: "5px" }}
                  >
                    ACTION POINTS
                  </span>
                </>
              }
            />
            <Divider type="vertical" className={classes.docNavDivider} />

            <Tab
              // onClick={() => navigate("/mrm/keyagenda")}
              label={
                <>
                  <KeyAgendaIcon
                    // fill={value === 1 ? "#334D6E" : "#000"}
                    className={classes.docNavIconStyle}
                  />
                  <span
                    className={`${classes.docNavText}
                     ${value === 4 ? classes.selectedTab : ""}`}
                    style={{ marginLeft: "5px" }}
                  >
                    KEY AGENDA
                  </span>
                </>
              }
            />
          </Tabs>
        </div>
      </Box> */}
      <Box
        sx={{ width: "100%", bgcolor: "background.paper", marginTop: "10px" }}
      >
        <div className={classes.tabWrapper}>
          <div
            style={{ display: "flex", alignItems: "center", padding: "8px" }}
          >
            <div
              onClick={() => setValue(5)} // You can add the onClick logic here
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                padding: "4px 10px",
                cursor: "pointer",
                borderRadius: "5px",
                position: "relative",
                backgroundColor: value === 5 ? "#3576BA" : "",
              }}
            >
              <KeyAgendaIcon
                className={classes.docNavIconStyle}
                stroke={value === 5 ? "white" : ""}
              />
              <span
                className={`${classes.docNavText} ${
                  value === 5 ? classes.selectedTab : ""
                }`}
                style={{
                  marginLeft: "5px",
                  color: value === 5 ? "white" : "black",
                }}
              >
                MRM Plan
              </span>
              {value === 5 && (
                <SelectedTabArrow
                  style={{
                    position: "absolute",
                    bottom: -13,
                    left: "53%",
                    transform: "translateX(-50%)",
                    width: 13,
                    height: 11,
                  }}
                />
              )}
            </div>
            <div
              onClick={() => {
                setFilter("mydocuments");
                setSearchValue("");
                setValue(0);
              }}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                padding: "4px 10px",
                cursor: "pointer",
                borderRadius: "5px",
                position: "relative",
                backgroundColor: value === 0 ? "#3576BA" : "",
              }}
            >
              <MRMLogo
                className={classes.docNavIconStyle}
                fill={value === 0 ? "white" : "none"}
              />
              <span
                className={`${classes.docNavText} ${
                  value === 0 ? classes.selectedTab : ""
                }`}
                style={{
                  marginLeft: "8px",
                  color: value === 0 ? "white" : "black",
                }}
              >
                MRM Schedule
              </span>
              {value === 0 && (
                <SelectedTabArrow
                  style={{
                    position: "absolute",
                    bottom: -13,
                    left: "53%",
                    transform: "translateX(-50%)",
                    width: 13,
                    height: 11,
                  }}
                />
              )}
            </div>
            <div
              onClick={() => setValue(1)} // You can add the onClick logic here
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                padding: "4px 10px",
                cursor: "pointer",
                borderRadius: "5px",
                position: "relative",
                backgroundColor: value === 1 ? "#3576BA" : "",
              }}
            >
              <KeyAgendaIcon
                className={classes.docNavIconStyle}
                stroke={value === 1 ? "white" : ""}
              />
              <span
                className={`${classes.docNavText} ${
                  value === 1 ? classes.selectedTab : ""
                }`}
                style={{
                  marginLeft: "5px",
                  color: value === 1 ? "white" : "black",
                }}
              >
                Meetings
              </span>
              {value === 1 && (
                <SelectedTabArrow
                  style={{
                    position: "absolute",
                    bottom: -13,
                    left: "53%",
                    transform: "translateX(-50%)",
                    width: 13,
                    height: 11,
                  }}
                />
              )}
            </div>
            <div
              onClick={() => {
                setFilter("myDistributedDocuments");
                setSearchValue("");
                setValue(2);
              }}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                padding: "4px 10px",
                cursor: "pointer",
                borderRadius: "5px",
                position: "relative",
                backgroundColor: value === 2 ? "#3576BA" : "",
              }}
            >
              <ActionPointIcon
                className={classes.docNavIconStyle}
                stroke={value === 2 ? "white" : ""}
              />
              <span
                className={`${classes.docNavText} ${
                  value === 2 ? classes.selectedTab : ""
                }`}
                style={{
                  marginLeft: "5px",
                  color: value === 2 ? "white" : "black",
                }}
              >
                Action Points
              </span>
              {value === 2 && (
                <SelectedTabArrow
                  style={{
                    position: "absolute",
                    bottom: -13,
                    left: "53%",
                    transform: "translateX(-50%)",
                    width: 13,
                    height: 11,
                  }}
                />
              )}
            </div>
            <div
              onClick={() => {
                navigate("/mrm/MrmSettings");
              }} // You can add the onClick logic here
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                padding: "4px 10px",
                cursor: "pointer",
                borderRadius: "5px",
                position: "relative",
                backgroundColor: value === 6 ? "#3576BA" : "",
              }}
            >
              <OrgSettingsIcon
                // fill={tabFilter === "inWorkflow" ? "white" : "black"}
                className={classes.docNavIconStyle}
              />
              <span
                className={`${classes.docNavText} ${
                  value === 6 ? classes.selectedTab : ""
                }`}
                style={{
                  marginLeft: "5px",
                  color: value === 6 ? "white" : "black",
                }}
              >
                Settings
              </span>
              {value === 6 && (
                <SelectedTabArrow
                  style={{
                    position: "absolute",
                    bottom: -13,
                    left: "53%",
                    transform: "translateX(-50%)",
                    width: 13,
                    height: 11,
                  }}
                />
              )}
            </div>

            <ModuleHeader
              moduleName="Management Review Meeting"
              createHandler={
                value === 2 || value === 5 || value === 1
                  ? false
                  : createHandler
              }
              configHandler={configHandler}
              filterHandler={false}
              showSideNav={true}
            />
          </div>
        </div>
      </Box>
      <div className={classes.calenderView}>
        {value === 0 && (
          <div
            style={{
              display: "flex",
              width: "100%",
              alignItems: "center",
              // marginTop: "1%",
              justifyContent: "space-between",
            }}
          >
            <>
              <Grid item xs={8} md={4}>
                <div style={{ display: "flex", flexDirection: "row" }}>
                  <FormControl variant="outlined">
                    <div style={{ width: "250px" }}>
                      <Autocomplete
                        disablePortal
                        id="combo-box-demo"
                        options={[allOption, ...locationOptions]}
                        onChange={handleLocation}
                        value={getSelectedItem()}
                        getOptionLabel={(option) => option.locationName || ""}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            variant="outlined"
                            size="small"
                            label="Units"
                            fullWidth
                          />
                        )}
                      />
                    </div>
                  </FormControl>
                  <YearComponent
                    currentYear={currentYear}
                    setCurrentYear={setCurrentYear}
                  />
                </div>
              </Grid>
            </>

            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "end",
              }}
            >
              {/* <Box
                display="flex"
                justifyContent="flex-end"
                alignItems="center"
                style={{ marginRight: "15px" }}
              > */}
              {/* <MrmIcon className={classes.icon} onClick={handleOpenModal} />
                <div className={classes.mrmtext} onClick={handleOpenModal}>
                  MRM Plan
                </div> */}
              {/* </Box> */}
              {/* <Box
                display="flex"
                justifyContent="flex-end"
                alignItems="center"
                style={{ marginRight: "15px" }}
              >
                {viewCalendar ? (
                  <Tooltip title="Show Table" placement="top">
                    <TableChartIcon
                      style={{
                        cursor: "pointer",
                        height: "31px",
                        width: "30px",
                        marginRight: "10px",
                      }}
                      onClick={() => setViewCalendar(!viewCalendar)}
                    />
                  </Tooltip>
                ) : (
                  <Tooltip title="Show Calendar" placement="top">
                    <CalendarIcon
                      className={classes.icon}
                      style={{ display: "flex", alignItems: "center" }}
                      onClick={() => setViewCalendar(!viewCalendar)}
                    />
                  </Tooltip>
                )}
              </Box> */}
              {/* <Tooltip title="View Calendar" placement="top">
            </Tooltip> */}
              <Paper
                style={{
                  width: "285px",
                  height: "33px",
                  float: "right",
                  margin: "11px",
                  borderRadius: "20px",
                  border: "1px solid #dadada",
                  overflow: "hidden",
                }}
                component="form"
                data-testid="search-field-container"
                elevation={0}
                variant="outlined"
                className={classes.root}
                onSubmit={(e) => {
                  e.preventDefault();
                  handleCheck("mrm");
                }}
              >
                <TextField
                  // className={classes.input}
                  name={"search"}
                  value={searchValue}
                  placeholder={"Search"}
                  onChange={handleSearchChange}
                  inputProps={{
                    "data-testid": "search-field",
                  }}
                  InputProps={{
                    disableUnderline: true,
                    startAdornment: (
                      <InputAdornment
                        position="start"
                        className={classes.iconButton}
                      >
                        <img src={SearchIcon} alt="search" />
                      </InputAdornment>
                    ),
                    endAdornment: (
                      <>
                        {searchValue && (
                          <InputAdornment position="end">
                            <IconButton onClick={handleClickDiscard}>
                              <CloseIcon fontSize="small" />
                            </IconButton>
                          </InputAdornment>
                        )}
                      </>
                    ),
                  }}
                />
              </Paper>
            </div>
          </div>
        )}
      </div>

      {!value && !viewCalendar && (
        <div className={classes.tableContainer}>
          <Table
            className={classes.documentTable}
            rowClassName={() => "editable-row"}
            bordered
            dataSource={dataSource}
            columns={columns}
            pagination={false}
            // expandable={{
            //   expandedRowRender: (record) => (
            //     <Table
            //       className={classes.subTableContainer}
            //       style={{ width: 800 }}
            //       columns={subColumns}
            //       bordered
            //       dataSource={
            //         record?.value?.actionPointdata &&
            //         record?.value?.actionPointdata?.length
            //           ? record?.value?.actionPointdata
            //           : []
            //       }
            //       pagination={false}
            //     />
            //   ),
            // }}
          />
          <div className={classes.pagination}>
            <Pagination
              size="small"
              current={pageMrm}
              pageSize={pageLimitMrm}
              total={count}
              showTotal={showTotal}
              showSizeChanger
              showQuickJumper
              onChange={(page, pageSize) => {
                handlePagination(page, pageSize);
              }}
            />
          </div>
        </div>
      )}
      {value === 2 && (
        <div>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              width: "100%",
            }}
          >
            <>
              <Grid item xs={8} md={4}>
                <FormControl variant="outlined" size="small" fullWidth>
                  <div className={classes.locSearchBox}>
                    <Autocomplete
                      disablePortal
                      id="combo-box-demo"
                      options={[allOption, ...locationOptions]}
                      onChange={handleActionLocation}
                      value={getSelectedActionItem()}
                      getOptionLabel={(option) => option.locationName || ""}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          variant="outlined"
                          size="small"
                          label="Units"
                          fullWidth
                        />
                      )}
                    />
                  </div>
                </FormControl>
              </Grid>
              <Grid item xs={6} md={3}>
                <YearComponent
                  currentYear={currentYear}
                  setCurrentYear={setCurrentYear}
                />
              </Grid>
            </>

            <div
              className={classes.root}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "end",
              }}
            >
              <div
                style={{
                  display: "flex",
                  justifyContent: "end",
                  marginRight: "10px",
                }}
              >
                <Tooltip title="My Action Points">
                  <IconButton
                    onClick={() => {
                      setOpenAction(!openAction);
                    }}
                  >
                    {openAction ? (
                      <PermContactCalendar
                        style={{
                          color: "rgb(53, 118, 186)",
                          height: "31px",
                          width: "30px",
                        }}
                      />
                    ) : (
                      <PermContactCalendarOutlinedIcon
                        style={{ color: "#444", height: "31px", width: "30px" }}
                      />
                    )}
                  </IconButton>
                </Tooltip>
              </div>
              <Paper
                style={{
                  width: "285px",
                  height: "33px",
                  float: "right",
                  margin: "11px",
                  borderRadius: "20px",
                  border: "1px solid #dadada",
                  overflow: "hidden",
                }}
                component="form"
                data-testid="search-field-container"
                elevation={0}
                variant="outlined"
                className={classes.root}
                onSubmit={(e) => {
                  e.preventDefault();
                  handleActionPointSearch(searchActionPointValue);
                }}
              >
                <TextField
                  // className={classes.input}
                  name={"search"}
                  value={searchActionPointValue}
                  placeholder={"Search"}
                  onChange={handleActionPointSearchChange}
                  inputProps={{
                    "data-testid": "search-field",
                  }}
                  InputProps={{
                    disableUnderline: true,
                    startAdornment: (
                      <InputAdornment
                        position="start"
                        className={classes.iconButton}
                      >
                        <img src={SearchIcon} alt="search" />
                      </InputAdornment>
                    ),
                    endAdornment: (
                      <>
                        {searchActionPointValue && (
                          <InputAdornment position="end">
                            <IconButton onClick={handleClickDiscard}>
                              <CloseIcon fontSize="small" />
                            </IconButton>
                          </InputAdornment>
                        )}
                      </>
                    ),
                  }}
                />
              </Paper>
            </div>
          </div>
          <div className={classes.tableContainer}>
            <Table
              className={classes.documentTable}
              rowClassName={() => "editable-row"}
              bordered
              dataSource={actionPointDataSource}
              columns={actionPointColumns}
              pagination={false}
            />
            <div className={classes.pagination}>
              <Pagination
                size="small"
                current={pageAction}
                pageSize={pageLimitAction}
                total={countAction}
                showTotal={showTotalAction}
                showSizeChanger
                showQuickJumper
                onChange={(page, pageSize) => {
                  handlePaginationAction(page, pageSize);
                }}
              />
            </div>
          </div>
        </div>
      )}
      {/* {value === 4 && (
        <MRMKeyAgenda
          setAddKeyAgenda={setAddKeyAgenda}
          addKeyAgenda={addKeyAgenda}
        />
      )} */}
      {value === 5 && (
        <div>
          <div
            style={{
              display: "flex",
              paddingTop: "10px",
              justifyContent: "space-between",
            }}
          >
            <div style={{ display: "flex" }}>
              <FormControl
                variant="outlined"
                className={classes.formControl}
                size="small"
              >
                <InputLabel id="demo-simple-select-outlined-label">
                  Units
                </InputLabel>
                <Select
                  labelId="demo-simple-select-outlined-label"
                  id="demo-simple-select-outlined"
                  value={selectedUnit}
                  onChange={handleChangeUnit}
                  label="Units"
                >
                  {units &&
                    units.length &&
                    units.map((data: any) => {
                      return (
                        <MenuItem value={data?.id} key={data?.id}>
                          {data?.locationName}
                        </MenuItem>
                      );
                    })}
                </Select>
              </FormControl>
              {systemData && systemData.length > 0 && (
                <div style={{ display: "flex", justifyContent: "center" }}>
                  <FormControl
                    variant="outlined"
                    className={classes.formControl}
                    size="small"
                  >
                    <InputLabel id="demo-simple-select-outlined-label">
                      System
                    </InputLabel>
                    <Select
                      labelId="demo-simple-select-outlined-label"
                      id="demo-simple-select-outlined"
                      value={selectedSystem}
                      multiple
                      onChange={handleChangeSystem}
                      label="System"
                    >
                      {systemData?.map((data: any) => {
                        return (
                          <MenuItem value={data?.id} key={data?.id}>
                            {data?.name}
                          </MenuItem>
                        );
                      })}
                    </Select>
                  </FormControl>
                  {/* <FormControl variant="outlined" className={classes.formControl} size='small'> */}
                  <YearComponent
                    currentYear={currentYear}
                    setCurrentYear={setCurrentYear}
                  />
                  {/* </FormControl> */}
                </div>
              )}
            </div>
            {submitButtonStatus && (
              <div
                style={{
                  display: "flex",
                  justifyContent: "flex-end",
                  paddingRight: "20px",
                  paddingTop: "10px",
                }}
              >
                <Button
                  style={{
                    backgroundColor: "rgb(0, 48, 89)",
                    color: "#fff",
                  }}
                  onClick={() => {
                    handleOk();
                  }}
                >
                  Submit
                </Button>
              </div>
            )}
          </div>
          <div style={{ height: "100%", overflowY: "scroll" }}>
            <div
              className={classes.tableContainer}
              style={{ paddingBottom: "40px" }}
            >
              <Table
                bordered
                dataSource={dataSourceMrm}
                columns={addMonthyColumns}
                pagination={false}
                className={classes.documentTable}
                rowClassName={() => "editable-row"}
              />
            </div>
            <div className={classes.pagination}>
              <Pagination
                size="small"
                current={pagePlan}
                pageSize={rowsPerPagePlan}
                total={countPlan}
                showTotal={showTotalPlan}
                showSizeChanger
                showQuickJumper
                onChange={(page, pageSize) => {
                  handlePaginationPlan(page, pageSize);
                }}
              />
            </div>
          </div>
        </div>
      )}
      {openModal?.open && (
        <MrmModal openModal={openModal} handleCloseModal={handleCloseModal} />
      )}
      {openScheduleDrawer && (
        <ScheduleDrawer
          openScheduleDrawer={openScheduleDrawer}
          expandDataValues={expandDataValues}
          handleDrawer={handleDrawer}
          mode={mode}
          mrm={true}
          scheduleData={scheduleData}
          unitSystemData={unitSystemData}
          mrmEditOptions={mrmEditOptions}
          status={statusMode}
          setStatusMode={setStatusMode}
        />
      )}
      {openActionPointDrawer.open && (
        <ActionPoint
          openActionPointDrawer={openActionPointDrawer}
          setOpenActionPointDrawer={setOpenActionPointDrawer}
          handleCloseActionPoint={handleCloseActionPoint}
        />
      )}

      {openActionPointEditDrawer?.open && (
        // <EditActionPoint
        //   openActionPointEditDrawer={openActionPointEditDrawer}
        //   setOpenActionPointEditDrawer={setOpenActionPointEditDrawer}
        //   handleCloseActionPoint={handleCloseActionPoint}
        // />
        <></>
      )}

      {viewCalendar && !value && (
        <div className={classes.tableContainer}>
          <CalendarMRM
            events={calendarData}
            toggleCalendarModal={toggleCalendarModal}
            calendarFor="MRM"
          />
          <CalendarModal
            calendarData={calendarData}
            calendarModalInfo={calendarModalInfo}
            toggleCalendarModal={toggleCalendarModal}
          />
        </div>
      )}
      {value === 1 && (
        <>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              width: "100%",
            }}
          >
            <>
              <Grid item xs={8} md={4}>
                <FormControl variant="outlined" size="small" fullWidth>
                  <div className={classes.locSearchBox}>
                    <Autocomplete
                      disablePortal
                      id="combo-box-demo"
                      options={[allOption, ...locationOptions]}
                      onChange={handleMeetingLocation}
                      value={getSelectedMeetingItem()}
                      getOptionLabel={(option) => option.locationName || ""}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          variant="outlined"
                          size="small"
                          label="Units"
                          fullWidth
                        />
                      )}
                    />
                  </div>
                </FormControl>
              </Grid>
              <Grid item xs={6} md={3}>
                <YearComponent
                  currentYear={currentYear}
                  setCurrentYear={setCurrentYear}
                />
              </Grid>
            </>

            <div
              className={classes.root}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "end",
              }}
            >
              <Tooltip title="My Meetings">
                <IconButton
                  onClick={() => {
                    setOpenMeeting(!openMeeting);
                  }}
                >
                  {openMeeting ? (
                    <PermContactCalendar
                      style={{
                        color: "rgb(53, 118, 186)",
                        height: "31px",
                        width: "30px",
                      }}
                    />
                  ) : (
                    <PermContactCalendarOutlinedIcon
                      style={{ color: "#444", height: "31px", width: "30px" }}
                    />
                  )}
                </IconButton>
              </Tooltip>
              <Paper
                style={{
                  width: "285px",
                  height: "33px",
                  float: "right",
                  margin: "11px",
                  borderRadius: "20px",
                  border: "1px solid #dadada",
                  overflow: "hidden",
                }}
                component="form"
                data-testid="search-field-container"
                elevation={0}
                variant="outlined"
                className={classes.root}
                onSubmit={(e) => {
                  e.preventDefault();
                  handleMeetingSearch(searchMeetingValue);
                }}
              >
                <TextField
                  // className={classes.input}
                  name={"search"}
                  value={searchMeetingValue}
                  placeholder={"Search"}
                  onChange={handleMeetingSearchChange}
                  inputProps={{
                    "data-testid": "search-field",
                  }}
                  InputProps={{
                    disableUnderline: true,
                    startAdornment: (
                      <InputAdornment
                        position="start"
                        className={classes.iconButton}
                      >
                        <img src={SearchIcon} alt="search" />
                      </InputAdornment>
                    ),
                    endAdornment: (
                      <>
                        {searchValue && (
                          <InputAdornment position="end">
                            <IconButton onClick={handleClickDiscard}>
                              <CloseIcon fontSize="small" />
                            </IconButton>
                          </InputAdornment>
                        )}
                      </>
                    ),
                  }}
                />
              </Paper>
            </div>
          </div>
          <div className={classes.tableContainer}>
            <Table
              className={classes.documentTable}
              rowClassName={() => "editable-row"}
              bordered
              dataSource={meetingsDataApi}
              columns={meetingsTableHeaders}
              pagination={false}
              //  expandable={{
              //    expandedRowRender: (record) => (
              //      <Table
              //        className={classes.subTableContainer}
              //        style={{ width: 800 }}
              //        columns={subColumns}
              //        bordered
              //        dataSource={
              //          record?.value?.actionPointdata &&
              //          record?.value?.actionPointdata.length
              //            ? record?.value?.actionPointdata
              //            : []
              //        }
              //        pagination={false}
              //      />
              //    ),
              //  }}
            />
            <div className={classes.pagination}>
              <Pagination
                size="small"
                current={page}
                pageSize={pageLimit}
                total={countMeeting}
                showTotal={showTotalMeeting}
                showSizeChanger
                showQuickJumper
                onChange={(page, pageSize) => {
                  handlePaginationMeeting(page, pageSize);
                }}
              />
            </div>
          </div>
        </>
      )}
      <MrmAddMeetings
        open={drawerOpen}
        setDrawerOpen={setDrawerOpen}
        onClose={handleDrawerClose}
        dataSourceFilter={dataSourceFilter}
        valueById={valueById}
        year={currentYear}
        meeting={true}
        setLoadMeeting={setLoadMeeting}
      />
      <MrmEditingMeetings
        open={editDrawerOpen}
        onClose={handleEditDrawerClose}
        dataSourceFilter={dataSourceFilter && dataSourceFilter}
        editDataMeeting={editDataMeeting && editDataMeeting}
        ownerSourceFilter={ownerSourceFilter && ownerSourceFilter}
        valueById={valueById}
        year={currentYear}
        readMode={readMode}
        meeting={true}
        setLoadMeeting={setLoadMeeting}
      />
      <div>
        <AddMrmActionPoint
          open={mrmActionPointAdd}
          onClose={handlerActionAddClose}
          addNew={true}
          dataSourceFilter={mrmActionId && mrmActionId}
          setAgendaData={undefined}
          agendaData={undefined}
          setFormData={undefined}
          formData={undefined}
          year={currentYear}
          setLoadActionPoint={setLoadActionPoint}
        />
        <EditMrmActionPoint
          open={mrmActionPointEdit}
          onClose={handlerActionEditClose}
          addNew={true}
          dataSourceFilter={mrmActionId && mrmActionId}
          setAgendaData={undefined}
          agendaData={undefined}
          setFormData={undefined}
          formData={undefined}
          actionRowData={actionRowData}
          year={currentYear}
          valueById={undefined}
          data={undefined}
          readMode={readMode}
          setLoadActionPoint={setLoadActionPoint}
        />
      </div>
    </>
  );
};
export default MRM;
