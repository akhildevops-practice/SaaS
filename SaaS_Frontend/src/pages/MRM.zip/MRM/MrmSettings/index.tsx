import { ReactComponent as AllDocIcon } from "../../../assets/documentControl/All-Doc.svg";
import { makeStyles, Theme } from "@material-ui/core/styles";
import ModuleNavigation from "components/Navigation/ModuleNavigation";
import Location from "pages/MasterHomePage/Location";
import Departments from "../../MasterHomePage/Departments";
import UserMaster from "../../MasterHomePage/UserMaster";
import MasterRoles from "../../MasterHomePage/MasterRoles";
import SystemMaster from "../../MasterHomePage/SystemMaster";
import UnitMaster from "../../MasterHomePage/UnitMaster";
import ModuleHeader from "../../../components/Navigation/ModuleHeader";
import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import AuditType from "../../AuditType";
import Template from "../../Template";
import FocusArea from "../../FocusArea";
import AuditorProfile from "../../AuditorProfile";
import Proficiency from "pages/Proficiency";
import MRMKeyAgenda from "../MRMKeyAgenda";
import checkRoles from "utils/checkRoles";

const useStyles = makeStyles<Theme>((theme: Theme) => ({
  docNavIconStyle: {
    width: "21.88px",
    height: "21px",
    paddingRight: "6px",
    cursor: "pointer",
  },
}));
const MrmSettings = () => {
  const [currentModuleName, setCurrentModuleName] = useState("Unit Management");
  const [addKeyAgenda, setAddKeyAgenda] = useState<boolean>(false);
  const [acitveTab, setActiveTab] = useState<any>("1");
  const classes = useStyles();
  const location = useLocation();
  const navigate = useNavigate();
  const userDetail = JSON.parse(sessionStorage.getItem("userDetails") || "{}");
  const isOrgAdmin = checkRoles("ORG-ADMIN");
  const isMR = checkRoles("MR");
  const showData = isOrgAdmin || isMR;

  useEffect(() => {
    if (!!location.state) {
      if (location?.state?.redirectToTab === "AUDIT CHECKLIST") {
        setActiveTab("2");
      } else if (location?.state?.redirectToTab === "FOCUS AREAS") {
        setActiveTab("3");
      } else if (location?.state?.redirectToTab === "PROFICIENCIES") {
        setActiveTab("4");
      } else if (location?.state?.redirectToTab === "AUDITOR PROFILE") {
        setActiveTab("5");
      }
    } else {
      setActiveTab("1");
    }
  }, [location]);


  const tabs = [
    {
      key: "1",
      name: "Meeting Types",
      // path: "/master/unit", //just for information
      icon: (
        <AllDocIcon
          style={{
            fill: acitveTab === "1" ? "white" : "",
          }}
          className={classes.docNavIconStyle}
        />
      ),
      children: <MRMKeyAgenda
      setAddKeyAgenda={setAddKeyAgenda}
      addKeyAgenda={addKeyAgenda}
    />,
      moduleHeader: "Meeting Type Management",
    },
    // {
    //   key: "2",
    //   name: "Audit Checklist",
    //   // path: "/master/department",
    //   icon: (
    //     <AllDocIcon
    //       style={{
    //         fill: acitveTab === "2" ? "white" : "",
    //       }}
    //       className={classes.docNavIconStyle}
    //     />
    //   ),
    //   children: <Template />,
    //   moduleHeader: "Audit CheckList Management",
    // },
    // {
    //   key: "3",
    //   name: "Focus Areas",
    //   // path: "/master/user",
    //   icon: (
    //     <AllDocIcon
    //       style={{
    //         fill: acitveTab === "3" ? "white" : "",
    //       }}
    //       className={classes.docNavIconStyle}
    //     />
    //   ),
    //   children: <FocusArea />,
    //   moduleHeader: "Focus Area Management",
    // },
    // {
    //   key: "4",
    //   name: "Proficiencies",
    //   // path: "/master/user",
    //   icon: (
    //     <AllDocIcon
    //       style={{
    //         fill: acitveTab === "4" ? "white" : "",
    //       }}
    //       className={classes.docNavIconStyle}
    //     />
    //   ),
    //   children: <Proficiency />,
    //   moduleHeader: "Proficiency Management",
    // },
    // {
    //   key: "5",
    //   name: "Auditor Profile",
    //   // path: "/master/roles",
    //   icon: (
    //     <AllDocIcon
    //       style={{
    //         fill: acitveTab === "5" ? "white" : "",
    //       }}
    //       className={classes.docNavIconStyle}
    //     />
    //   ),
    //   children: <AuditorProfile />,
    //   moduleHeader: "Auditor Profile Management",
    // },
  ];

  const createHandler = () => {
    if(acitveTab === "1"){
      if (showData) {
        setAddKeyAgenda(true);
      }
    } 
  }

  return (
    <>
      <div>
        <ModuleNavigation
          tabs={tabs}
          activeTab={acitveTab}
          setActiveTab={setActiveTab}
          currentModuleName={currentModuleName}
          setCurrentModuleName={setCurrentModuleName}
          createHandler={showData && (createHandler)}
          mainModuleName={"Mrm Settings"}
        />
         {/* <ModuleHeader moduleName={"Mrm Settings"} createHandler={createHandler} /> */}
      </div>
    </>
  );
};

export default MrmSettings;
