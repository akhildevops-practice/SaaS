import React, { useEffect, useState } from "react";
import PropTypes from "prop-types";
import {
  Box,
  Button,
  Drawer,
  IconButton,
  InputBase,
  TableCell,
  TableRow,
  makeStyles,
  Grid,
} from "@material-ui/core";
import { CheckBox, Delete, Edit } from "@material-ui/icons";
import CloseIcon from "@material-ui/icons/Close";
import {
  createAgenda,
  deleteAgenda,
  getAgendaByMeetingType,
  updateAgenda,
} from "apis/mrmagendapi";
import { useRecoilValue } from "recoil";
import { orgFormData } from "recoil/atom";
import useStyles from "../MRMKeyAgenda.style";
import { Col, Form, Input, Row, Table, Popconfirm } from "antd";
import { ReactComponent as CustomEditIcon } from "assets/documentControl/Edit.svg";
import { ReactComponent as CustomDeleteICon } from "assets/documentControl/Delete.svg";
import { useSnackbar } from "notistack";

type Props = {
  open: boolean;
  onClose: () => void;
  meetingType: any;
  selectedData: any;
};
const drawerWidth = 600;

const useStylesClass = makeStyles((theme) => ({
  formTextPadding: {
    paddingBottom: theme.typography.pxToRem(10),
    fontSize: theme.typography.pxToRem(14),
    color: "#003566",
  },
  asterisk: {
    color: "red",
    verticalAlign: "end",
  },
  labelStyle: {
    "& .ant-input-lg": {
      border: "1px solid #dadada",
    },
    "& .ant-form-item .ant-form-item-label > label": {
      color: "#003566",
      fontWeight: "bold",
      letterSpacing: "0.8px",
    },
  },

  label: {
    verticalAlign: "middle",
  },
  drawerPaper: {
    width: drawerWidth,
    flexShrink: 0,
    "& .MuiDrawer-paper": {
      width: drawerWidth,
      boxSizing: "border-box",
    },
  },
  documentTable: {
    "&::-webkit-scrollbar-thumb": {
      borderRadius: "10px",
      backgroundColor: "grey",
    },
  },
  tableContainer: {
    paddingLeft: "10px",
    paddingRight: "10px",
    marginTop: "1%",
    maxHeight: "calc(60vh - 14vh)", // Adjust the max-height value as needed
    overflowY: "auto",
    overflowX: "hidden",
    // fontFamily: "Poppins !important",
    "& .ant-table-wrapper .ant-table.ant-table-bordered > .ant-table-container > .ant-table-summary > table > tfoot > tr > td":
      {
        borderInlineEnd: "none",
      },
    "& .ant-table-thead .ant-table-cell": {
      backgroundColor: "#E8F3F9",
      // fontFamily: "Poppins !important",
      color: "#00224E",
    },
    "& span.ant-table-column-sorter-inner": {
      color: "#00224E",
      // color: ({ iconColor }) => iconColor,
    },
    "& span.ant-tag": {
      display: "flex",
      width: "89px",
      padding: "5px 0px",
      justifyContent: "center",
      alignItems: "center",
      borderRadius: "10px",
      color: "white",
    },
    "& .ant-table-wrapper .ant-table-thead>tr>th": {
      position: "sticky", // Add these two properties
      top: 0, // Add these two properties
      zIndex: 2,
      // padding: "12px 16px",
      fontWeight: 600,
      fontSize: "14px",
      padding: "6px 8px !important",
      // fontFamily: "Poppins !important",
      lineHeight: "24px",
    },
    "& .ant-table-tbody >tr >td": {
      // borderBottom: ({ tableColor }) => `1px solid ${tableColor}`, // Customize the border-bottom color here
      borderBottom: "black",
      padding: "4px 8px !important",
    },
    // '& .ant-table-wrapper .ant-table-container': {
    //     maxHeight: '420px', // Adjust the max-height value as needed
    //     overflowY: 'auto',
    //     overflowX: 'hidden',
    // },
    "& .ant-table-body": {
      // maxHeight: '150px', // Adjust the max-height value as needed
      // overflowY: 'auto',
      "&::-webkit-scrollbar": {
        width: "8px",
        height: "10px", // Adjust the height value as needed
        backgroundColor: "#e5e4e2",
      },
      "&::-webkit-scrollbar-thumb": {
        borderRadius: "10px",
        backgroundColor: "grey",
      },
    },
    "& tr.ant-table-row": {
      cursor: "pointer",
      transition: "all 0.1s linear",
    },
  },
}));

function MrmAgendaCreate({ open, onClose, meetingType, selectedData }: Props) {
  const [formDataAgendaData, setFormDataAgendaData] = useState<any>([]);
  const [formDataAgenda, setFormDataAgenda] = useState<any>([
    {
      meetingType: "",
      name: "",
      organizationId: "",
    },
  ]);
  const [textValue, setTextValue] = useState<any | null>("");
  const [editButton, setEditButton] = useState(false);
  const [textValueEdit, setTextValueEdit] = useState<any>();
  const [isEditing, setIsEditing] = useState(false);
  const [isEditIndex, setIsEditIndex] = useState<any>();
  const [isEditStatus, setEditStatus] = useState(false);
  const [isEditId, setIsEditId] = useState<any>();
  const [isAddAgenda, setIsAddAgenda] = useState(false);
  const { enqueueSnackbar } = useSnackbar();

  useEffect(() => {
    getAgendaDataMeetingById(selectedData);
  }, [selectedData]);

  const classes = useStyles();
  const classStylse = useStylesClass();

  const orgData = useRecoilValue(orgFormData);
  const organizationId =
    sessionStorage.getItem("orgId") !== null &&
    sessionStorage.getItem("orgId") !== "null"
      ? sessionStorage.getItem("orgId")
      : (orgData && orgData.organizationId) ||
        (orgData && orgData.id) ||
        undefined;

  const getAgendaDataMeetingById = (meetingType: any) => {
    getAgendaByMeetingType(meetingType._id).then((response: any) => {
      setFormDataAgendaData(response?.data);
      // if (response.data) {
      //  ;
      // } else {
      //   setFormDataAgendaData(formDataAgenda);
      // }
    });
  };

  const addAgenda = () => {
    if (formDataAgendaData.length === 0) {
      const FormValues = {
        name: textValue,
        organizationId: organizationId,
        meetingType: selectedData._id,
      };
      if (FormValues?.name) {
        setFormDataAgendaData([...formDataAgendaData, FormValues]);
        if (FormValues?.name) {
          createAgenda(FormValues).then((response: any) => {
            setTextValue("");
            setIsAddAgenda(false);
            if (response.status === 200 || response.status === 201) {
              enqueueSnackbar(`Agenda Added successfully!`, {
                variant: "success",
              });
            }
          });
        }
      } else {
        enqueueSnackbar(`Add Agenda name`, { variant: "error" });
      }
    } else {
      const FormValuesTy = {
        name: textValue,
        organizationId: organizationId,
        meetingType: selectedData._id,
      };
      if (FormValuesTy?.name) {
        setFormDataAgendaData([...formDataAgendaData, FormValuesTy]);

        createAgenda(FormValuesTy).then((response: any) => {
          setTextValue("");
          setIsAddAgenda(false);
          if (response.status === 200 || response.status === 201) {
            enqueueSnackbar(`Agenda Added successfully!`, {
              variant: "success",
            });
          }
        });
      } else {
        enqueueSnackbar(`Add Agenda name`, { variant: "error" });
      }
    }
  };


  const handleValuesEdit = (rowIndex: any) => {
    setEditStatus(true);
    setIsEditId(rowIndex);
    setTextValueEdit(formDataAgendaData[rowIndex].name);
  };
  const handleUpdateValues = (row: any, rowIndex: any) => {
    const FormValues = {
      name: textValueEdit,
    };
    const objectIndexToUpdate = rowIndex;
    if (
      objectIndexToUpdate >= 0 &&
      objectIndexToUpdate < formDataAgendaData.length
    ) {
      const updatedObject = {
        ...formDataAgendaData[objectIndexToUpdate],
        name: textValueEdit,
      };
      setFormDataAgendaData([
        ...formDataAgendaData.slice(0, objectIndexToUpdate),
        updatedObject,
        ...formDataAgendaData.slice(objectIndexToUpdate + 1),
      ]);
    }
    if (!!FormValues.name) {
      updateAgenda(row._id, FormValues).then((response: any) => {
        setEditStatus(false);
        setTextValueEdit("");
        if (response.status === 200 || response.status === 201) {
          enqueueSnackbar(`Data Added successfully!`, {
            variant: "success",
          });
        }
      });
    } else {
      enqueueSnackbar(`Add Agenda Name`, { variant: "error" });
    }
  };
  const handleDeleteRows = (row: any, rowIndex: any) => {
    deleteAgenda(row._id).then((response: any) => {
      if (response.status === 200 || response.status === 201) {
        enqueueSnackbar(`Deleted Schedule Successfully!`, {
          variant: "success",
        });
      }else{
        enqueueSnackbar(`errrr!`, {
          variant: "error",
        });
      }
    });
    const deleteAgendData = formDataAgendaData.filter(
      (ele: any, index: any) => index !== rowIndex
    );
    setFormDataAgendaData(deleteAgendData);
  };


  const TableRowData = [
    {
      title: "Agenda",
      dataIndex: "Agenda",
      width: 250,
      render: (_: any, data: any, index: any) => {
        return (
          <div>
            {isEditStatus && isEditId === index ? (
              <Input
                className={classes.editField}
                style={{ height: "30px", width: "100%" }}
                placeholder="Enter Agenda"
                value={textValueEdit}
                onChange={(e: any) => {
                  setTextValueEdit(e.target.value);
                }}
              />
            ) : (
              <div className={classes.inputButton}>{data.name}</div>
            )}
          </div>
        );
      },
    },
    {
      title: "Action",
      dataIndex: "AgendaAction",
      width: 40,
      render: (_: any, data: any, index: any) => {
        return (
          <div
            style={{
              padding: "0px !important",
              display: "flex",
              flexDirection: "row",
              gap: "15px",
            }}
          >
            <div style={{ padding: "0px !important" }}>
              {isEditStatus && isEditId === index ? (
                <CheckBox
                  style={{ fontSize: "18px" }}
                  onClick={(e) => {
                    handleUpdateValues(data, index);
                  }}
                />
              ) : (
                <CustomEditIcon
                  style={{ fontSize: "15px !important", height: "17px" }}
                  onClick={() => {
                    handleValuesEdit(index);
                  }}
                />
              )}
            </div>
            <div style={{ padding: "0px !important" }}>
            {isEditStatus && isEditId === index ? (
                          ""
                        ) : ( 
              <CustomDeleteICon
                style={{ fontSize: "15px !important", height: "17px" }}
                onClick={() => {
                  handleDeleteRows(data, index);
                }}
              />
               )}
            </div>
          </div>
        );
      },
    },
  ];

  return (
    <Drawer
      open={open}
      onClose={onClose}
      anchor="right"
      classes={{
        paper: classStylse.drawerPaper,
      }}
    >
      <div>
        <div
          style={{
            height: "50px",
            backgroundColor: "#e8f3f9",
            display: "flex",
            justifyContent: "flex-start",
            gap: "20px",
            paddingLeft: "10px",
            alignItems: "center",
          }}
        >
          <div style={{ border: "none" }}>
            <CloseIcon onClick={onClose} style={{ cursor: "pointer" }} />
          </div>
          <div style={{ fontSize: "20px", border: "none" }}>Add Agenda</div>
        </div>
        <div>
          <div>
            <div
              className={classes.ulContainer}
              style={{
                paddingTop: "5px",
                paddingBottom: "5px",
              }}
            >
              <TableCell
                style={{
                  border: "none",
                  fontSize: "18px",
                  display: "flex",
                  gap: "8px",
                  alignItems: "center",
                }}
              >
                <span> Meeting Type:</span>
                <span style={{ color: "#1677ff" }}>{selectedData?.name}</span>
              </TableCell>
            </div>
            <div
              style={{ borderBottom: "1px solid #F4F6F6", paddingTop: "10px" }}
            >
              {formDataAgenda &&
                formDataAgenda?.map((row: any, rowIndex: any) => (
                  <div>
                    <Row
                      gutter={[16, 16]}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <Col span={19}>
                        <Grid
                          item
                          sm={12}
                          md={5}
                          className={classStylse.formTextPadding}
                        >
                          <strong>
                            <span className={classStylse.asterisk}>*</span>{" "}
                            <span className={classStylse.label}>
                              Enter Agenda:{" "}
                            </span>
                          </strong>
                        </Grid>
                        <Form.Item>
                          <Input
                            style={{ height: "37px" }}
                            value={textValue}
                            placeholder="Enter Agenda"
                            onChange={(e: any) => {
                              setTextValue(e.target.value);
                            }}
                          />
                        </Form.Item>
                      </Col>
                      <Col span={4} style={{ paddingTop: "5px" }}>
                          <Button
                            style={{
                              backgroundColor: "#e8f3f9",
                              color: "block",
                            }}
                            onClick={() => {
                              addAgenda();
                            }}
                          >
                            Add
                          </Button>
                      </Col>
                    </Row>
                  </div>
                ))}
            </div>

            <div className={classStylse.tableContainer}>
              <Table
                className={classes.documentTable}
                rowClassName={() => "editable-row"}
                bordered
                dataSource={formDataAgendaData}
                columns={TableRowData}
                pagination={false}
              />
            </div>
          </div>
        </div>
      </div>
    </Drawer>
  );
}

MrmAgendaCreate.propTypes = {};

export default MrmAgendaCreate;
