import React, { useEffect, useRef, useState } from "react";
import {
  Form,
  Input,
  Row,
  Col,
  DatePicker,
  Select,
  Upload,
  Button,
  Space,
  Spin,
  Typography,
} from "antd";
import getAppUrl from "../../../utils/getAppUrl";
import axios from "../../../apis/axios.global";
import { useSnackbar } from "notistack";
import MyEditor from "../Editor";
import { Autocomplete } from "@material-ui/lab";
import MenuItem from "@material-ui/core/MenuItem";
import {
  Avatar,
  ListItem,
  ListItemAvatar,
  ListItemText,
  TextField,
  makeStyles,
  Collapse,
  TableCell,
  TableRow,
  TableHead,
  InputBase,
  IconButton,
  Table,
  TableContainer,
  TableBody,
  Box,
  Paper,
} from "@material-ui/core";
import { API_LINK } from "../../../config";
import { debounce } from "lodash";
import { MinusCircleOutlined, PlusOutlined } from "@ant-design/icons";
import ArrowDropDown from "../../../assets/TeamDropdown.svg";
import checkRoles from "../../../utils/checkRoles";
import { getAgendaByMeetingType } from "apis/mrmagendapi";
import { data } from "components/Doughnut";
import { AddCircle, CheckBox, Delete, Edit } from "@material-ui/icons";

const { TextArea } = Input;

type Props = {
  formData?: any;
  setFormData?: any;
  mode?: any;
  scheduleData: any;
  mrmEditOptions: any;
};

var typeAheadValue: string;
var typeAheadType: string;

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    "& .MuiAccordionDetails-root": {
      display: "block",
    },
  },
  table: {
    backgroundColor: "#FFFFFF",
    borderRadius: "9px",
    width: "100%",
    "& thead th": {
      padding: theme.spacing(2),
      backgroundColor: "#F7F7FF",
      color: theme.palette.primary.main,
      zIndex: 0,
    },
  },
  actionButtonTableCell: {
    fontSize: theme.typography.pxToRem(12),
    textAlign: "center",
    paddingTop: theme.spacing(0.1),
    paddingBottom: theme.spacing(0.1),
    height: theme.typography.pxToRem(2),
    borderBottom: "1px solid rgba(104, 104, 104, 0.1);",
    borderRight: "1px solid rgba(104, 104, 104, 0.1);",
    wordWrap: "break-word",
    maxWidth: "200px",
  },
  tableHeaderColor: {
    color: theme.palette.primary.main,
  },
  tableCell: {
    fontSize: theme.typography.pxToRem(12),
    paddingTop: theme.spacing(0.1),
    paddingBottom: theme.spacing(0.1),
    paddingLeft: theme.spacing(2), //removing for testing
    paddingRight: theme.spacing(2), //removing for testing
    height: theme.typography.pxToRem(2),
    borderBottom: "1px solid rgba(104, 104, 104, 0.1);",
    borderRight: "1px solid rgba(104, 104, 104, 0.1);",
    wordWrap: "break-word",
    maxWidth: "300px",
  },
  tableCellWithoutAction: {
    fontSize: theme.typography.pxToRem(12),
    height: theme.typography.pxToRem(10),
    borderBottom: "1px solid rgba(104, 104, 104, 0.1);",
    borderRight: "1px solid rgba(104, 104, 104, 0.1);",
  },

  editField: {
    fontSize: theme.typography.pxToRem(12),
    width: "100%",
    borderBottom: "0.5px solid black",
  },
  addField: {
    width: "100%",
    borderRadius: "6px",
    fontSize: theme.typography.pxToRem(12),
  },
  addFieldButton: {
    display: "flex",
    margin: "auto",
    maxWidth: "100px",
  },
  buttonCell: {
    fontSize: theme.typography.pxToRem(12),
    paddingTop: theme.spacing(0.1),
    paddingBottom: theme.spacing(0.1),
    paddingLeft: theme.spacing(2), //removing for testing
    paddingRight: theme.spacing(2), //removing for testing
    height: theme.typography.pxToRem(2),
    borderBottom: "1px solid rgba(104, 104, 104, 0.1);",
    borderRight: "1px solid rgba(104, 104, 104, 0.1);",
  },
  uploadSection: {
    "& .ant-upload-list-item-name": {
      color: "blue !important",
    },
  },
  divAction: {
    display: "flex",
    alignItems: "center",
    margin: "20px 0",
  },

  line: {
    width: "49%",
    height: "1px",
    backgroundColor: "#cacaca",
  },
  last: {
    margin: "0 auto",
  },
  arrow: {
    backgroundImage: `url(${ArrowDropDown})`,
    height: "10px",
    width: "10px",
    backgroundRepeat: "no-repeat",
    backgroundPosition: "center",
    backgroundSize: "100%",
    margin: "0 10px",
    cursor: "pointer",
    rotate: "180deg",
  },
  active: {
    rotate: "0deg",
  },
}));

const MeetingAgendaNotes = ({
  formData,
  setFormData,
  mode,
  scheduleData,
  mrmEditOptions,
}: Props) => {
  const [firstForm] = Form.useForm();
  const [dataSource, setDataSource] = useState<any>([]);
  const [agendas, setAgendas] = useState<any>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [suggestions, setSuggestions] = React.useState([]);
  const [collapseDiv, setCollapseDiv] = useState(true);
  const [totalAttendees, setTotalAttendees] = useState<any>([]);
  const [owners, setowners] = useState<any>([]);
  const [agendaowner, setagendowner] = useState<any>([]);
  const classes = useStyles();
  const isOrgAdmin = checkRoles("ORG-ADMIN");
  const isMR = checkRoles("MR");
  const isInitialRender = useRef(true);
  const showData = isOrgAdmin || isMR;
  const orgId = sessionStorage.getItem("orgId");
  const realmName = getAppUrl();
  const { enqueueSnackbar } = useSnackbar();
  const [readStatus, setReadStatus] = useState(false);


  useEffect(() => {
    if (mrmEditOptions === "MrmPlan") {
      agendaDataActions();
    }
    if (mrmEditOptions === "ReadOnly") {
      setReadStatus(true);
    }
  }, [scheduleData]);

  const dataFinalActions: any[] = [];

  const agendaDataActions = () => {
    getAgendaByMeetingType(scheduleData?._id).then((response: any) => {
      if (response.data) {
        setAgendas(response.data);
      }
      if (response.data && response.data.length) {
        for (let i = 0; i < response.data.length; i++) {
          let newValue = response.data[i];

          dataFinalActions.push({
            agenda: newValue?.agenda || newValue?.name,
            _id: newValue?._id,
            keyagendaId: newValue?.meetingType || "",
            owner: newValue?.owner,
            decisionPoints: newValue?.decisionPoints || "",
          });
        }
        setDataSource(dataFinalActions);
      }
    });
  };

  useEffect(() => {
    setLoading(true);
    getAgendaDataMeetingById(formData?.meetingType);
    let newData = { ...formData };

    let newDataSource: any = [],
      newAttendes: any = [],
      attendeesName: any = [];

    let datavalues = newData?.dataValue
      ? newData.dataValue
      : newData?.agendaformeetingType
      ? newData.agendaformeetingType
      : [];
    let agendavalues = newData?.dataValue;

    if (datavalues && datavalues.length) {
      for (let i = 0; i < datavalues.length; i++) {
        let newValue = datavalues[i];

        newDataSource.push({
          agenda: newValue?.agenda || newValue?.name,
          _id: newValue?._id,
          keyagendaId: newValue?.meetingType || "",
          owner: newValue?.owner,
          decisionPoints: newValue?.decisionPoints || "",
        });
      }
    }
    // if (datavalues && datavalues.length) {
    //   for (let i = 0; i < datavalues.length; i++) {
    //     let newValue = datavalues[i];
    //     console.log("newvalue duign form set", newValue);
    //     newDataSource.push({
    //       agenda: newValue?.agenda || newValue?.name,
    //       _id: newValue?._id,
    //       keyagendaId: newValue?.meetingType || "",
    //       owner: newValue[0]?.owner,
    //       decisionPoints: newValue?.decisionPoints || "",
    //     });
    //     console.log("newdatasource during initialization", newDataSource);

    //     //     // if (newData?.attendees && newData.attendees.length) {
    //     //     //   newAttendes = [...newData.attendees];
    //     //     // } else {
    //     //     //   for (let j = 0; j < newValue?.mrmData?.participants.length; j++) {
    //     //     //     let newAttendeValue = newValue?.mrmData?.participants[j];
    //     //     //     if (!attendeesName.includes(newAttendeValue?.id)) {
    //     //     //       attendeesName.push(newAttendeValue?.id);
    //     //     //       newAttendes.push(newAttendeValue);
    //     //     //     }
    //     //     //   }
    //     //     // }
    //   }
    // }

    //setTotalAttendees([...newAttendes]);

    // setAgendas(newDataSource);
    setDataSource(newDataSource);
    setLoading(false);
    setFormData({
      ...formData,
      // attendees: newAttendes,
      agendaformeetingType: newDataSource,
      dataValue: newDataSource,
    });
  }, []);

  useEffect(() => {
    if (isInitialRender.current && mode === "Edit") {
      isInitialRender.current = false;
      return;
    }
  });

  const handleTextChange = (e: any) => {
    getSuggestionList(e.target.value, "normal");
  };

  const getSuggestionList = (value: any, type: string) => {
    typeAheadValue = value;
    typeAheadType = type;
    debouncedSearch();
  };

  const debouncedSearch = debounce(() => {
    getData(typeAheadValue, typeAheadType);
  }, 400);

  const getData = async (value: string, type: string) => {
    try {
      let res = await axios.get(
        `api/user/doctype/filterusers/${realmName}/${"allusers"}?email=${value}`
      );
      setSuggestions(res.data);
    } catch (err) {
      console.log(err);
    }
  };

  const onFinish = (values: any) => {
    // console.log("Received values of form:", values);
  };

  const toggleDiv = () => {
    setCollapseDiv(!collapseDiv);
  };

  const addData = () => {
    const newAgenda = {
      agenda: "",
      keyagendaId: "",
      owner: [],
    };
    //dataSource.push(newAgenda);
    setDataSource([...dataSource, newAgenda]); // Update dataSource if needed
  };

  const handleAttendees = (values: any) => {
    setFormData({ ...formData, attendees: values });
  };

  const handlechangeOwner = (value: any, key: number) => {
    let newDatasource = [...dataSource];
    newDatasource[key].owner = [...value];
    // let newagendaowner = [];
    // newagendaowner.push({
    //   agenda: newDatasource[key].agenda,
    //   owner: newDatasource[key].agenda,
    // });
    // console.log("newagendaownerarray", newagendaowner);

    setDataSource(newDatasource);
    setAgendas(newDatasource);

    if (newDatasource && newDatasource[key]) {
      setFormData({
        ...formData,
        agendaformeetingType: newDatasource,
        dataValue: newDatasource,
        //da: newDatasource, // Include other form data here if needed
      });
    }
  };

  // const removeData = (index: number) => {
  // let newDatasource = [...agendas];
  // console.log("dataValue", dataSource);
  // console.log("index in splice", index);
  // if (index > -1) {
  //   // only splice array when item is found
  //   let newarray = newDatasource.splice(index, 1);
  //   console.log("newdatasource after splice", newDatasource); // 2nd parameter means remove one item only
  //   setDataSource(newDatasource);
  //   setAgendas(newDatasource);
  // }
  // setFormData({ ...formData, agendaformeetingType: agendas });
  // // setFormData((prevFormData:any) => ({
  // //   ...prevFormData,
  // //   agendaformeetingType: newDatasource,
  // // }));
  // console.log("agenda data after removal", newDatasource);
  // console.log("drawer data after removal", formData);
  //console.log("after remove", newDatasource);
  // };
  const removeData = (index: number) => {
    if (index > -1 && index < agendas.length) {
      const newAgendas = [...agendas];
      newAgendas.splice(index, 1);

      setAgendas(newAgendas);
      setDataSource(newAgendas); // Update dataSource if needed
      setFormData({
        ...formData,
        agendaformeetingType: newAgendas,
        dataValue: newAgendas,
      });
    }
  };

  const getAgendaDataMeetingById = (meetingType: any) => {
    getAgendaByMeetingType(meetingType).then((response: any) => {
      if (response.data) {
        setAgendas(response.data);
      }
    });
  };

  const handleKeyAgenda = (value: any, key: number) => {
    let newDatasource = [...dataSource];
    if (!dataSource || key < 0 || key >= dataSource.length) {
      console.error("Invalid dataSource or key");
      return;
    }

    let newsource2 = [...agendas];
    let newAgendas = [...agendas];
    newDatasource[key].agenda = value;
    // newsource2[key].agenda = value;

    setDataSource(newDatasource);
    setAgendas(newAgendas);
    setFormData({
      ...formData,
      dataValue: newDatasource,
      keyadendaDataValues: newDatasource,
      agendaformeetingType: newDatasource,
    });
  };
  const handleDelete = (indexToDelete: any) => {
    // Create a copy of the dataSource array
    const updatedDataSource = [...dataSource];

    // Remove the object at the specified index
    updatedDataSource.splice(indexToDelete, 1);

    // Update the state with the modified dataSource
    setDataSource(updatedDataSource);
    setFormData({
      ...formData,
      dataValue: updatedDataSource,
    });
  };

  return (
    <>
      {" "}
      {loading ? (
        <Spin style={{ display: "flex", justifyContent: "center" }}> </Spin>
      ) : (
        <Form
          form={firstForm}
          layout="vertical"
          onValuesChange={(changedValues, allValues) =>
            setFormData({ ...formData, allValues, changedValues })
          }
          autoComplete="off"
          onFinish={onFinish}
          // initialValues={dataSource}
        >
          <div className={classes.divAction}>
            <div className={classes.line} />
            <div
              className={`${classes.arrow} ${collapseDiv && classes.active}`}
              onClick={toggleDiv}
            />
            <div className={`${classes.line} ${classes.last}`} />
          </div>

          <>
            <TableContainer component={Paper} elevation={0} variant="outlined">
              <Table stickyHeader className={classes.table}>
                <TableHead>
                  <TableRow>
                    <TableCell>Agenda</TableCell>
                    <TableCell>Owners</TableCell>
                    <TableCell>Action</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {dataSource?.map((val: any, i: number) => {
                    return (
                      <TableRow key={i}>
                        <TableCell style={{ width: "50%" }}>
                          <TextField
                            // disabled={showData ? false : true}
                            key="agenda"
                            name="agenda"
                            placeholder="Agenda"
                            value={val?.agenda}
                            disabled={readStatus}
                            onChange={(e) => handleKeyAgenda(e.target.value, i)}
                          />
                        </TableCell>
                        <TableCell style={{ width: "40%" }}>
                          <Autocomplete
                            multiple={true}
                            options={suggestions}
                            disabled={readStatus}
                            getOptionLabel={(option: any) => {
                              return option["email"];
                            }}
                            getOptionSelected={(option, value) =>
                              option.id === value.id
                            }
                            limitTags={2}
                            size="small"
                            onChange={(e, value) => handlechangeOwner(value, i)}
                            defaultValue={
                              dataSource &&
                              dataSource.length &&
                              dataSource[i] &&
                              dataSource[i]?.owner
                            }
                            filterSelectedOptions
                            renderOption={(option) => {
                              return (
                                <>
                                  <div>
                                    <MenuItem key={option.id}>
                                      <ListItemAvatar>
                                        <Avatar>
                                          <Avatar
                                            src={`${API_LINK}/${option.avatar}`}
                                          />
                                        </Avatar>
                                      </ListItemAvatar>
                                      <ListItemText
                                        primary={option.value}
                                        secondary={option.email}
                                      />
                                    </MenuItem>
                                  </div>
                                </>
                              );
                            }}
                            renderInput={(params) => {
                              return (
                                <TextField
                                  {...params}
                                  variant="outlined"
                                  placeholder={"owners"}
                                  onChange={handleTextChange}
                                  size="small"
                                  //disabled={showData ? false : true}
                                  InputLabelProps={{ shrink: false }}
                                />
                              );
                            }}
                          />
                        </TableCell>
                        <TableCell
                        // className={classes.actionButtonTableCell}
                        >
                          <IconButton
                            // disabled={!isAuditor||isOrgAdmin}
                            onClick={() => {
                              addData();
                            }}
                          >
                            {i === dataSource.length - 1 ? (
                              <AddCircle style={{ fontSize: "20px" }} />
                            ) : null}
                          </IconButton>

                          <IconButton
                            // disabled={!isLocAdmin|| !isAuditor}
                            onClick={() => {
                              handleDelete(i);
                            }}
                            style={{ fontSize: "20px" }}
                          >
                            <MinusCircleOutlined style={{ fontSize: "16px" }} />
                          </IconButton>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </TableContainer>
          </>

          {/* <Row gutter={[16, 16]}>
            <Col span={24}>
              <Form.Item label="Attendees: " name="attendees">
             
                <Autocomplete
                  key={`attendees`}
                  multiple={true}
                  options={suggestions}
                  getOptionLabel={(option: any) => {
                    return option["email"];
                  }}
                  getOptionSelected={(option, value) => option.id === value.id}
                  limitTags={2}
                  size="small"
                  onChange={(e, value) => handleAttendees(value)}
                  defaultValue={totalAttendees}
                  filterSelectedOptions
                  disabled={showData ? false : true}
                  renderOption={(option) => {
                    return (
                      <>
                        <div>
                          <MenuItem key={option.id}>
                            <ListItemAvatar>
                              <Avatar>
                                <Avatar src={`${API_LINK}/${option.avatar}`} />
                              </Avatar>
                            </ListItemAvatar>
                            <ListItemText
                              primary={option.value}
                              secondary={option.email}
                            />
                          </MenuItem>
                        </div>
                      </>
                    );
                  }}
                  renderInput={(params) => {
                    return (
                      <TextField
                        {...params}
                        variant="outlined"
                        placeholder={"attendees"}
                        onChange={handleTextChange}
                        size="small"
                        InputLabelProps={{ shrink: false }}
                        disabled={showData ? false : true}
                      />
                    );
                  }}
                />
              </Form.Item>
            </Col>
          </Row> */}
        </Form>
      )}
    </>
  );
};

export default MeetingAgendaNotes;
