import { Tabs, Drawer, Space, Button } from "antd";
import { Tooltip } from "@material-ui/core";
import { useEffect, useState } from "react";
import useStyles from "../commonDrawerStyles";
import { IconButton, useMediaQuery } from "@material-ui/core";
import axios from "../../../apis/axios.global";
import { ReactComponent as ExpandIcon } from "../../../assets/icons/row-expand.svg";
import { useNavigate } from "react-router-dom";
import { useRecoilState } from "recoil";
import { referencesData } from "recoil/atom";

//notistack
import { useSnackbar } from "notistack";

import moment from "moment";
import MeetingAgenda from "./MeetingAgenda";
import MeetingAgendaNotes from "./MeetingAgendaNotes";
import ReferencesTab from "./ReferencesTab";
import DecisionPointsAndMinutes from "./DecisionPointsAndMinutes";
import checkRoles from "../../../utils/checkRoles";
import getYearFormat from "utils/getYearFormat";
import Select from "@material-ui/core/Select";
import MailOutlineIcon from "@material-ui/icons/MailOutline";

type Props = {
  openScheduleDrawer: boolean;
  handleDrawer: any;
  expandDataValues: any;
  mrm: boolean;
  mode: any;
  scheduleData: any;
  unitSystemData: any;
  mrmEditOptions: any;
  status: any;
  setStatusMode: any;
};

const ScheduleDrawer = ({
  openScheduleDrawer,
  handleDrawer,
  expandDataValues,
  mode,
  mrm,
  scheduleData,
  unitSystemData,
  mrmEditOptions,
  status,
}: Props) => {
  const [formData, setFormData] = useState<any>(expandDataValues || {});
  const [referencesNew, setReferencesNew] = useState<any>([]);
  const isOrgAdmin = checkRoles("ORG-ADMIN");
  const isMR = checkRoles("MR");
  const [statusRef, setStatusRef] = useState<any>();
  const [refStatus, setRefStatus] = useState(false);
  const showData = isOrgAdmin || isMR;
  const navigate = useNavigate();

  useEffect(() => {
    if (mrmEditOptions === "ReadOnly") {
      setStatusRef("edit");
    } else if (mrmEditOptions === "Edit") {
      setStatusRef("edit");
    } else {
      setStatusRef("create");
    }
  }, [mrmEditOptions]);

  const [drawer, setDrawer] = useState<any>({
    mode: status,
    open: false,
    clearFields: true,
    toggle: false,
    data: { id: scheduleData?.value?._id },
  });

  const orgId = sessionStorage.getItem("orgId");
  const userDetail = JSON.parse(sessionStorage.getItem("userDetails") || "{}");
  const [currentYear, setCurrentYear] = useState<any>();
  const [refsData] = useRecoilState(referencesData);
  const { enqueueSnackbar } = useSnackbar();
  const classes = useStyles();
  const isSmallScreen = useMediaQuery("(max-width:600px)");

  const tabs = [
    {
      label: "Meeting Info",
      key: 1,
      children: (
        <MeetingAgenda
          formData={formData}
          setFormData={setFormData}
          mode={mode}
          scheduleData={scheduleData}
          unitSystemData={unitSystemData}
          mrmEditOptions={mrmEditOptions}
        />
      ),
    },
    {
      label: "Agenda",
      key: 2,
      children: (
        <MeetingAgendaNotes
          formData={formData}
          setFormData={setFormData}
          scheduleData={scheduleData}
          mode={mode}
          mrmEditOptions={mrmEditOptions}
        />
      ),
    },
    {
      label: "References",
      key: 3,
      children: <ReferencesTab drawer={drawer} />,
    },
    // {
    //   label: "Decision & Minutes",
    //   key: 4,
    //   children: (
    //     <DecisionPointsAndMinutes
    //       formData={formData}
    //       setFormData={setFormData}
    //     />
    //   ),
    // },
  ];

  useEffect(() => {
    getyear();
  }, []);

  const getyear = async () => {
    const currentyear = await getYearFormat(new Date().getFullYear());
    setCurrentYear(currentyear);
  };

  const handleMail = async (data: any) => {
    try {
      //console.log("data id", data);
      const mail = await axios.post(`/api/mrm/sendAgendOwnerMail/${data}`);
      if (mail.status == 201) {
        enqueueSnackbar("Email sent successfuly", { variant: "success" });
      }
    } catch (error) {
      enqueueSnackbar("Error sending email", { variant: "error" });
    }
  };

  const handleSubmit = async () => {
    let agendaValues: any = [];

    // if (showData) {
    let decisionValue =
      formData?.decisionPoints && formData?.decisionPoints?.length
        ? formData?.decisionPoints
        : [];

    if (formData?.dataValue && formData?.dataValue.length) {
      for (let i = 0; i < formData?.dataValue.length; i++) {
        let newValue = formData?.dataValue[i];

        agendaValues.push({
          agenda: newValue?.agenda,
          keyagendaId: newValue?.keyagendaId,
          owner: newValue?.owner,
          decisionPoints: decisionValue,
        });
      }
    }

    if (formData && formData?._id) {
      const newPayload = {
        organizationId: orgId,
        momPlanYear: currentYear,
        unitId: formData?.unit,
        systemId: formData?.system
          ? formData?.system
          : formData?.allValues?.system
          ? formData?.allValues?.system
          : [],
        period: formData?.period ? formData?.period : "N/A",
        meetingType: formData?.meetingType,
        meetingName: formData?.meetingTitle,
        // meetingdate:
        //   formData?.changedValues && formData?.changedValues?.date
        //     ? moment(formData?.changedValues?.date)
        //     : moment(formData?.date),
        keyAgendaId: formData?.dataValue,
        // attendees: formData?.attendees,
        // organizer: userDetail && userDetail?.id,
        description: formData?.meetingDescription,
        decision: decisionValue,
        notes: formData?.meetingMOM,
        updatedBy: userDetail && userDetail?.id,
        files: formData?.files,
        date: formData?.date || scheduleData?.value?.date,
        // createdBy: userDetail && userDetail?.id
      };

      if (newPayload.unitId === undefined) {
        enqueueSnackbar("Please Select Schedule Unit", { variant: "error" });
      } else if (newPayload?.systemId?.length === 0) {
        enqueueSnackbar("Please Select System field", { variant: "error" });
      } else if (newPayload.meetingName === "") {
        enqueueSnackbar("Please Enter Schedule Title", { variant: "error" });
      } else if (newPayload.meetingType === undefined) {
        enqueueSnackbar("Please Select Meeting Type", { variant: "error" });
      } else if (newPayload.date === undefined) {
        enqueueSnackbar("Please Select Schedule Date", { variant: "error" });
      } else if (newPayload.period === undefined) {
        enqueueSnackbar("Please Select  Period", { variant: "error" });
      } else {
        try {
          const res = await axios.patch(
            `/api/mrm/${formData?._id}`,
            newPayload
          );
          if (res.status === 200 || res.status === 201) {
            try {
              let formattedReferences: any = [];
              if (refsData && refsData.length > 0) {
                formattedReferences = refsData.map((ref: any) => ({
                  refId: ref.refId,
                  organizationId: orgId,
                  type: ref.type,
                  name: ref.name,
                  comments: ref.comments,
                  createdBy: userDetail.firstName + " " + userDetail.lastName,
                  updatedBy: null,
                  link: ref.link,
                  refTo: res.data._id,
                }));
              }
              //console.log("refs befor");
              const refs = await axios.put("/api/refs/bulk-update", {
                refs: formattedReferences,
                id: formData?._id,
              });
              //console.log("refs", refs);
            } catch (error) {
              enqueueSnackbar("Error creating References", {
                variant: "error",
              });
            }
            enqueueSnackbar(`Schedule Updated successfully!`, {
              variant: "success",
            });
            setFormData({});
            handleDrawer();
          }
        } catch (error) {
          enqueueSnackbar(`Error creating Schedule`, { variant: "error" });
        }
      }
    } else {
      const newPayload = {
        organizationId: orgId,
        momPlanYear: currentYear,
        unitId: formData?.unit,
        systemId: formData?.system,
        period: formData?.period ? formData?.period : "N/A",
        meetingName: formData?.meetingTitle,
        meetingType: formData?.meetingType,
        owners: formData?.owner,
        agendaowner: formData?.agendaowner,
        // meetingdate:
        //   formData?.changedValues && formData?.changedValues?.date
        //     ? moment(formData?.changedValues?.date)
        //     : moment(formData?.date),
        keyAgendaId: agendaValues,
        //  attendees: formData?.attendees,
        organizer: userDetail && userDetail?.id,
        description: formData?.meetingDescription,
        decision: decisionValue,
        notes: formData?.meetingMOM,
        updatedBy: userDetail && userDetail?.id,
        createdBy: userDetail && userDetail?.id,
        files: formData?.files,
        currentYear: currentYear,
        date: formData.date,
      };
      if (mrmEditOptions === "MrmPlan") {
        if (newPayload.systemId === undefined) {
          enqueueSnackbar("Please Select System field", { variant: "error" });
        } else if (newPayload.meetingName === undefined) {
          enqueueSnackbar("Please Enter Schedule Title", { variant: "error" });
        } else if (newPayload.period === "N/A") {
          enqueueSnackbar("Please Select  Period", { variant: "error" });
        } else if (newPayload.date === undefined) {
          enqueueSnackbar("Please Select Meeting Date", { variant: "error" });
        } else {
          try {
            const res = await axios.post("/api/mrm/schedule", newPayload);
            if (res.status === 200 || res.status === 201) {
              try {
                let formattedReferences: any = [];

                if (refsData && refsData.length > 0) {
                  formattedReferences = refsData.map((ref: any) => ({
                    refId: ref.refId,
                    organizationId: orgId,
                    type: ref.type,
                    name: ref.name,
                    comments: ref.comments,
                    createdBy: userDetail.firstName + " " + userDetail.lastName,
                    updatedBy: null,
                    link: ref.link,
                    refTo: res.data._id,
                  }));
                }
                const refs = await axios.post(
                  "/api/refs/bulk-insert",
                  formattedReferences
                );
              } catch (error) {
                enqueueSnackbar("Error creating References", {
                  variant: "error",
                });
              }
              enqueueSnackbar(`Schedule Added successfully!`, {
                variant: "success",
              });
              setFormData({});
              handleDrawer();
            }
          } catch (error) {
            enqueueSnackbar("Error creating Schedule", { variant: "error" });
          }
        }
      } else if (mrmEditOptions === "Direct") {
        if (newPayload.unitId === undefined) {
          enqueueSnackbar("Please Select Schedule Unit", { variant: "error" });
        } else if (newPayload.systemId === undefined) {
          enqueueSnackbar("Please Select System field", { variant: "error" });
        } else if (newPayload.meetingName === undefined) {
          enqueueSnackbar("Please Enter Schedule Title", { variant: "error" });
        } else if (newPayload.meetingType === undefined) {
          enqueueSnackbar("Please Select Meeting Type", { variant: "error" });
        } else if (newPayload.date === undefined) {
          enqueueSnackbar("Please Select Schedule Date", { variant: "error" });
        } else {
          try {
            const res = await axios.post("/api/mrm/schedule", newPayload);
            if (res.status === 200 || res.status === 201) {
              try {
                let formattedReferences: any = [];
                if (refsData && refsData.length > 0) {
                  formattedReferences = refsData.map((ref: any) => ({
                    refId: ref.refId,
                    organizationId: orgId,
                    type: ref.type,
                    name: ref.name,
                    comments: ref.comments,
                    createdBy: userDetail.firstName + " " + userDetail.lastName,
                    updatedBy: null,
                    link: ref.link,
                    refTo: res.data._id,
                  }));
                }
                const refs = await axios.post(
                  "/api/refs/bulk-insert",
                  formattedReferences
                );
              } catch (error) {
                enqueueSnackbar("Error creating References", {
                  variant: "error",
                });
              }
              enqueueSnackbar(`Schedule Added successfully!`, {
                variant: "success",
              });
              setFormData({});
              handleDrawer();
            }
          } catch (error) {
            enqueueSnackbar("Error creating Schedule", { variant: "error" });
          }
        }
      }
    }
  };

  return (
    <Drawer
      title={[
        <span
          key="title"
          style={isSmallScreen ? { fontSize: "13px" } : { fontSize: "16px" }}
        >
          {"Schedule MRM"}
        </span>,
      ]}
      placement="right"
      open={openScheduleDrawer}
      closable={true}
      onClose={handleDrawer}
      className={classes.drawer}
      width={isSmallScreen ? "85%" : "45%"}
      extra={
        <>
          {mrmEditOptions === "ReadOnly" ? (
            <></>
          ) : (
            <>
              <Space>
                <Button
                  onClick={() => {
                    handleDrawer();
                    setFormData({});
                  }}
                  className={classes.cancelBtn}
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleSubmit}
                  type="primary"
                  className={classes.submitBtn}
                >
                  Submit
                </Button>
              </Space>
            </>
          )}
          {/* <Tooltip title="Expand Form">
            <Button
              // style={{ marginLeft: "8px" }}
              className={classes.expandIcon}
              onClick={() =>
                navigate("/mrm/fullformview", {
                  state: { formData: formData, mrm: mrm },
                })
              }
            >
              <ExpandIcon />
            </Button>
          </Tooltip> */}
        </>
      }
    >
      <div className={classes.tabsWrapper} style={{ position: "relative" }}>
        <Tabs
          type="card"
          items={tabs as any}
          animated={{ inkBar: true, tabPane: true }}
          // tabBarStyle={{backgroundColor : "green"}}
        />
        {tabs.length > 2 && (
          <div
            style={{
              position: "absolute",
              top: 0,
              right: 0,
              display: "flex",
              alignItems: "center",
              fontSize: "10px",
              color: "grey",
            }}
          >
            {mrmEditOptions === "Edit" && (
              <Tooltip title="Send Mail to Agenda Owners" placement="bottom">
                <IconButton onClick={() => handleMail(formData?._id)}>
                  <MailOutlineIcon style={{ height: "30px" }} />
                </IconButton>
              </Tooltip>
            )}
          </div>
        )}
      </div>
    </Drawer>
  );
};

export default ScheduleDrawer;
