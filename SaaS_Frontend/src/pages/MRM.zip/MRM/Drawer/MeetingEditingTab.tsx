import React, { useEffect, useState } from "react";
import {
  Form,
  Input,
  Row,
  Col,
  DatePicker,
  Select,
  Upload,
  Avatar,
} from "antd";
import getAppUrl from "../../../utils/getAppUrl";
import axios from "../../../apis/axios.global";
import { useSnackbar } from "notistack";
import MyEditor from "../Editor";
import {
  makeStyles,
  TextField,
  Typography,
  IconButton,
  MenuItem,
  ListItemAvatar,
  ListItemText,
  Grid,
  Tooltip,
  Button,
} from "@material-ui/core";
import { debounce, filter } from "lodash";
import { API_LINK } from "../../../config";
import type { UploadProps } from "antd";
import InboxIcon from "@material-ui/icons/Inbox";
import CrossIcon from "../../../assets/icons/BluecrossIcon.svg";
import checkRoles from "../../../utils/checkRoles";
import moment from "moment";
import { currentAuditYear, currentLocation } from "recoil/atom";
import getYearFormat from "utils/getYearFormat";
import dayjs from "dayjs";
import { getAgendaByMeetingType } from "apis/mrmagendapi";
import { Autocomplete } from "@material-ui/lab";
import { TimePicker } from "antd";
import type { Dayjs } from "dayjs";
import customParseFormat from "dayjs/plugin/customParseFormat";
import AutoComplete from "components/AutoComplete";
import MyUpdateEditorMrm from "../UpdateEditorMrm";

const { Option } = Select;
const { Dragger } = Upload;

type Props = {
  formData?: any;
  setFormData?: any;
  data: any;
  index: any;
  editDataMeeting: any;
  readMode: any;
};
var typeAheadValue: string;
var typeAheadType: string;

const useStyles = makeStyles((theme) => ({
  formTextPadding: {
    paddingBottom: theme.typography.pxToRem(10),
    fontSize: theme.typography.pxToRem(14),
    color: "#003566",
  },
  submitBtn: {
    backgroundColor: "#003566 !important",
    height: "36px",
    color: "#fff",
  },
  asterisk: {
    color: "red",
    verticalAlign: "end",
  },
  labelStyle: {
    "& .ant-input-lg": {
      border: "1px solid #dadada",
    },
    "& .ant-form-item .ant-form-item-label > label": {
      color: "#003566",
      fontWeight: "bold",
      letterSpacing: "0.8px",
    },
  },
  label: {
    verticalAlign: "middle",
  },
  root: {
    width: "100%",
    "& .MuiAccordionDetails-root": {
      display: "block",
    },
  },
  uploadSection: {
    "& .ant-upload-list-item-name": {
      color: "blue !important",
    },
  },
  filename: {
    fontSize: theme.typography.pxToRem(12),
    color: theme.palette.primary.light,
    textOverflow: "ellipsis",
    overflow: "hidden",
    width: "160px",
    whiteSpace: "nowrap",
  },
  dateField: {
    marginTop: "-8px",
  },
  textField: {
    width: "100%",
    height: "30px",
    color: "#EAECEE",
    fontSize: "14px",
    textAlign:"center",
    display:"flex",
    justifyContent:"center",
    borderRadius:"6px",
    paddingTop:"0px",
    paddingBottom:"0px",
    paddingLeft:"2px",
    paddingRight:"2px",
    "& .MuiInputBase-input": {
      fontSize: "14px",
    },

    border: "1px solid #EAECEE",
    "& .MuiInput-underline": {
      "&:before": {
        borderBottom: "none",
      },
      "&:after": {
        borderBottom: "none",
      },
      "&:hover:not(.Mui-disabled):before": {
        borderBottom: "none",
      },
    },
  },
}));

const MeetingEditingTab = ({
  formData,
  setFormData,
  data,
  index,
  editDataMeeting,
  readMode,
}: Props) => {
  const [firstForm] = Form.useForm();
  let previousData = { ...formData };
  const isOrgAdmin = checkRoles("ORG-ADMIN");
  const isMR = checkRoles("MR");
  const showData = isOrgAdmin || isMR;
  const [dataSource, setDataSource] = useState<any[]>([]);
  const [uploadFileError, setUploadFileError] = useState<any>(false);
  const [fileList, setFileList] = useState<any[]>([]);
  const [uploadLoading, setUploadLoading] = useState<boolean>(false);
  const [documentForm] = Form.useForm();
  const classes = useStyles();
  const [suggestions, setSuggestions] = React.useState([]);
  const orgId = sessionStorage.getItem("orgId");
  const userInfo = JSON.parse(sessionStorage.getItem("userDetails") as string);
  const { enqueueSnackbar } = useSnackbar();
  const dateString = editDataMeeting && editDataMeeting?.meetingdate;
  const finaldateTime = dateString?.substring(
    0,
    dateString && dateString?.length - 5
  );
  const [selectedDate, setSelectedDate] = useState(finaldateTime);
  const [meetingName, setMeetingName] = useState(data?.meetingName);
  const [meetingVenue, setMeetingVenue] = useState(data?.venue);


  console.log("fromData===>", formData)

  useEffect(()=>{
    setFormData({
      ...formData,
      meetingdate: finaldateTime,
      period: data?.meetingSchedule?.period,
      createdBy: userInfo?.id,
      organizationId: data?.organizationId,
      meetingName: data?.meetingName,
      venue: data?.venue,
      attachments: data?.attachments,
      participants : editDataMeeting?.participants,
      minutesofMeeting: data.minutesofMeeting,
      meetingSchedule: editDataMeeting?.meetingSchedule?._id,
      locationId: editDataMeeting?.organizationId,
    });
    firstForm.setFieldsValue({
      meetingdate: finaldateTime,
      period: data?.meetingSchedule?.period,
      createdBy: userInfo?.id,
      organizationId: data?.organizationId,
      meetingName: data?.meetingName,
      venue: data?.venue,
      attachments: data?.attachments,
      participants : editDataMeeting?.participants,
      minutesofMeeting: data.minutesofMeeting,
      meetingSchedule: editDataMeeting?.meetingSchedule?._id,
      locationId: editDataMeeting?.organizationId,
    })
    setFileList(data.attachments)
   },[data,editDataMeeting])



  const handlerVenue = (e: any) => {
    setFormData({
      ...formData,
      venue: e.target.value,
    });
  };
  const handlerMeeting = (e: any) => {
    setFormData({
      ...formData,
      meetingName: e.target.value,
    });
  };



  const uploadFileprops: UploadProps = {
    action: "https://www.mocky.io/v2/5cc8019d300000980a055e76",
    multiple: true,
    beforeUpload: () => false,
    onChange({ file, fileList }) {
      setFileList(fileList);
    },
  };

  const addSelectedFiles = async (fileList: any) => {
    setUploadLoading(true);
    console.log("filelist", fileList);
    // Create FormData to send multiple files
    const formDataFiles = new FormData();
    fileList.forEach((file: any) => {
      formDataFiles.append("files", file.originFileObj || file);
    });

    if (process.env.REACT_APP_IS_OBJECT_STORAGE) {
      console.log("inside if");
      try {
        const res = await axios.post(
          `${API_LINK}/api/mrm/attachment`,
          formDataFiles,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          }
        );
        console.log("res in regular", res);
        if (res.status === 200 || res.status === 201) {
          console.log("res.data", res.data);
          const updatedFiles = res?.data?.map((data: any, index: number) => ({
            uid: `-${index}`,
            name: data?.name,
            url: data?.path,
            //status: "done",
          }));
          setFileList((prevFileList: any) => [
            ...prevFileList,
            ...updatedFiles,
          ]);

          setFormData((prevFormData: any) => ({
            ...prevFormData,
            attachments: [...prevFormData.attachments, ...updatedFiles],
          }));
          // setFileList(updatedFiles);
          // setFormData((prevFormData: any) => ({
          //   ...prevFormData,

          //   attachments: updatedFiles,
          // }));

          //firstForm.setFieldsValue({ documentLink: updatedFiles });
        }
      } catch (error) {
        enqueueSnackbar("Error uploading files:", { variant: "error" });
      }
    } else {
      try {
        // Send all files in a single request
        const res = await axios.post(
          `${API_LINK}/api/mrm/objectStore`,
          formDataFiles,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          }
        );
        console.log("res in object storage", res);
        if (res.status === 200 || res.status === 201) {
          console.log("res.data", res.data);
          const updatedFiles = res?.data?.map((data: any, index: number) => ({
            uid: `-${index}`,
            name: data?.name,
            url: data?.path,
            //status: "done",
          }));

          setFileList(updatedFiles);
          setFormData({ ...formData, attachments: updatedFiles });
          // firstForm.setFieldsValue({ documentLink: updatedFiles });
        }
      } catch (error) {
        // Handle error if the API call fails
        console.error("Error uploading files:", error);
      }
    }
  };

  const clearFile = async (data: any) => {
    try {
      console.log("data", data);
      if (data && data?.uid) {
        setFileList((previousFiles) =>
          previousFiles?.filter((item: any) => item.uid !== data.uid)
        );
        console.log("filelist after update", fileList);
        setFormData((prevFormData: any) => ({
          ...prevFormData,
          attachments: prevFormData?.attachments?.filter(
            (item: any) => item.uid !== data.uid
          ),
        }));

        // Assuming data.uid is a valid identifier for your file
        let result = await axios.post(`${API_LINK}/api/mrm/attachment/delete`, {
          path: data.uid,
        });
        return result;
      }
    } catch (error) {
      return error;
    }
  };

  const handleDateChange = (e: any) => {
    setFormData({
      ...formData,
      meetingdate: e.target.value,
    });
  };

  const [userOptions, setUserOptions] = useState([]);

  const getUserOptions = async (value: any, type: string) => {
    await axios
      .get(
        `/api/documents/filerValue?searchLocation=&searchBusinessType=&searchEntity=&searchSystems=&searchDoctype=&searchUser=${value}`
      )
      .then((res) => {
        const ops = res?.data?.allUser?.map((obj: any) => ({
          id: obj.id,
          name: obj.username,
          avatar: obj.avatar,
          email: obj.email,
          username: obj.username,
        }));
        setUserOptions(ops);
      })
      .catch((err) => console.error(err));
  };
  const getSuggestionListUser = (value: any, type: string) => {
    typeAheadValue = value;
    typeAheadType = type;
    debouncedSearchUser();
  };

  const debouncedSearchUser = debounce(() => {
    getUserOptions(typeAheadValue, typeAheadType);
  }, 50);

  return (
    <>
      <Form
        form={firstForm}
        layout="vertical"
        onValuesChange={(changedValues, allValues) =>
          setFormData({ ...formData, allValues, changedValues })
        }
        initialValues={formData}
      >
        <Row gutter={[16, 16]}>
          <Col span={16}>
            <Grid item sm={12} md={5} className={classes.formTextPadding}>
              <strong>
                <span className={classes.asterisk}>*</span>
                <span className={classes.label}>Meeting Title: </span>
              </strong>
            </Grid>
            <Form.Item
              // label="Meeting Title: "
              name="meetingName"
              // tooltip="This is a required field"
              // labelCol={{ style: { color: "#003566" } }}
              rules={[
                { required: true, message: "Please Enter  Meeting Title!" },
              ]}
            >
              <Input
                value={formData?.meetingName}
                defaultValue={formData?.meetingName}
                placeholder="Meeting Title"
                name="meetingName"
                disabled={readMode}
                onBlur={(e) => {
                  handlerMeeting(e);
                }}
              />
            </Form.Item>
          </Col>
          <Col span={8}>
            <Grid item sm={12} md={5} className={classes.formTextPadding}>
              <strong>
                <span className={classes.asterisk}>*</span>
                <span className={classes.label}>Date: </span>
              </strong>
            </Grid>
            <Form.Item
              // label="Meeting Date: "
              name="meetingdate"
              // tooltip="This is a required field"
              rules={[{ required: true, message: "Please Select Date!" }]}
            >
              <TextField
                fullWidth
                className={classes.textField}
                disabled={readMode}
                type="datetime-local"
                name="meetingdate"
                value={formData?.meetingdate}
                onChange={(e) => {
                  handleDateChange(e);
                }}
                size="small"
                required
              />
            </Form.Item>
          </Col>
        </Row>

        <Row gutter={[16, 16]}>
          <Col span={16}>
            <Grid item sm={12} md={5} className={classes.formTextPadding}>
              <strong>
                <span className={classes.asterisk}>*</span>{" "}
                <span className={classes.label}> Meeting Venue: </span>
              </strong>
            </Grid>
            <Form.Item
              name="venue"
              rules={[{ required: true, message: "Please Enter Venue!" }]}
            >
              <Input
                value={formData?.venue}
                defaultValue={formData?.venue}
                placeholder="Meeting Venue"
                name="venue"
                disabled={readMode}
                onBlur={(e) => {
                  handlerVenue(e);
                }}
              />
            </Form.Item>
          </Col>
          <Col span={8}>
            <Grid item sm={12} md={5} className={classes.formTextPadding}>
              <strong>
                {/* <span className={classes.asterisk}>*</span>{" "} */}
                <span className={classes.label}>Period: </span>
              </strong>
            </Grid>
            <Form.Item name="period">
              <Input
                value={formData?.period}
                disabled={true}
                name="period"
                placeholder={formData?.period}
              />
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={[16, 16]}>
          <Col span={24}>
            <Grid item sm={12} md={5} className={classes.formTextPadding}>
              <strong>
                <span className={classes.asterisk}>*</span>{" "}
                <span className={classes.label}>List of Participants: </span>
              </strong>
            </Grid>
            <Form.Item
              // label="List of Participants "
              name="participants"
              // tooltip="This is a required field"
              rules={[
                { required: true, message: "Please Select Participants!" },
              ]}
            >
              <AutoComplete
                suggestionList={userOptions ? userOptions : []}
                name="participants"
                keyName="participants"
                labelKey="name"
                formData={formData}
                setFormData={setFormData}
                disabled={readMode}
                getSuggestionList={getSuggestionListUser}
                defaultValue={
                  editDataMeeting && editDataMeeting?.participants?.length
                    ? editDataMeeting?.participants
                    : []
                }
                type="RA"
              />
            </Form.Item>
          </Col>
        </Row>

        <Row gutter={[16, 16]}>
          <Col span={24}>
            <Grid item sm={12} md={5} className={classes.formTextPadding}>
              <strong>
                {/* <span className={classes.asterisk}>*</span>{" "} */}
                <span className={classes.label}>Minutes of Meeting: </span>
              </strong>
            </Grid>
            <Form.Item name="minutesofMeeting">
              <MyUpdateEditorMrm
                formData={formData}
                setFormData={setFormData}
                title="minutesofMeeting"
                data={data}
                readMode={readMode}
              />
            </Form.Item>
          </Col>
        </Row>

        <Row gutter={[16, 16]}>
          <Col span={12}>
            <Grid item sm={12} md={5} className={classes.formTextPadding}>
              <strong>
                <span className={classes.label}>
                  {!!fileList?.length
                    ? "Change Uploaded Files"
                    : "Attach Files: "}
                </span>
              </strong>
            </Grid>
          </Col>
          <Col
            span={12}
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "flex-end",
            }}
          >
            <Tooltip title="Upload files">
              <Button
                type="primary"
                href="#"
                disabled={readMode}
                onClick={() => addSelectedFiles(fileList)}
                className={classes.submitBtn}
              >
                Upload Files
              </Button>
            </Tooltip>
          </Col>
          <Col span={24}>
            <strong>
              <span
                style={{
                  color: "red",
                  fontSize: "10px",
                }}
              >
                {!!fileList.length
                  ? "!!Click on Upload files button to upload"
                  : ""}
              </span>
            </strong>
          </Col>
          <Col span={24}>
            <Form.Item
              // name="fileList"
              help={uploadFileError ? "Please upload a file!" : ""}
              validateStatus={uploadFileError ? "error" : ""}
            >
              <Dragger
                accept=".pdf,.png,.jpeg,.jpg,.docx,.bmp,.tif,.tiff,.webp"
                name="fileList"
                {...uploadFileprops}
                className={classes.uploadSection}
                showUploadList={false}
                fileList={fileList}
                multiple
              >
                <p className="ant-upload-drag-icon">
                  <InboxIcon />
                </p>
                <p className="ant-upload-text">
                  Click or drag files to this area to upload
                </p>
              </Dragger>
            </Form.Item>

            {uploadLoading ? (
              <div>Please wait while documents get uploaded</div>
            ) : (
              fileList &&
              fileList?.length > 0 &&
              fileList?.map((item: any) => (
                <div
                  style={{
                    display: "flex",
                    marginLeft: "10px",
                    alignItems: "center",
                  }}
                  key={item.uid}
                >
                  <Typography className={classes.filename}>
                    <a
                      href={`${API_LINK}${item?.url}`}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      {item?.name}
                    </a>
                  </Typography>

                  <IconButton onClick={() => clearFile(item)}>
                    <img src={CrossIcon} alt="" />
                  </IconButton>
                </div>
              ))
            )}
          </Col>
        </Row>
      </Form>
    </>
  );
};

export default MeetingEditingTab;
