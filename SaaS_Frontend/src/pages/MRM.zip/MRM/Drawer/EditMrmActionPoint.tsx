import { Tabs, Space, Button, Tooltip, Drawer } from "antd";
import { List, ListItem } from "@material-ui/core";
import { useEffect, useState } from "react";
import useStyles from "../commonDrawerStyles";
import { makeStyles, useMediaQuery } from "@material-ui/core";
import axios from "../../../apis/axios.global";
import { ReactComponent as ExpandIcon } from "../../../assets/icons/row-expand.svg";
import { useNavigate } from "react-router-dom";
import CloseIcon from "@material-ui/icons/Close";
import InfoIcon from "@material-ui/icons/Info";
import { Autocomplete } from "@material-ui/lab";
import { Form, Input, Row, Col, DatePicker, Upload, Switch } from "antd";
// import { Select, MenuItem } from "@material-ui/core";
import {
  Avatar,
  IconButton,
  ListItemAvatar,
  ListItemText,
  TextField,
  Typography,
  Grid,
} from "@material-ui/core";
import { Select, MenuItem } from "@material-ui/core";
import InboxIcon from "@material-ui/icons/Inbox";
//notistack
import { useSnackbar } from "notistack";
import moment from "moment";
import { API_LINK } from "../../../config";
import { debounce } from "lodash";
import getAppUrl from "../../../utils/getAppUrl";
import type { UploadProps } from "antd";
import CrossIcon from "../../../assets/icons/BluecrossIcon.svg";
import ReferencesTab from "./ReferencesTab";
import checkRoles from "../../../utils/checkRoles";
import useStylesMrm from "./MrmAddMeetingsStyles";
import { TableCell, TableContainer, TableRow } from "@material-ui/core";
import { getAgendaForOwner } from "apis/mrmmeetingsApi";
import AutoComplete from "components/AutoComplete";
import { createActionPoint, updateActionPoint } from "apis/mrmActionpoint";
import getYearFormat from "utils/getYearFormat";
import { AnyMessageParams } from "yup/lib/types";
import ReferencesTabMrm from "./ReferencesTabMrm";
import { useRecoilState } from "recoil";
import { referencesData } from "recoil/atom";
import { truncateSync } from "fs";

const drawerWidth = 600;
const nestedWidth = 600;
const nestedHeight = 200;

const useStylesClass = makeStyles((theme) => ({
  formTextPadding: {
    paddingBottom: theme.typography.pxToRem(10),
    fontSize: theme.typography.pxToRem(14),
    color: "#003566",
  },
  asterisk: {
    color: "red",
    verticalAlign: "end",
  },
  labelStyle: {
    "& .ant-input-lg": {
      border: "1px solid #dadada",
    },
    "& .ant-form-item .ant-form-item-label > label": {
      color: "#003566",
      fontWeight: "bold",
      letterSpacing: "0.8px",
    },
  },

  label: {
    verticalAlign: "middle",
  },

  drawerPaper: {
    width: drawerWidth,
    flexShrink: 0,
    "& .MuiDrawer-paper": {
      width: drawerWidth,
      boxSizing: "border-box",
    },
  },
  textField: {
    width: "100%",
    height: "36px",
    color: "#EAECEE",
    fontSize: "14px",
    textAlign: "center",
    display: "flex",
    justifyContent: "center",
    borderRadius: "6px",
    paddingTop: "0px",
    paddingBottom: "0px",
    paddingLeft: "2px",
    paddingRight: "2px",
    "& .MuiInputBase-input": {
      fontSize: "14px",
    },
    border: "1px solid #EAECEE",
    "& .MuiInput-underline": {
      "&:before": {
        borderBottom: "none",
      },
      "&:after": {
        borderBottom: "none",
      },
      "&:hover:not(.Mui-disabled):before": {
        borderBottom: "none",
      },
    },
  },
  Dropdowm: {
    width: "100%",
    height: "35px",
    borderRadius: "3px",
    padding: "0px",
    border: "1px solid #EAECEE",
    "& .MuiInput-underline": {
      "&:before": {
        borderBottom: "none",
      },
      "&:after": {
        borderBottom: "none",
      },
      "&:hover:not(.Mui-disabled):before": {
        borderBottom: "none",
      },
    },
  },
  submitBtn: {
    backgroundColor: "#003566 !important",
    height: "36px",
    color: "#fff",
  },

  drawerPaperSub: {
    width: nestedWidth,
    height: nestedHeight,
    flexShrink: 0,
    "& .MuiDrawer-paper": {
      width: nestedWidth,
      height: nestedHeight,
      boxSizing: "border-box",
    },
  },
  documentTable: {
    "&::-webkit-scrollbar-thumb": {
      borderRadius: "10px",
      backgroundColor: "grey",
    },
  },
  tableContainer: {
    marginTop: "1%",
    maxHeight: "calc(60vh - 14vh)", // Adjust the max-height value as needed
    overflowY: "auto",
    overflowX: "hidden",
    // fontFamily: "Poppins !important",
    "& .ant-table-wrapper .ant-table.ant-table-bordered > .ant-table-container > .ant-table-summary > table > tfoot > tr > td":
      {
        borderInlineEnd: "none",
      },
    "& .ant-table-thead .ant-table-cell": {
      backgroundColor: "#E8F3F9",
      // fontFamily: "Poppins !important",
      color: "#00224E",
    },
    "& span.ant-table-column-sorter-inner": {
      color: "#00224E",
      // color: ({ iconColor }) => iconColor,
    },
    "& span.ant-tag": {
      display: "flex",
      width: "89px",
      padding: "5px 0px",
      justifyContent: "center",
      alignItems: "center",
      borderRadius: "10px",
      color: "white",
    },
    "& .ant-table-wrapper .ant-table-thead>tr>th": {
      position: "sticky", // Add these two properties
      top: 0, // Add these two properties
      zIndex: 2,
      // padding: "12px 16px",
      fontWeight: 600,
      fontSize: "14px",
      padding: "6px 8px !important",
      // fontFamily: "Poppins !important",
      lineHeight: "24px",
    },
    "& .ant-table-tbody >tr >td": {
      // borderBottom: ({ tableColor }) => `1px solid ${tableColor}`, // Customize the border-bottom color here
      borderBottom: "black",
      padding: "4px 8px !important",
    },
    // '& .ant-table-wrapper .ant-table-container': {
    //     maxHeight: '420px', // Adjust the max-height value as needed
    //     overflowY: 'auto',
    //     overflowX: 'hidden',
    // },
    "& .ant-table-body": {
      // maxHeight: '150px', // Adjust the max-height value as needed
      // overflowY: 'auto',
      "&::-webkit-scrollbar": {
        width: "8px",
        height: "10px", // Adjust the height value as needed
        backgroundColor: "#e5e4e2",
      },
      "&::-webkit-scrollbar-thumb": {
        borderRadius: "10px",
        backgroundColor: "grey",
      },
    },
    "& tr.ant-table-row": {
      cursor: "pointer",
      transition: "all 0.1s linear",
    },
  },
}));

const { TextArea } = Input;
const { Dragger } = Upload;

var typeAheadValue: string;
var typeAheadType: string;

type Props = {
  open: any;
  onClose: () => void;
  setAgendaData: any;
  agendaData: any;
  addNew: boolean;
  setFormData: any;
  formData: any;
  edit?: any;
  dataSourceFilter: any;
  actionRowData: any;
  valueById: any;
  data: any;
  year: any;
  readMode: any;
  setLoadActionPoint:any;
};

const AddActionPoint = ({
  open,
  onClose,
  setAgendaData,
  agendaData,
  addNew,
  edit,
  dataSourceFilter,
  actionRowData,
  valueById,
  data,
  year,
  readMode,
  setLoadActionPoint,
}: Props) => {
  const modalData = undefined;
  let checkOwner: undefined = undefined;
  const isOrgAdmin = checkRoles("ORG-ADMIN");
  const isMR = checkRoles("MR");
  const isGeneralUser = checkRoles("GENERAL-USER");
  const showData = isOrgAdmin || isMR;
  const [uploadFileError, setUploadFileError] = useState<boolean>(false);
  const [firstForm] = Form.useForm();
  const [suggestions, setSuggestions] = useState([]);
  const [fileList, setFileList] = useState<any[]>([]);
  const [uploadLoading, setUploadLoading] = useState<boolean>(false);
  const mrmStyles = useStylesMrm();
  const realmName = getAppUrl();
  const [formData, setFormData] = useState<any>({});
  const [agendaValuesFind, setagendaValuesFind] = useState<any[]>(["None"]);
  const [currentYear, setCurrentYear] = useState<any>();
  const [refsData] = useRecoilState(referencesData);
  const orgId = sessionStorage.getItem("orgId");
  const userId = sessionStorage.getItem("user_info");
  const [userOptions, setUserOptions] = useState([]);
  const { enqueueSnackbar } = useSnackbar();
  const [status, setStatus] = useState<boolean>(true);
  const classes = useStyles();
  const isSmallScreen = useMediaQuery("(max-width:600px)");
  const [selectDropValues, setSelectedDropValues] = useState<any>(
    actionRowData?.agenda
  );
  const userDetail = JSON.parse(sessionStorage.getItem("userDetails") || "{}");
  useEffect(() => {
    setFormData({
      meetingId: actionRowData?.meetingId?._id,
      mrmId: actionRowData?.mrmId?._id,
      organizationId: actionRowData?.meetingId?.organizationId,
      status: actionRowData?.status,
      agenda: actionRowData?.agenda,
      description: actionRowData?.description,
      actionPoint: actionRowData?.actionPoint,
      owner: actionRowData?.owner,
      dueDate: actionRowData?.dueDate?.substring(0, 10),
      decisionPoint: actionRowData?.decisionPoint,
      files: actionRowData?.files,
      locationId: dataSourceFilter?.meetingSchedule?.unitId,
      year: year,
    });
    firstForm.setFieldsValue({
      meetingId: actionRowData?.meetingId?._id,
      mrmId: actionRowData?.mrmId?._id,
      organizationId: actionRowData?.meetingId?.organizationId,
      status: actionRowData?.status,
      agenda: actionRowData?.agenda,
      description: actionRowData?.description,
      actionPoint: actionRowData?.actionPoint,
      owner: actionRowData?.owner,
      dueDate: actionRowData?.dueDate?.substring(0, 10),
      decisionPoint: actionRowData?.decisionPoint,
      files: actionRowData?.files,
      locationId: dataSourceFilter?.meetingSchedule?.unitId,
      year: year,
    });
    setSelectedDropValues(actionRowData?.agenda);
    setFileList(actionRowData?.files);
    setDrawer({
      mode: "edit",
      open: false,
      clearFields: true,
      toggle: false,
      data: { id: actionRowData?._id },
    });
  }, [actionRowData]);

  useEffect(() => {
    getyear();
  }, []);

  const getyear = async () => {
    const currentyear = await getYearFormat(new Date().getFullYear());
    setCurrentYear(currentyear);
  };

  const handleChange = (e: any) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  useEffect(() => {
    if (dataSourceFilter) {
      setFormData({
        meetingId: dataSourceFilter?._id,
        mrmId: dataSourceFilter?.meetingSchedule?._id,
        organizationId: dataSourceFilter?.meetingSchedule?.organizationId,
        status: status,
        currentYear: currentYear,
      });
    }
  }, [dataSourceFilter]);

  useEffect(() => {
    try {
      if (actionRowData) {
        getAgendaForOwner(actionRowData?.mrmId?._id).then((response: any) => {
          setagendaValuesFind(response?.data);
        });
      }
    } catch (err) {
      enqueueSnackbar(err, {
        variant: "success",
      });
    }
  }, [actionRowData]);

  const actionPointSubmitClose = () => {
    // addSelectedFiles(fileList);

    const newPayload = {
      ...formData,
      meetingId: dataSourceFilter?._id,
      mrmId: dataSourceFilter?.meetingSchedule?._id,
      organizationId: dataSourceFilter?.meetingSchedule?.organizationId,
      status: status,
      locationId: dataSourceFilter?.meetingSchedule?.unitId,
      currentYear: currentYear,
      year: year,
      files: fileList,
      owner: formData.owner,
      createdBy: userDetail.id,
    };

    if (
      newPayload.agenda &&
      newPayload.decisionPoint &&
      newPayload.actionPoint &&
      newPayload.dueDate &&
      newPayload.owner
    ) {
      updateActionPoint(actionRowData?._id, newPayload)
        .then(async (response: any) => {
          // console.log()
          try {
            let formattedReferences: any = [];
            //console.log("refsdata", refsData);
            if (refsData && refsData.length > 0) {
              formattedReferences = refsData.map((ref: any) => ({
                refId: ref.refId,
                organizationId: orgId,
                type: ref.type,
                name: ref.name,
                comments: ref.comments,
                createdBy: userDetail.firstName + " " + userDetail.lastName,
                updatedBy: null,
                link: ref.link,
                refTo: actionRowData?._id,
              }));
            }
            // console.log("refs");
            const refs = await axios.put("/api/refs/bulk-update", {
              refs: formattedReferences,
              id: actionRowData._id,
            });
            //console.log("refs after update", refs);
          } catch (error) {
            enqueueSnackbar("Error creating References", {
              variant: "error",
            });
          }
          if (response.status === 200 || response.status === 201) {
            enqueueSnackbar(`Action Point Updated successfully!`, {
              variant: "success",
            });
          }
          onClose();
          firstForm.resetFields();
          setUserOptions([]);
          setLoadActionPoint(true)
        })
        .catch((error: any) => {
          enqueueSnackbar("error adding data");
        });
    } else {
      enqueueSnackbar("Please fill all the required fields", {
        variant: "error",
      });
    }
  };

  useEffect(() => {
    firstForm.resetFields();

    // setAgendaData({
    //   agenda: "",
    //   decisionPoints: "",
    //   owner: [],
    // });

    setFileList([]);
  }, [addNew]);

  useEffect(() => {
    // firstForm.setFieldsValue({
    //   meetingId: actionRowData?.allData?.meetingId,
    //  mrmId: actionRowData?.allData?.mrmId,
    //  organizationId: actionRowData?.allData?.organizationId,
    //  status: actionRowData?.status,
    //  agenda: actionRowData?.allData?.agenda,
    //  description:  actionRowData?.allData?.description,
    //  actionPoint: actionRowData?.actionPoint,
    //  owner: actionRowData?.allData?.owner,
    //  dueDate: actionRowData?.dueDate?.substring(0, 10),
    // });
  }, []);

  const navigate = useNavigate();

  const onStatusChange = (checked: boolean) => {
    setStatus(checked);
    setFormData({ ...formData, status: checked });
  };
  const handleTextChange = (e: any) => {
    getSuggestionList(e.target.value, "normal");
  };

  const getSuggestionList = (value: any, type: string) => {
    typeAheadValue = value;
    typeAheadType = type;
    debouncedSearch();
  };

  const debouncedSearch = debounce(() => {
    getData(typeAheadValue, typeAheadType);
  }, 400);

  const getData = async (value: string, type: string) => {
    try {
      let res = await axios.get(
        `api/user/doctype/filterusers/${realmName}/${"allusers"}?email=${value}`
      );
      setSuggestions(res.data);
    } catch (err) {
      console.log(err);
    }
  };

  const uploadFileprops: UploadProps = {
    action: "https://www.mocky.io/v2/5cc8019d300000980a055e76",
    multiple: true,
    beforeUpload: () => false,
    onChange({ file, fileList }) {
      setFileList(fileList);
    },
  };

  const addSelectedFiles = async (fileList: any) => {
    setUploadLoading(true);

    // Create FormData to send multiple files
    const formDataFiles = new FormData();
    fileList.forEach((file: any) => {
      formDataFiles.append("files", file.originFileObj || file);
    });

    if (process.env.REACT_APP_IS_OBJECT_STORAGE) {
      try {
        const res = await axios.post(
          `${API_LINK}/api/mrm/attachment`,
          formDataFiles,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          }
        );

        if (res.status === 200 || res.status === 201) {
          const updatedFiles = res?.data?.map((data: any, index: number) => ({
            uid: `-${index}`,
            name: data?.name,
            url: data?.path,
            //status: "done",
          }));

          setFileList((prevFileList: any) => [
            ...prevFileList,
            ...updatedFiles,
          ]);

          setFormData((prevFormData: any) => ({
            ...prevFormData,
            files: [...prevFormData.files, ...updatedFiles],
          }));

          //firstForm.setFieldsValue({ documentLink: updatedFiles });
        }
      } catch (error) {
        enqueueSnackbar("Error uploading files:", { variant: "error" });
      }
    } else {
      try {
        // Send all files in a single request
        const res = await axios.post(
          `${API_LINK}/api/mrm/objectStore`,
          formDataFiles,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          }
        );

        if (res.status === 200 || res.status === 201) {
          const updatedFiles = res?.data?.map((data: any, index: number) => ({
            uid: `-${index}`,
            name: data?.name,
            url: data?.path,
            //status: "done",
          }));

          setFileList(updatedFiles);
          setFormData({ ...formData, files: updatedFiles });
          // firstForm.setFieldsValue({ documentLink: updatedFiles });
        }
      } catch (error) {
        // Handle error if the API call fails
        console.error("Error uploading files:", error);
      }
    }
  };

  const getUserOptions = async (value: any, type: string) => {
    await axios
      .get(
        `/api/documents/filerValue?searchLocation=&searchBusinessType=&searchEntity=&searchSystems=&searchDoctype=&searchUser=${value}`
      )
      .then((res) => {
        const ops = res?.data?.allUser?.map((obj: any) => ({
          id: obj.id,
          name: obj.username,
          avatar: obj.avatar,
          email: obj.email,
          username: obj.username,
        }));
        setUserOptions(ops);
      })
      .catch((err) => console.error(err));
  };
  const getSuggestionListUser = (value: any, type: string) => {
    typeAheadValue = value;
    typeAheadType = type;
    debouncedSearchUser();
  };

  const debouncedSearchUser = debounce(() => {
    getUserOptions(typeAheadValue, typeAheadType);
  }, 50);

  const clearFile = async (data: any) => {
    try {
      if (data && data?.uid) {
        setFileList((previousFiles) =>
          previousFiles?.filter((item: any) => item.uid !== data.uid)
        );

        setFormData((prevFormData: any) => ({
          ...prevFormData,
          files: prevFormData?.files?.filter(
            (item: any) => item.uid !== data.uid
          ),
        }));

        // Assuming data.uid is a valid identifier for your file
        let result = await axios.post(`${API_LINK}/api/mrm/attachment/delete`, {
          path: data.uid,
        });
        return result;
      }
    } catch (error) {
      return error;
    }
  };

  const classStylse = useStylesClass();

  const [drawer, setDrawer] = useState<any>({
    mode: "edit",
    open: false,
    clearFields: true,
    toggle: false,
    data: { id: actionRowData?._id },
  });

  const tabs = [
    {
      label: "Action Point",
      key: 1,
      children: (
        <>
          <Form
            form={firstForm}
            layout="vertical"
            onValuesChange={(changedValues, allValues) => {
              setFormData(allValues);
            }}
          >
            <Row gutter={[16, 16]}>
              <Col span={24}>
                <Grid
                  item
                  sm={12}
                  md={5}
                  className={classStylse.formTextPadding}
                >
                  <strong>
                    <span className={classStylse.asterisk}>*</span>{" "}
                    <span className={classStylse.label}>Agenda: </span>
                  </strong>
                </Grid>
                <Form.Item
                  // label="Agenda"
                  name="agenda"
                  // tooltip="This is a required field"
                  rules={[{ required: true, message: "Please Select agenda!" }]}
                >
                  {isGeneralUser ? (
                    <>
                      <Input
                        value={actionRowData?.agenda}
                        defaultValue={actionRowData?.agenda}
                        disabled={readMode}
                      />
                    </>
                  ) : (
                    <>
                      <Select
                        className={classStylse.Dropdowm}
                        placeholder="Please select agenda"
                        value={formData?.agenda}
                        defaultValue={formData?.agenda}
                        disabled={readMode}
                        name="agenda"
                        onChange={(e: any) => {
                          handleChange(e);
                        }}
                        style={{ width: "100%", paddingLeft: "10px" }}
                      >
                        {Array.isArray(agendaValuesFind) &&
                          agendaValuesFind.length > 0 &&
                          agendaValuesFind?.map((item: any, index: any) => {
                            return (
                              <MenuItem
                                key={index}
                                value={item}
                                style={{ width: "80%" }}
                              >
                                {item}
                              </MenuItem>
                            );
                          })}
                      </Select>
                    </>
                  )}
                </Form.Item>
              </Col>
            </Row>

            <Row gutter={[16, 16]}>
              <Col span={24}>
                <Grid
                  item
                  sm={12}
                  md={5}
                  className={classStylse.formTextPadding}
                >
                  <strong>
                    <span className={classStylse.asterisk}>*</span>{" "}
                    <span className={classStylse.label}>Decision Points: </span>
                  </strong>
                </Grid>
                <Form.Item
                  // label="Decision Points"
                  name="decisionPoint"
                  // tooltip="This is a required field"
                  rules={[
                    { required: false, message: "Please add decision points!" },
                  ]}
                >
                  <TextArea
                    autoSize={{ minRows: 4 }}
                    value={formData?.decisionPoint}
                    disabled={readMode}
                    name="decisionPoint"
                    onChange={(e: any) => {
                      handleChange(e);
                    }}
                    defaultValue={formData?.decisionPoint}
                  />
                </Form.Item>
              </Col>
            </Row>
            <hr />
            <Row gutter={[16, 16]}>
              <Col span={24}>
                <Grid
                  item
                  sm={12}
                  md={5}
                  className={classStylse.formTextPadding}
                >
                  <strong>
                    <span className={classStylse.asterisk}>*</span>{" "}
                    <span className={classStylse.label}>Action Item: </span>
                  </strong>
                </Grid>
                <Form.Item
                  // label="Action Point"
                  name="actionPoint"
                  // tooltip="This is a required field"
                  rules={[
                    { required: true, message: "Please add action points!" },
                  ]}
                >
                  <TextArea
                    autoSize={{ minRows: 2 }}
                    value={formData?.actionPoint}
                    disabled={readMode}
                    name="actionPoint"
                    onChange={(e: any) => {
                      handleChange(e);
                    }}
                    defaultValue={formData?.actionPoint}
                  />
                </Form.Item>
              </Col>
              <Col span={12}>
                <Grid
                  item
                  sm={12}
                  md={5}
                  className={classStylse.formTextPadding}
                >
                  <strong>
                    <span className={classStylse.asterisk}>*</span>{" "}
                    <span className={classStylse.label}>Owner: </span>
                  </strong>
                </Grid>
                <Form.Item
                  // label="Owner"
                  name="owner"
                  // tooltip="This is a required field"

                  rules={[{ required: true, message: "Please Select Owner!" }]}
                >
                  <AutoComplete
                    suggestionList={userOptions ? userOptions : []}
                    keyName="owner"
                    labelKey="name"
                    name="owner"
                    disabled={readMode}
                    formData={formData}
                    setFormData={setFormData}
                    getSuggestionList={getSuggestionListUser}
                    defaultValue={
                      formData?.owner?.length ? formData?.owner : []
                    }
                    type="RA"
                  />
                </Form.Item>
              </Col>
              <Col span={11}>
                <Grid
                  item
                  sm={12}
                  md={5}
                  className={classStylse.formTextPadding}
                >
                  <strong>
                    <span className={classStylse.asterisk}>*</span>{" "}
                    <span className={classStylse.label}>Due Date: </span>
                  </strong>
                </Grid>
                <Form.Item
                  // label="Due Date: "
                  name="dueDate"
                  rules={[{ required: true, message: "Please Select Date!" }]}
                >
                  <TextField
                    name="dueDate"
                    type="date"
                    className={classStylse.textField}
                    value={formData?.dueDate}
                    disabled={readMode}
                    onChange={(e) => {
                      handleChange(e);
                    }}
                    defaultValue={formData?.dueDate?.substring(0, 10)}
                  />
                </Form.Item>
              </Col>
            </Row>

            <Row gutter={[16, 16]}>
              <Col span={24}>
                <Grid
                  item
                  sm={12}
                  md={5}
                  className={classStylse.formTextPadding}
                >
                  <strong>
                    {/* <span className={classStylse.asterisk}>*</span>{" "} */}
                    <span className={classStylse.label}>
                      Details of action point:{" "}
                    </span>
                  </strong>
                </Grid>
                <Form.Item
                  // label="Description"
                  name="description"
                  // tooltip="This is a required field"
                  // rules={[
                  //   {
                  //     required: false,
                  //     message: "Please add action point description!",
                  //   },
                  // ]}
                >
                  <TextArea
                    autoSize={{ minRows: 2 }}
                    value={formData?.description}
                    name="description"
                    disabled={readMode}
                    onChange={(e: any) => {
                      handleChange(e);
                    }}
                    defaultValue={formData?.description}
                  />
                </Form.Item>
              </Col>
            </Row>
            <Row gutter={[16, 16]}>
              <Col span={12}>
                <Grid
                  item
                  sm={12}
                  md={5}
                  className={classStylse.formTextPadding}
                >
                  <strong>
                    <span className={classStylse.label}>
                      {!!fileList.length ? "Change Files" : "Attach Files: "}
                    </span>
                  </strong>
                </Grid>
              </Col>

              <Col
                span={12}
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "flex-end",
                }}
              >
                <Tooltip title="Upload files">
                  <Button
                    type="primary"
                    href="#"
                    disabled={readMode}
                    onClick={() => addSelectedFiles(fileList)}
                    className={classStylse.submitBtn}
                  >
                    Upload Files
                  </Button>
                </Tooltip>
              </Col>

              <Col span={24}>
                <strong>
                  <span
                    style={{
                      color: "red",
                      fontSize: "10px",
                    }}
                  >
                    {!!fileList.length
                      ? "!!Click on Upload files button to upload"
                      : ""}
                  </span>
                </strong>
              </Col>

              <Col span={24}>
                <Form.Item
                  // name="fileList"
                  help={uploadFileError ? "Please upload a file!" : ""}
                  validateStatus={uploadFileError ? "error" : ""}
                >
                  <Dragger
                    accept=".pdf,.png,.jpeg,.jpg,.docx,.bmp,.tif,.tiff,.webp"
                    name="fileList"
                    {...uploadFileprops}
                    className={classes.uploadSection}
                    showUploadList={false}
                    fileList={fileList}
                    multiple
                  >
                    <p className="ant-upload-drag-icon">
                      <InboxIcon />
                    </p>
                    <p className="ant-upload-text">
                      Click or drag files to this area to upload
                    </p>
                  </Dragger>
                </Form.Item>

                {uploadLoading ? (
                  <div>Please wait while documents get uploaded</div>
                ) : (
                  fileList &&
                  fileList?.length > 0 &&
                  fileList?.map((item: any) => (
                    <div
                      style={{
                        display: "flex",
                        marginLeft: "10px",
                        alignItems: "center",
                      }}
                      key={item.uid}
                    >
                      <Typography className={classes.filename}>
                        <a
                          href={`${API_LINK}${item?.url}`}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          {item?.name}
                        </a>
                      </Typography>

                      <IconButton
                        onClick={() => {
                          // console.log("item click");
                          clearFile(item);
                        }}
                      >
                        <img src={CrossIcon} alt="" />
                      </IconButton>
                    </div>
                  ))
                )}
              </Col>
            </Row>
          </Form>
        </>
      ),
    },
    {
      label: "References",
      key: 3,
      children: (
        <div style={{ position: "absolute" }}>
          <ReferencesTabMrm drawer={drawer} />
        </div>
      ),
    },
  ];

  return (
    <Drawer
      open={open}
      onClose={onClose}
      placement="right"
      title={readMode === true ? "Action Point" : "Edit Action Point"}
      width={580}
      headerStyle={{ backgroundColor: "#E8F3F9", color: "black" }}
      extra={
        <TableCell>
          <Space>
            {readMode === false && (
              <Button
                className={classes.submitBtn}
                type="primary"
                onClick={() => {
                  actionPointSubmitClose();
                }}
              >
                Update
              </Button>
            )}
            <div style={{ display: "flex", gap: "5px" }}>
              <div
                className={classes.text}
                style={{ display: "flex", gap: "5px" }}
              >
                Status
              </div>
              <Switch
                checked={status}
                style={{ backgroundColor: status ? "#003566" : "" }}
                className={classes.switch}
                onChange={onStatusChange}
              />
            </div>
          </Space>
        </TableCell>
      }
    >
      <div style={{ display: "grid", gap: "5px" }}>
        <div className={classes.tabsWrapper} style={{ padding: "10px" }}>
          <Tabs
            type="card"
            items={tabs as any}
            animated={{ inkBar: true, tabPane: true }}
            // tabBarStyle={{backgroundColor : "green"}}
          />
        </div>
      </div>
    </Drawer>
  );
};

export default AddActionPoint;
