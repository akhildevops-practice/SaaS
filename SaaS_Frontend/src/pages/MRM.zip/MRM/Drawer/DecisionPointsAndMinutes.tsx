import React, { useEffect, useRef, useState } from 'react';
import { Form, Input, Row, Col, DatePicker, Select, Upload, Button, Space, Spin } from "antd";
import getAppUrl from "../../../utils/getAppUrl";
import axios from "../../../apis/axios.global";
import { useSnackbar } from "notistack";
import MyEditor from "../Editor";
import { Autocomplete } from "@material-ui/lab";
import MenuItem from '@material-ui/core/MenuItem';
import { makeStyles, Collapse } from "@material-ui/core";
import { MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';
import ArrowDropDown from '../../../assets/TeamDropdown.svg';
import jsPDF from 'jspdf'
import autoTable from 'jspdf-autotable'
import checkRoles from "../../../utils/checkRoles";
import printJS from 'print-js';

const { TextArea } = Input;


type Props = {
    formData?: any;
    setFormData?: any;
};


const useStyles = makeStyles((theme) => ({
    root: {
        width: "100%",
        "& .MuiAccordionDetails-root": {
            display: "block",
        },
    },
    uploadSection: {
        "& .ant-upload-list-item-name": {
            color: "blue !important",
        },
    },
    divAction: {
        display: 'flex',
        alignItems: 'center',
        margin: '20px 0',
    },

    line: {
        width: '49%',
        height: '1px',
        backgroundColor: '#cacaca',

    },
    last: {
        margin: '0 auto',
    },
    arrow: {
        backgroundImage: `url(${ArrowDropDown})`,
        height: '10px',
        width: '10px',
        backgroundRepeat: 'no-repeat',
        backgroundPosition: 'center',
        backgroundSize: '100%',
        margin: '0 10px',
        cursor: 'pointer',
        rotate: '180deg'
    },
    active: {
        rotate: '0deg'
    }

}));

const DecisionPointsAndMinutes = ({
    formData,
    setFormData,
}: Props) => {

    const [firstForm] = Form.useForm();
    const [dataSource, setDataSource] = useState<any>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [collapseDiv, setCollapseDiv] = useState(true);
    const classes = useStyles();
    const isOrgAdmin = checkRoles("ORG-ADMIN");
    const isMR = checkRoles("MR");
    const containerRef = useRef<HTMLDivElement>(null);
    const showData = isOrgAdmin || isMR;



    const orgId = sessionStorage.getItem("orgId");
    const realmName = getAppUrl();
    const { enqueueSnackbar } = useSnackbar();


    useEffect(() => {
        setLoading(true);
        let newData = { ...formData };

        let newDataSource: any = [];

        let datavalues = newData?.dataValue ? newData.dataValue : newData?.keyadendaDataValues ? newData.keyadendaDataValues : []
        if (datavalues && datavalues?.length) {
            newDataSource = datavalues[0] && datavalues[0]?.decisionPoints !== '' && datavalues[0]?.decisionPoints.length ? datavalues[0] && datavalues[0]?.decisionPoints : []
        }
        setDataSource(newDataSource)
        setLoading(false)
        setFormData({ ...formData, decisionPoints: newDataSource })
    }, [])

    useEffect(() => {
        if (containerRef.current && formData?.meetingMOM) {
            containerRef.current.innerHTML = formData?.meetingMOM;
        }
    }, []);



    const onFinish = (values: any) => {
        console.log('Received values of form:', values);
    };

    const toggleDiv = () => {
        setCollapseDiv(!collapseDiv)
    };

    const addData = () => {
        let newSource: any = dataSource && dataSource?.length ? [...dataSource] : [];
        newSource.push({
            decisionPoints: ''
        });


        setDataSource(newSource)
    }



    const removeData = (index: number) => {
        let newDatasource = [...dataSource];
        if (index > -1) { // only splice array when item is found
            newDatasource.splice(index, 1); // 2nd parameter means remove one item only
            setDataSource(newDatasource)
        }
    }

    const exportPdf = () => {

        const tableRows = dataSource.map((row: any, index: number) => {
            return `<tr><td>${index + 1} : ${row.decisionPoints}</td></tr>`
        }).join('');


        const newCont = `<div id="print-content">
                    <p><strong>Meeting Minutes:</strong></p>
                    ${formData?.meetingMOM}
                    <table>
                    <thead>
                    <tr>
                    <th>Decision Points</th>
                    </tr>
                </thead>
                <tbody>
                ${tableRows}
                </tbody></table>
        </div>`;

        if (formData?.meetingMOM && formData?.meetingMOM?.length && dataSource.length) {
            const container = document.createElement('div');
            container.innerHTML = newCont;
            document.body.appendChild(container);
            printJS('print-content', 'html')
            // printJS({
            //     printable: 'print-content',
            //     type: 'html',
            //     style: `
            //       body {
            //         font-family: Arial, sans-serif;
            //       }
            //       p {
            //         font-size: 16px;
            //         color: blue;
            //       }
            //     `,
            // })
        }

    }


    const handleDecisionPoints = (value: any, key: number) => {
        let newDatasource = [...dataSource];
        newDatasource[key].decisionPoints = value;

        setDataSource(newDatasource);
        setFormData({ ...formData, decisionPoints: newDatasource });
    }

    return (
        <> {
            loading ? (
                <Spin style={{ display: 'flex', justifyContent: 'center' }}> </Spin>
            ) : (

                <Form
                    form={firstForm}
                    layout="vertical"
                    // onValuesChange={(changedValues, allValues) => setFormData({ ...formData, points : allValues,  changedValues })}
                    autoComplete="off"
                    onFinish={onFinish}
                // initialValues={{ points: dataSource.length ? [...dataSource] : [] }}
                >
                    <div className={classes.divAction}>
                        <div className={classes.line} />
                        <div className={`${classes.arrow} ${collapseDiv && classes.active}`} onClick={toggleDiv} />
                        <div className={`${classes.line} ${classes.last}`} />
                    </div>
                    <Collapse in={collapseDiv}>
                        <Row gutter={[16, 16]}>
                            <Col span={24}>
                                <Form.List name="points"
                                    initialValue={dataSource}
                                >
                                    {(fields, { add, remove }) => (
                                        <>
                                            {fields.map(({ key, name, ...restField }) => (
                                                <>
                                                    <Row gutter={[16, 16]} key={key}>
                                                        <Col span={20}>
                                                            <Form.Item
                                                                {...restField}
                                                                name={[name, 'decisionPoints']}
                                                                label="Decision Points"
                                                                rules={[{ required: true, message: 'Enter decision points' }]}
                                                            >
                                                                <TextArea disabled={showData ? false : true} placeholder="Enter decision points " onBlur={(e) => handleDecisionPoints(e.target.value, key)} />

                                                            </Form.Item>
                                                        </Col>

                                                        <Col span={2}>

                                                            <MinusCircleOutlined style={{ height: '100%', display: 'flex', alignItems: 'center' }} onClick={() => { showData && remove(name); removeData(name) }} />
                                                        </Col>
                                                    </Row>

                                                </>
                                            ))}
                                            <Form.Item>
                                                <Button type="dashed" onClick={() => { add(); addData() }} block icon={<PlusOutlined />}>
                                                    Add Decision Point
                                                </Button>
                                            </Form.Item>
                                        </>
                                    )}
                                </Form.List>
                            </Col>
                        </Row>
                    </Collapse>



                    <Row gutter={[16, 16]}>
                        <Col span={24}>
                            <Form.Item label="Meeting Minutes">
                                <MyEditor formData={formData} setFormData={setFormData} title="mom" readStatus={undefined} />
                            </Form.Item>
                        </Col>
                    </Row>
                </Form>

            )
        }
            {dataSource?.length > 0 && formData && formData?.meetingMOM && <Button onClick={exportPdf}>Export to pdf</Button>}
        </>
    )
}

export default DecisionPointsAndMinutes;