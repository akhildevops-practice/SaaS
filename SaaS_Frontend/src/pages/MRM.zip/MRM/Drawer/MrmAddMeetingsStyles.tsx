import { makeStyles, Theme } from "@material-ui/core/styles";

const useStylesMrm = makeStyles<Theme>((theme: Theme) => ({
    TabHeaderPageButtons:{
        display:"flex",
        justifyContent: 'space-between',
        paddingLeft:"20px",
        paddingRight:"20px",
        backgroundColor:"#e8f3f9",
        height:"40px",
        alignItems:"center"
    }
}));

export default useStylesMrm;