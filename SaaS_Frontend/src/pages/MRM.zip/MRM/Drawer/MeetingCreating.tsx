import React, { useEffect, useState } from "react";
import {
  List,
  ListItem,
  ListItemText,
  IconButton,
  makeStyles,
} from "@material-ui/core";
import CloseIcon from "@material-ui/icons/Close";
import { Tabs, Space, Button, Tooltip, Grid, Modal, Drawer } from "antd";
import useStyles from "../commonDrawerStyles";
import { TableCell, TableContainer, TableRow } from "@material-ui/core";
import useStylesMrm from "./MrmAddMeetingsStyles";
import modelStyles from "./style";
import MeetingCreatingTab from "./MeetingCreatingTab";
import MeetingCreatingTabTwo from "./MeetingCreatingTabTwo";
import InfoIcon from "@material-ui/icons/Info";
import { createMeeting } from "apis/mrmmeetingsApi";
import { useSnackbar } from "notistack";
import { useNavigate } from "react-router-dom";
import { ReactComponent as ExpandIcon } from "../../../assets/icons/row-expand.svg";
import MeetingCreatingTabThree from "./MeetingCreatingTabThree";
import HindalcoLogoSvg from "assets/logo/HindalcoLogoSvg.svg";
import CloseIconImageSvg from "assets/documentControl/Close.svg";
import getAppUrl from "utils/getAppUrl";
import { API_LINK } from "config";
import { expandCreateMeeting, expandMeetingAgendaData, expandMeetingData } from "recoil/atom";
import { useRecoilState, useResetRecoilState } from "recoil";
import { currentAuditYear, currentLocation } from "recoil/atom";
import getYearFormat from "utils/getYearFormat";

type Props = {
  open: boolean;
  onClose: () => void;
  dataSourceFilter: any;
  valueById: any;
  year: any;
  meeting: any;
  setDrawerOpen: any;
  setLoadMeeting:any,
};
const drawerWidth = 600;
const nestedWidth = 600;
const nestedHeight = 200;
const useStylesClass = makeStyles({
  drawerPaper: {
    width: drawerWidth,
    flexShrink: 0,
    "& .MuiDrawer-paper": {
      width: drawerWidth,
      boxSizing: "border-box",
    },
  },
  drawerPaperSub: {
    width: nestedWidth,
    height: nestedHeight,
    flexShrink: 0,
    "& .MuiDrawer-paper": {
      width: nestedWidth,
      height: nestedHeight,
      boxSizing: "border-box",
    },
  },
  documentTable: {
    "&::-webkit-scrollbar-thumb": {
      borderRadius: "10px",
      backgroundColor: "grey",
    },
  },
  tableContainer: {
    marginTop: "1%",
    maxHeight: "calc(60vh - 14vh)", // Adjust the max-height value as needed
    overflowY: "auto",
    overflowX: "hidden",
    // fontFamily: "Poppins !important",
    "& .ant-table-wrapper .ant-table.ant-table-bordered > .ant-table-container > .ant-table-summary > table > tfoot > tr > td":
      {
        borderInlineEnd: "none",
      },
    "& .ant-table-thead .ant-table-cell": {
      backgroundColor: "#E8F3F9",
      // fontFamily: "Poppins !important",
      color: "#00224E",
    },
    "& span.ant-table-column-sorter-inner": {
      color: "#00224E",
      // color: ({ iconColor }) => iconColor,
    },
    "& span.ant-tag": {
      display: "flex",
      width: "89px",
      padding: "5px 0px",
      justifyContent: "center",
      alignItems: "center",
      borderRadius: "10px",
      color: "white",
    },
    "& .ant-table-wrapper .ant-table-thead>tr>th": {
      position: "sticky", // Add these two properties
      top: 0, // Add these two properties
      zIndex: 2,
      // padding: "12px 16px",
      fontWeight: 600,
      fontSize: "14px",
      padding: "6px 8px !important",
      // fontFamily: "Poppins !important",
      lineHeight: "24px",
    },
    "& .ant-table-tbody >tr >td": {
      // borderBottom: ({ tableColor }) => `1px solid ${tableColor}`, // Customize the border-bottom color here
      borderBottom: "black",
      padding: "4px 8px !important",
    },
    // '& .ant-table-wrapper .ant-table-container': {
    //     maxHeight: '420px', // Adjust the max-height value as needed
    //     overflowY: 'auto',
    //     overflowX: 'hidden',
    // },
    "& .ant-table-body": {
      // maxHeight: '150px', // Adjust the max-height value as needed
      // overflowY: 'auto',
      "&::-webkit-scrollbar": {
        width: "8px",
        height: "10px", // Adjust the height value as needed
        backgroundColor: "#e5e4e2",
      },
      "&::-webkit-scrollbar-thumb": {
        borderRadius: "10px",
        backgroundColor: "grey",
      },
    },
    "& tr.ant-table-row": {
      cursor: "pointer",
      transition: "all 0.1s linear",
    },
  },
});
function MrmAddMeetings({
  open,
  onClose,
  dataSourceFilter,
  valueById,
  year,
  meeting,
  setDrawerOpen,
  setLoadMeeting,
}: Props) {
  const drawerWidth = 600;
  const nestedWidth = 600;
  const nestedHeight = 200;
  const classes = useStyles();
  const modelClass = modelStyles();
  const mrmStyles = useStylesMrm();
  const [formData, setFormData] = useRecoilState(expandMeetingData);
  const [dataForm, setDataForm] = useRecoilState(expandCreateMeeting)
  const resetExpandValues = useResetRecoilState(expandMeetingData);
  const [data, setData] = useState<any>();
  const [index, setIndex] = useState<any>();
  const [nestedOpen, setNestedOpen] = useState(false);
  const userInfo = JSON.parse(sessionStorage.getItem("userDetails") as string);
  const imgUrl = getAppUrl();
  const [addAgendaValues, setAddAgendaValues] = useRecoilState(
    expandMeetingAgendaData
  );
  const resetExpandData = useResetRecoilState(expandMeetingData);
  const resetExpanAgendaData = useResetRecoilState(expandMeetingAgendaData);

  useEffect(() => {
    setFormData({
      ...formData,
      period: dataSourceFilter?.allData?.value?.period,
      createdBy: userInfo?.id,
      organizationId: dataSourceFilter?.allData?.value?.organizationId,
      meetingSchedule: valueById,
      locationId: dataSourceFilter?.allData?.value?.unitId,
    });
  }, [dataSourceFilter]);

  const classStylse = useStylesClass();
 

  const navigate = useNavigate();
  const toggleNestedDrawer = (isOpen: any) => (event: any) => {
    if (
      event &&
      event.type === "keydown" &&
      (event.key === "Tab" || event.key === "Shift")
    ) {
      return;
    }
    setNestedOpen(isOpen);
  };

  const { enqueueSnackbar } = useSnackbar();

  const createMeetingsMrm = () => {
    //console.log("formData in create meeting", formData);
    if (
      formData.meetingName &&
      formData.meetingdate &&
      formData.venue &&
      formData.participants &&
      formData.minutesofMeeting
    ) {
      const payload = {
        ...formData,
        period: dataSourceFilter?.allData?.value?.period,
        createdBy: userInfo?.id,
        organizationId: dataSourceFilter?.allData?.value?.organizationId,
        meetingSchedule: valueById,
        locationId: dataSourceFilter?.allData?.value?.unitId,
        agenda: addAgendaValues,
        year: year,
      };
      createMeeting(payload)
        .then((response: any) => {
          //console.log("response====> api", response);
          resetExpandValues();
          onClose();
          if (response.status === 200 || response.status === 201) {
            enqueueSnackbar(`Meeting Added successfully!`, {
              variant: "success",
            });
            resetExpandValues();
            resetExpandData();
            resetExpanAgendaData();
           setLoadMeeting(true)
          }
        })
        .catch((error) => {
          enqueueSnackbar(`Error creating meeting`, { variant: "error" });
        });
    } else {
      enqueueSnackbar(`Please fill required fields!`, {
        variant: "error",
      });
    }
  };

  console.log();

  const tabs = [
    {
      label: "Meeting",
      key: 1,
      children: (
        <MeetingCreatingTab
          formData={formData}
          setFormData={setFormData}
          data={dataSourceFilter}
          index={index}
          valueById={valueById}
          year={year}
        />
      ),
    },
    {
      label: "Decision",
      key: 2,
      children: (
        <MeetingCreatingTabTwo
          formData={formData}
          setFormData={setFormData}
          data={dataSourceFilter}
          valueById={valueById}
        />
      ),
    },
    {
      label: "Pending Actions",
      key: 3,
      children: (
        <MeetingCreatingTabThree
          data={dataSourceFilter}
          valueById={valueById}
          ownerSourceFilter={undefined}
          option={"Create"}
        />
      ),
    },
  ];
  // console.log("meeting type", dataSourceFilter.allData);
  const unitName = dataSourceFilter?.allData?.systemData.map(
    (item: any) => item.name
  );
  // console.log("userInfo", imgUrl);
  const avatarUrl = userInfo.avatar
    ? `${API_LINK}/${userInfo.avatar}`
    : "https://cdn-icons-png.flaticon.com/512/219/219986.png";

  const info = () => {
    Modal.info({
      title: "Meeting Information",
      mask: false,
      style: {
        top: 0,
        right: -250,
      },
      content: (
        <div>
          <TableRow style={{ padding: "0px" }}>
            <span>Unit :</span>
            <span>{dataSourceFilter?.allData?.unit?.locationName}</span>
          </TableRow>
          <TableRow style={{ padding: "0px" }}>
            <span>Meeting Schedule Title : {""} </span>
            <span>{dataSourceFilter?.title}</span>
          </TableRow>
          <TableRow style={{ padding: "0px" }}>
            <span>Meeting Type :</span>
            <span>{dataSourceFilter?.allData?.meetingType?.name}</span>
          </TableRow>
        </div>
      ),
      onOk() {},
    });
  };

  const expandNavigation = () => {
    setLoadMeeting(true)
  let data = {
      data: dataSourceFilter,
      valueById: valueById,
      year: year,
    }
    setDataForm([...dataForm, data])
    navigate("/mrm/mrmmeetingdetailsdoc", {
      state: {
        data: dataSourceFilter,
        valueById: valueById,
        year: year,
        mrm: meeting,
      },
    });
  };
  return (
    <Drawer
      open={open}
      onClose={() => {
        onClose();
        resetExpandData();
        resetExpanAgendaData();
      }}
      title="Create Meeting"
      placement="right"
      width={600}
      headerStyle={{ backgroundColor: "#E8F3F9", color: "black" }}
      extra={
        <div style={{ display: "grid", gap: "5px" }}>
          <div>
            <TableRow className={mrmStyles.TabHeaderPageButtons}>
              <TableCell>
                <Space>
                  <IconButton onClick={info}>
                    <InfoIcon />
                  </IconButton>
                  <Button
                    className={classes.cancelBtn}
                    onClick={() => {
                      onClose();
                      resetExpandValues();
                      resetExpandData();
                      resetExpanAgendaData();
                    }}
                  >
                    Cancel
                  </Button>
                  <Button
                    className={classes.submitBtn}
                    type="primary"
                    onClick={() => {
                      createMeetingsMrm();
                    }}
                  >
                    Submit
                  </Button>
                  <Tooltip title="Expand Form">
                    <Button
                      onClick={() => {
                        expandNavigation();
                      }}
                    >
                      <ExpandIcon style={{ height: "23px" }} />
                    </Button>
                  </Tooltip>
                </Space>
              </TableCell>
            </TableRow>
          </div>
          <div>
            <Modal></Modal>
          </div>
        </div>
      }
    >
      <div className={classes.tabsWrapper} style={{ position: "relative" }}>
        <Tabs
          type="card"
          items={tabs as any}
          animated={{ inkBar: true, tabPane: true }}
          // tabBarStyle={{backgroundColor : "green"}}
        />
        <div style={{ position: "absolute", top: "2px", right: "10px" }}>
          <div
            style={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              height: "40px",
              width: "150px",
              gap: "8px",
            }}
          >
            <div style={{ marginTop: "4px" }}>
              <img
                src={avatarUrl}
                alt="hello"
                width="35px"
                height="35px"
                style={{ borderRadius: "20px" }}
              />
            </div>
            <div style={{ fontSize: "12px" }}>
              <p style={{ margin: "0" }}>{userInfo.username}</p>
              <p style={{ margin: "0" }}> Meeting Owner</p>
            </div>
          </div>
        </div>
      </div>
    </Drawer>
  );
}

MrmAddMeetings.propTypes = {};

export default MrmAddMeetings;
