import React, { useEffect, useState } from "react";
import {
  List,
  ListItem,
  ListItemText,
  IconButton,
  makeStyles,
} from "@material-ui/core";
import CloseIcon from "@material-ui/icons/Close";
import { Tabs, Space, Button, Tooltip, Grid, Drawer, Modal } from "antd";
import useStyles from "../commonDrawerStyles";
import { TableCell, TableContainer, TableRow } from "@material-ui/core";
import useStylesMrm from "./MrmAddMeetingsStyles";
import MeetingEditingTab from "./MeetingEditingTab";
import MeetingEditingTabTwo from "./MeetingEditingTabTwo";
import InfoIcon from "@material-ui/icons/Info";
import { createMeeting, updateMeeting } from "apis/mrmmeetingsApi";
import { ReactComponent as ExpandIcon } from "../../../assets/icons/row-expand.svg";
import { useNavigate } from "react-router-dom";
import SyncAltSharpIcon from "@material-ui/icons/SyncAltSharp";
import { useSnackbar } from "notistack";
import MeetingCreatingTabThree from "./MeetingCreatingTabThree";
import { API_LINK } from "config";
import { useRecoilState, useResetRecoilState } from "recoil";
import {
  expandMeetingAgendaData,
  expandMeetingData,
  expandMeetingEditData,
} from "recoil/atom";

type Props = {
  open: boolean;
  onClose: () => void;
  dataSourceFilter: any;
  editDataMeeting: any;
  ownerSourceFilter: any;
  valueById: any;
  year: any;
  readMode: any;
  meeting: any;
  setLoadMeeting:any;
};
const drawerWidth = 600;
const nestedWidth = 600;
const nestedHeight = 200;
const useStylesClass = makeStyles({
  drawerPaper: {
    width: drawerWidth,
    flexShrink: 0,
    "& .MuiDrawer-paper": {
      width: drawerWidth,
      boxSizing: "border-box",
    },
  },
  submitBtn: {
    backgroundColor: "#003566 !important",
    height: "36px",
    color: "#fff",
  },
  drawerPaperSub: {
    width: nestedWidth,
    height: nestedHeight,
    flexShrink: 0,
    "& .MuiDrawer-paper": {
      width: nestedWidth,
      height: nestedHeight,
      boxSizing: "border-box",
    },
  },
  documentTable: {
    "&::-webkit-scrollbar-thumb": {
      borderRadius: "10px",
      backgroundColor: "grey",
    },
  },
  tableContainer: {
    marginTop: "1%",
    maxHeight: "calc(60vh - 14vh)", // Adjust the max-height value as needed
    overflowY: "auto",
    overflowX: "hidden",
    // fontFamily: "Poppins !important",
    "& .ant-table-wrapper .ant-table.ant-table-bordered > .ant-table-container > .ant-table-summary > table > tfoot > tr > td":
      {
        borderInlineEnd: "none",
      },
    "& .ant-table-thead .ant-table-cell": {
      backgroundColor: "#E8F3F9",
      // fontFamily: "Poppins !important",
      color: "#00224E",
    },
    "& span.ant-table-column-sorter-inner": {
      color: "#00224E",
      // color: ({ iconColor }) => iconColor,
    },
    "& span.ant-tag": {
      display: "flex",
      width: "89px",
      padding: "5px 0px",
      justifyContent: "center",
      alignItems: "center",
      borderRadius: "10px",
      color: "white",
    },
    "& .ant-table-wrapper .ant-table-thead>tr>th": {
      position: "sticky", // Add these two properties
      top: 0, // Add these two properties
      zIndex: 2,
      // padding: "12px 16px",
      fontWeight: 600,
      fontSize: "14px",
      padding: "6px 8px !important",
      // fontFamily: "Poppins !important",
      lineHeight: "24px",
    },
    "& .ant-table-tbody >tr >td": {
      // borderBottom: ({ tableColor }) => `1px solid ${tableColor}`, // Customize the border-bottom color here
      borderBottom: "black",
      padding: "4px 8px !important",
    },
    // '& .ant-table-wrapper .ant-table-container': {
    //     maxHeight: '420px', // Adjust the max-height value as needed
    //     overflowY: 'auto',
    //     overflowX: 'hidden',
    // },
    "& .ant-table-body": {
      // maxHeight: '150px', // Adjust the max-height value as needed
      // overflowY: 'auto',
      "&::-webkit-scrollbar": {
        width: "8px",
        height: "10px", // Adjust the height value as needed
        backgroundColor: "#e5e4e2",
      },
      "&::-webkit-scrollbar-thumb": {
        borderRadius: "10px",
        backgroundColor: "grey",
      },
    },
    "& tr.ant-table-row": {
      cursor: "pointer",
      transition: "all 0.1s linear",
    },
  },
});

function MrmAddMeetings({
  open,
  onClose,
  dataSourceFilter,
  editDataMeeting,
  ownerSourceFilter,
  valueById,
  year,
  readMode,
  meeting,
  setLoadMeeting,
}: Props) {
  const classes = useStyles();
  const mrmStyles = useStylesMrm();
  const [formData, setFormData] = useRecoilState(expandMeetingEditData);
  const [addAgendaValues, setAddAgendaValues] = useRecoilState(
    expandMeetingAgendaData
  );
  const resetExpandData = useResetRecoilState(expandMeetingEditData);
  const resetExpanAgendaData = useResetRecoilState(expandMeetingAgendaData);
  const [data, setData] = useState<any>();
  const [index, setIndex] = useState<any>();
  const [nestedOpen, setNestedOpen] = useState(false);
  const userInfo = JSON.parse(sessionStorage.getItem("userDetails") as string);

  const dateString = editDataMeeting && editDataMeeting?.meetingdate;
  const finaldateTime = dateString?.substring(
    0,
    dateString && dateString?.length - 5
  );

  const { enqueueSnackbar } = useSnackbar();

  useEffect(() => {
    setAddAgendaValues(dataSourceFilter?.agenda);
  }, [dataSourceFilter]);


  const createMeetingsMrm = () => {
    const updateForm = {
      ...formData,
      agenda : addAgendaValues,
    };

    if (formData.meetingName && formData.meetingdate) {
      updateMeeting(editDataMeeting._id, updateForm).then((response: any) => {
        // console.log("response====>update api", response);
        resetExpandData();
        if (response.status === 200 || response.status === 201) {
          enqueueSnackbar(`Data Added successfully!`, {
            variant: "success",
          });
          onClose();
          setLoadMeeting(true)
        }
      });
    } else {
      enqueueSnackbar(`Please fill required fields!`, { variant: "error" });
    }
  };
  const navigate = useNavigate();
  const classStylse = useStylesClass();
  const tabs = [
    {
      label: "Meeting",
      key: 1,
      children: (
        <MeetingEditingTab
          formData={formData}
          setFormData={setFormData}
          data={dataSourceFilter}
          index={index}
          editDataMeeting={editDataMeeting}
          readMode={readMode}
        />
      ),
    },
    {
      label: "Decision",
      key: 2,
      children: (
        <MeetingEditingTabTwo
          formData={formData}
          setFormData={setFormData}
          data={dataSourceFilter}
          ownerSourceFilter={ownerSourceFilter}
          valueById={valueById}
          readMode={readMode}
        />
      ),
    },
    {
      label: "Pending Actions",
      key: 3,
      children: (
        <MeetingCreatingTabThree
          data={dataSourceFilter}
          valueById={valueById}
          ownerSourceFilter={ownerSourceFilter}
          option={"Edit"}
        />
      ),
    },
  ];


  const unitName =
    dataSourceFilter &&
    dataSourceFilter?.allData?.systemData?.map((item: any) => item.name);
  const avatarUrl = userInfo.avatar
    ? `${API_LINK}/${userInfo.avatar}`
    : "https://cdn-icons-png.flaticon.com/512/219/219986.png";

  const info = () => {
    Modal.info({
      title: "Meeting Information",
      mask: false,
      style: {
        top: 0,
        right: -250,
      },
      content: (
        <div>
          <TableRow style={{ padding: "0px" }}>
            <span>Unit :</span>
            <span>{ownerSourceFilter?.unit?.locationName}</span>
          </TableRow>
          <TableRow style={{ padding: "0px" }}>
            <span>Meeting Schedule Title : {""} </span>
            <span> {dataSourceFilter?.meetingSchedule?.meetingName}</span>
          </TableRow>
          <TableRow style={{ padding: "0px" }}>
            <span>Meeting Type :</span>
            <span>{ownerSourceFilter?.meetingType?.name}</span>
          </TableRow>
        </div>
      ),
      onOk() {},
    });
  };


  return (
    <Drawer
      title={readMode === true ? "Meeting" : "Edit Meeting"}
      open={open}
      onClose={() => {
        onClose();
        resetExpandData();
        resetExpanAgendaData();
      }}
      placement="right"
      width={600}
      headerStyle={{ backgroundColor: "#E8F3F9", color: "black" }}
      extra={
        <TableCell>
          <Space>
            <IconButton onClick={info}>
              <InfoIcon />
            </IconButton>
            {readMode === false ? (
              <>
                <Button
                  className={classes.cancelBtn}
                  onClick={() => {
                    onClose();
                    resetExpandData();
                    resetExpanAgendaData();
                  }}
                >
                  Cancel
                </Button>
                <Button
                  className={classes.submitBtn}
                  type="primary"
                  onClick={() => {
                    createMeetingsMrm();
                  }}
                  // disabled={readMode}
                >
                  Update
                </Button>
              </>
            ) : (
              <></>
            )}
            <Tooltip title="Expand Form">
              <Button
                // style={{width:"30px"}}
                // className={classes.expandIcon}
                onClick={() =>{
                  navigate("/mrm/mrmmeetingdetailseditdoc", {
                    state: {
                      state: {
                        data: dataSourceFilter,
                        valueById: valueById,
                        year: year,
                        editDataMeeting: editDataMeeting,
                        ownerSourceFilter: ownerSourceFilter,
                        readMode: readMode,
                        mrm: meeting,
                      },
                    },
                  });
                  setLoadMeeting(true);
                }
                }
              >
                <ExpandIcon style={{ height: "23px" }} />
                {/* <SyncAltSharpIcon /> */}
              </Button>
            </Tooltip>
          </Space>
        </TableCell>
      }
    >
      <div>
        <div style={{ display: "grid", gap: "5px" }}>
          <div className={classes.tabsWrapper} style={{ position: "relative" }}>
            <Tabs
              type="card"
              items={tabs as any}
              animated={{ inkBar: true, tabPane: true }}
              // tabBarStyle={{backgroundColor : "green"}}
            />
            <div style={{ position: "absolute", top: "2px", right: "10px" }}>
              <div
                style={{
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "center",
                  alignItems: "center",
                  height: "40px",
                  width: "150px",
                  gap: "8px",
                }}
              >
                <div style={{ marginTop: "4px" }}>
                  <img
                    src={avatarUrl}
                    alt="hello"
                    width="35px"
                    height="35px"
                    style={{ borderRadius: "20px" }}
                  />
                </div>
                <div style={{ fontSize: "12px" }}>
                  <p style={{ margin: "0" }}>{userInfo.username}</p>
                  <p style={{ margin: "0" }}> Meeting Owner</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Drawer>
  );
}

MrmAddMeetings.propTypes = {};

export default MrmAddMeetings;
