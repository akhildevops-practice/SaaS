import React, { useEffect, useState } from "react";
import { Form, Input, Row, Col, DatePicker, Select, Upload } from "antd";
import type { DatePickerProps } from "antd";
import getAppUrl from "../../../utils/getAppUrl";
import axios from "../../../apis/axios.global";
import { useSnackbar } from "notistack";
import MyEditor from "../Editor";
import {
  makeStyles,
  TextField,
  Typography,
  IconButton,
  Grid,
  Tooltip,
  Button,
} from "@material-ui/core";
import { API_LINK } from "../../../config";
import type { UploadProps } from "antd";
import InboxIcon from "@material-ui/icons/Inbox";
import CrossIcon from "../../../assets/icons/BluecrossIcon.svg";
import checkRoles from "../../../utils/checkRoles";
import moment from "moment";
import { currentAuditYear, currentLocation } from "recoil/atom";
import getYearFormat from "utils/getYearFormat";
import dayjs from "dayjs";
import { getAgendaByMeetingType } from "apis/mrmagendapi";

const { Option } = Select;
const { Dragger } = Upload;

type Props = {
  formData?: any;
  setFormData?: any;
  mode?: any;
  scheduleData: any;
  unitSystemData: any;
  mrmEditOptions: any;
};

const useStyles = makeStyles((theme) => ({
  submitBtn: {
    backgroundColor: "#003566 !important",
    height: "36px",
    color: "#fff",
  },
  formTextPadding: {
    paddingBottom: theme.typography.pxToRem(10),
    fontSize: theme.typography.pxToRem(14),
    color: "#003566",
  },
  asterisk: {
    color: "red",
    verticalAlign: "end",
  },
  labelStyle: {
    "& .ant-input-lg": {
      border: "1px solid #dadada",
    },
    "& .ant-form-item .ant-form-item-label > label": {
      color: "#003566",
      fontWeight: "bold",
      letterSpacing: "0.8px",
    },
  },
  label: {
    verticalAlign: "middle",
  },
  root: {
    width: "100%",
    "& .MuiAccordionDetails-root": {
      display: "block",
    },
  },
  uploadSection: {
    "& .ant-upload-list-item-name": {
      color: "blue !important",
    },
  },
  filename: {
    fontSize: theme.typography.pxToRem(12),
    color: theme.palette.primary.light,
    textOverflow: "ellipsis",
    overflow: "hidden",
    width: "160px",
    whiteSpace: "nowrap",
  },
  dateField: {
    marginTop: "-8px",
  },
}));

const periodArray = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

const MeetingAgenda = ({
  formData,
  setFormData,
  mode,
  scheduleData,
  unitSystemData,
  mrmEditOptions,
}: Props) => {
  const [firstForm] = Form.useForm();
  let previousData = { ...formData };
  const isOrgAdmin = checkRoles("ORG-ADMIN");
  const isMR = checkRoles("MR");
  const { RangePicker } = DatePicker;
  const showData = isOrgAdmin || isMR;
  const classes = useStyles();
  const [dataSource, setDataSource] = useState<any[]>([]);
  const [selectedUnit, setSelectedUnit] = useState<string>(
    previousData?.unit || ""
  );
  const [units, setUnits] = useState<any[]>(previousData?.units || []);
  const [loading, setLoading] = useState<boolean>(false);
  const [systemData, setSystemData] = useState<any[]>([]);
  const [selectedSystem, setSelectedSystem] = useState<any[]>(
    previousData?.system || []
  );
  const [meetingTypeData, setMeetingTypeData] = useState<any[]>([]);
  const [selectedMeetingType, setSelectedMeetingType] = useState<any>("");
  const [selectedMeetingId, setSelectedMeetingId] = useState<any>("");
  const [allPeriods, setPeriods] = useState<any[]>([]);
  const [uploadFileError, setUploadFileError] = useState<any>(false);
  const [fileList, setFileList] = useState<any[]>([]);
  const [dateTime, setDateTime] = useState<any>(null);
  const [uploadLoading, setUploadLoading] = useState<boolean>(false);
  const [settings, setSettings] = useState<string>("");
  const [currentYear, setCurrentYear] = useState<any>();
  const [readStatus, setReadStatus] = useState(false);
  const [documentForm] = Form.useForm();

  const unitFilterBy = units.filter(
    (item: any) => item.id === unitSystemData.unit
  );

  // console.log("formData====>",formData)
  // console.log("formData====>",scheduleData)

  useEffect(() => {
    if (mrmEditOptions === "ReadOnly") {
      setReadStatus(true);
    }
  }, [mrmEditOptions]);
  const orgId = sessionStorage.getItem("orgId");
  const userInfo = JSON.parse(sessionStorage.getItem("userDetails") as string);

  const realmName = getAppUrl();
  const { enqueueSnackbar } = useSnackbar();
  const getyear = async () => {
    const currentyear = await getYearFormat(new Date().getFullYear());
    setCurrentYear(currentyear);
  };

  useEffect(() => {
    getAgendaByMeetingType(scheduleData?._id).then((response: any) => {
      if (response.data) {
        setFormData({
          ...formData,
          agendaformeetingType: response && response?.data,
          unit: unitFilterBy[0]?.id,
          meetingType: scheduleData?._id,
        });
      }
    });
  }, [scheduleData]);
  // console.log("formdata 2", scheduleData);

  useEffect(() => {
    orgdata();
    // console.log("set orgdata", scheduleData);
    getyear();
    // console.log("set year", scheduleData);
    getUnits();
    //console.log("set units", scheduleData);
    // if (mrmEditOptions === "MrmPlan") {
    //   firstForm.setFieldsValue({
    //     organizer: userInfo?.userName,
    //     unit: unitFilterBy[0]?.id || null,
    //     system: previousData?.system,
    //     meetingTitle: previousData?.meetingTitle || null,
    //     meetingType: scheduleData?._id || null,
    //     period: previousData?.period || null,
    //     meetingDesc: previousData?.meetingDescription || "",
    //     date: previousData?.date || null,
    //   });
    // } else {
    firstForm.setFieldsValue({
      organizer: userInfo?.userName,
      unit: previousData?.unit || null,
      system: previousData?.system || [],
      meetingTitle: previousData?.meetingTitle || null,
      meetingType: previousData?.meetingType || null,
      period: previousData?.period || null,
      meetingDesc: previousData?.meetingDescription || "",
      date: previousData?.date || null,
    });
    // console.log("first first", formData);
    // }
    if (previousData?.files && previousData?.files?.length > 0) {
      firstForm.setFieldsValue({ files: previousData?.files });
      setFileList([...previousData?.files]);
      setFormData({ ...formData, files: previousData?.files });
    }
    // console.log("first second", formData);
    if (previousData?.date) {
      // let date = moment(previousData?.date);
      // var dateComponent = date.format("YYYY-MM-DD");
      // var timeComponent = date.format("HH:mm");
      // setDateTime(`${dateComponent}T${timeComponent}`);
      // firstForm.setFieldsValue({ date: `${dateComponent}T${timeComponent}` });
      const [start, end] = previousData?.date; // Destructure values to get the start and end moments
      const startDate = start.format("DD-MM-YYYY");
      const endDate = end.format("DD-MM-YYYY");

      // firstForm.setFieldsValue({ date: [startDate, endDate] });
      setFormData({ ...formData, date: [startDate, endDate] });
    }

    setFormData({ ...formData, organizer: userInfo?.userName || "" });
    if (previousData?.unit) {
      getApplicationSystems(previousData?.unit);
      getKeyAgendaByLocation(previousData?.unit, currentYear);
    }
    if (previousData?.system && previousData?.system?.length) {
      getKeyAgendaValues(previousData?.system);
    }
    if (previousData?.meetingType) {
      getAgendaDataMeetingById(previousData?.meetingType);
      setFormData({ ...formData, date: previousData?.date });
    }
  }, []);
  //console.log("formdata3", formData);

  useEffect(() => {
    getyear();
    if (!!previousData?.unit && currentYear !== undefined) {
      getKeyAgendaByLocation(previousData?.unit, currentYear);
    }
  }, [formData?.unit, currentYear]);
  useEffect(() => {
    //getAgendaByMeetingType(formData.meetingType);

    if (!!selectedMeetingType) {
      getAgendaDataMeetingById(selectedMeetingType);
      getPeriodsData();
    }
  }, [selectedMeetingType]);
  const orgdata = async () => {
    const response = await axios.get(`/api/organization/${realmName}`);

    if (response.status === 200 || response.status === 201) {
      setSettings(response?.data?.fiscalYearQuarters);
    }
  };
  const getUnits = async () => {
    setLoading(true);
    await axios(`/api/location/getLocationsForOrg/${realmName}`)
      .then((res) => {
        setUnits(res?.data);
        setLoading(false);
        setFormData({ ...formData, units: res?.data });
      })
      .catch((err) => {
        setLoading(false);
        console.error(err);
      });
  };
  useEffect(() => {
    getPeriodsDataAll();
    getApplicationSystems(unitFilterBy[0]?.id);
    getApplicationSystemsPlan();
  }, [scheduleData]);

  const getApplicationSystemsPlan = async () => {
    let encodedSystems = scheduleData?.mrmData?.unitId
      ? encodeURIComponent(JSON.stringify(scheduleData?.mrmData?.unitId))
      : null;
    const { data } = await axios.get(
      `api/systems/displaySystems/${encodedSystems}`
    );

    if (data && data?.length) {
      setSystemData([...data]);
    } else {
      setSystemData([]);
    }
  };
  const getPeriodsDataAll = async () => {
    try {
      await axios(`/api/mrm/getPeriodForMeetingType/${scheduleData._id}`).then(
        (res) => {
          let allPeriods = res?.data;
          if (settings === "Jan - Dec" && allPeriods?.length) {
            allPeriods?.sort(function (a: any, b: any) {
              return periodArray.indexOf(a) - periodArray.indexOf(b);
            });
          }
          const orderedMonthNames = [
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December",
          ];
          const sortedMonthNames = allPeriods?.sort((a: any, b: any) => {
            return (
              orderedMonthNames?.indexOf(a) - orderedMonthNames?.indexOf(b)
            );
          });
          setPeriods(sortedMonthNames);
        }
      );
    } catch (error) {
      console.log(error);
    }
  };

  const getPeriodsData = async () => {
    try {
      await axios(
        `/api/mrm/getPeriodForMeetingType/${selectedMeetingType}`
      ).then((res) => {
        let allPeriods = res.data;
        if (settings === "Jan - Dec" && allPeriods?.length) {
          allPeriods?.sort(function (a: any, b: any) {
            return periodArray?.indexOf(a) - periodArray?.indexOf(b);
          });
        }
        setPeriods(allPeriods);
      });
    } catch (error) {
      console.log(error);
    }
  };

  const getApplicationSystems = async (locationId: any) => {
    let encodedSystems = locationId
      ? encodeURIComponent(JSON.stringify(locationId))
      : null;

    if (encodedSystems && encodedSystems?.length) {
      const { data } = await axios.get(
        `api/systems/displaySystems/${encodedSystems}`
      );
      if (data && data?.length) {
        setSystemData([...data]);
      } else {
        setSystemData([]);
      }
    }
  };

  const handleChangeSystem = (value: string[]) => {
    setSelectedSystem(value);

    setFormData({
      ...formData,
      system: value,
    });
    if (mrmEditOptions === "MrmPlan") {
      setFormData({
        ...formData,
        system: value,
        meetingType: scheduleData?._id,
        unit: scheduleData?.mrmData?.unitId,
      });
    }
    // getKeyAgendaValues(value);
  };
  const handleChangeMeetingType = (value: string) => {
    setSelectedMeetingType(value);
    // getPeriodsData();
    setFormData({ ...formData, meetingType: value });
  };

  const getKeyAgendaByLocation = async (data: any, currentYear: any) => {
    try {
      let res: any;

      let location = [data];

      if (location?.includes("All") || location?.length === 0) {
        const payload = {
          orgId: orgId,
          currentYear: currentYear,
        };

        res = await axios.get("/api/keyagenda/getkeyAgendaByOrgId", {
          params: payload,
        });
      } else {
        //const locationValues = [...location].map((option: any) => option.id);

        const payloadData = {
          orgId: orgId,
          locationId: location,
          currentYear: currentYear,
        };

        res = await axios.get("/api/keyagenda/getkeyAgendaByUnit", {
          params: payloadData,
        });
      }
      if (res.status === 200 || res.status === 201) {
        const data = res.data;

        setMeetingTypeData(data);
        //setFormData({ ...formData, agendaformeetingType: data });
      }
    } catch (error) {
      console.log(error);
    }
  };

  const getAgendaDataMeetingById = (meetingType: any) => {
    getAgendaByMeetingType(meetingType).then((response: any) => {
      if (response.data) {
        setFormData({ ...formData, agendaformeetingType: response.data });
      }
    });
  };

  const getKeyAgendaValues = async (data: any) => {
    try {
      setLoading(true);
      //get api

      if (data && data?.length && selectedUnit) {
        const payload = {
          orgId: orgId,
          unitId: [selectedUnit],
          applicationSystemID: data && data?.length ? [...data] : [],
        };
        const res = await axios.get("api/keyagenda/getSchedulePeriodUnit", {
          params: payload,
        });
        if (res.status === 200 || res.status === 201) {
          const data = res.data;
          let allPeriods = res?.data?.period;

          if (settings === "Jan - Dec" && allPeriods?.length) {
            allPeriods?.sort(function (a: any, b: any) {
              return periodArray?.indexOf(a) - periodArray?.indexOf(b);
            });
          }

          //setPeriods(allPeriods || []);
          setDataSource(data?.data || []);
          setLoading(false);
        }
      }
    } catch (error) {
      console.log(error);
      setLoading(false);
      enqueueSnackbar(`!`, {
        variant: "error",
      });
    }
  };

  const handleChange = (value: string) => {
    setSelectedUnit(value);
    setFormData({ ...formData, unit: value });
    getApplicationSystems(value);
  };

  const handleKeyAgenda = (data: any) => {
    getKeyAgendaValues(selectedSystem);
  };
  const handleDateRange = (values: any) => {
    if (!values || !Array.isArray(values)) {
      // Handle the case where values is not defined or not an array

      enqueueSnackbar("select a valid date range", { variant: "error" });
      return;
    }
    const [start, end] = values; // Destructure values to get the start and end moments
    const startDate = start?.format("YYYY-MM-DD");
    const endDate = end?.format("YYYY-MM-DD");
    const date = {
      startDate: startDate,
      endDate: endDate,
    };

    setFormData({
      ...formData,
      date: date,
      startDate: startDate,
      toDate: endDate,
    });
  };

  const uploadFileprops: UploadProps = {
    action: "https://www.mocky.io/v2/5cc8019d300000980a055e76",
    multiple: true,
    beforeUpload: () => false,
    onChange({ file, fileList }) {
      setFileList(fileList);
    },
  };

  const addSelectedFiles = async (fileList: any) => {
    setUploadLoading(true);

    // Create FormData to send multiple files
    const formDataFiles = new FormData();
    fileList.forEach((file: any) => {
      formDataFiles.append("files", file.originFileObj || file);
    });
    if (previousData?.files && previousData?.files?.length > 0) {
      // If previousData has files, append new files to existing files
      setFileList((prevFileList: any) => [...prevFileList, ...fileList]);
      setFormData((prevFormData: any) => ({
        ...prevFormData,
        files: [...prevFormData?.files, ...fileList],
      }));
    } else {
      // If previousData doesn't have files, set new files directly
      setFileList([...fileList]);
      setFormData((prevFormData: any) => ({
        ...prevFormData,
        files: [...fileList],
      }));
    }
    if (process.env.REACT_APP_IS_OBJECT_STORAGE) {
      try {
        const res = await axios.post(
          `${API_LINK}/api/mrm/attachment`,
          formDataFiles,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          }
        );
        // console.log("res in regular", res);
        if (res.status === 200 || res.status === 201) {
          const updatedFiles = res?.data?.map((data: any, index: number) => ({
            uid: `-${index}`,
            name: data?.name,
            url: data?.path,
            //status: "done",
          }));

          // No need to update fileList and formData again here
        }
      } catch (error) {
        enqueueSnackbar("Error uploading files:", { variant: "error" });
      }
    } else {
      try {
        const res = await axios.post(
          `${API_LINK}/api/mrm/objectStore`,
          formDataFiles,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          }
        );
        //  console.log("res in regular", res);
        if (res.status === 200 || res.status === 201) {
          const updatedFiles = res?.data?.map((data: any, index: number) => ({
            uid: `-${index}`,
            name: data?.name,
            url: data?.path,
            //status: "done",
          }));

          // No need to update fileList and formData again here
        }
      } catch (error) {
        enqueueSnackbar("Error uploading files:", { variant: "error" });
      }
    }
  };

  const clearFile = async (data: any) => {
    try {
      // console.log("data", data);
      if (data && data?.uid) {
        setFileList((previousFiles) =>
          previousFiles?.filter((item: any) => item.uid !== data.uid)
        );
        //console.log("filelist after update", fileList);
        setFormData((prevFormData: any) => ({
          ...prevFormData,
          files: prevFormData?.files?.filter(
            (item: any) => item.uid !== data.uid
          ),
        }));

        // Assuming data.uid is a valid identifier for your file
        let result = await axios.post(`${API_LINK}/api/mrm/attachment/delete`, {
          path: data.uid,
        });
        return result;
      }
    } catch (error) {
      return error;
    }
  };

  const handleChangePeriod = (data: any) => {
    // console.log("datasource", data);
    let newDataSource: any[] = [...dataSource];
    // console.log("new dat source value", newDataSource);
    // console.log("data", data);
    let DataSource = newDataSource.filter(
      (item: any) => item?.mrmData?.period && item.mrmData.period.includes(data)
    );

    setFormData({
      ...formData,
      keyadendaDataValues: DataSource,
      period: data,
      // dataValue: DataSource,
    });
  };

  const handleChangeDateTime = (event: any) => {
    setFormData({ ...formData, date: event.target.value || null });
    setDateTime(event.target.value || null);
  };

  return (
    <>
      <Form
        form={firstForm}
        layout="vertical"
        onValuesChange={(changedValues, allValues) =>
          setFormData({ ...formData, allValues, changedValues })
        }
        initialValues={formData}
      >
        <Row gutter={[16, 16]}>
          <Col span={10}>
            {mrmEditOptions === "MrmPlan" ? (
              <>
                <Grid item sm={12} md={5} className={classes.formTextPadding}>
                  <strong>
                    {/* <span className={classes.asterisk}>*</span>{" "} */}
                    <span className={classes.label}>Select Unit: </span>
                  </strong>
                </Grid>
                <Form.Item
                  // label="Select Unit: "
                  // name="unit"
                  // tooltip="This is a required field"
                  rules={[{ required: true, message: "Please Select Unit!" }]}
                >
                  <Input
                    value={unitFilterBy[0]?.locationName || ""}
                    disabled={true}
                    placeholder={unitFilterBy[0]?.locationName || ""}
                  />
                </Form.Item>
              </>
            ) : (
              <>
                <Grid item sm={12} md={5} className={classes.formTextPadding}>
                  <strong>
                    <span className={classes.asterisk}>*</span>{" "}
                    <span className={classes.label}>Select Unit: </span>
                  </strong>
                </Grid>
                <Form.Item
                  // label="Select Unit: "
                  name="unit"
                  // tooltip="This is a required field"
                  rules={[{ required: true, message: "Please Select Unit!" }]}
                >
                  <Select
                    allowClear
                    style={{ width: "100%" }}
                    placeholder="Please select unit"
                    onChange={handleChange}
                    disabled={
                      readStatus || mrmEditOptions === "Edit" ? true : false
                    }
                  >
                    {units?.length &&
                      units?.map((data) => {
                        return (
                          <Option value={data?.id} key={data?.id}>
                            {data?.locationName}
                          </Option>
                        );
                      })}
                  </Select>
                </Form.Item>
              </>
            )}
          </Col>
          <Col span={14}>
            {/* {mrmEditOptions === "MrmPlan" ? (
              <>
                <Grid item sm={12} md={5} className={classes.formTextPadding}>
                  <strong>
                    <span className={classes.asterisk}>*</span>{" "}
                    <span className={classes.label}>Select System: </span>
                  </strong>
                </Grid>
                <Form.Item
                  // label="Select System: "
                  name="system"
                  // tooltip="This is a required field"
                  rules={[{ required: true, message: "Please Select System!" }]}
                >
                  <Select
                    mode="multiple"
                    allowClear
                    style={{ width: "100%" }}
                    placeholder="Please select system"
                    onChange={handleChangeSystem}
                    // disabled={showData ? false : true}
                    onBlur={handleKeyAgenda}
                  >
                    {scheduleData?.applicableSystem.map((data: any) => {
                      return (
                        <Option value={data?.id} key={data?.id}>
                          {data?.name}
                        </Option>
                      );
                    })}
                  </Select>
                </Form.Item>
              </>
            ) : (
              <>
                {systemData && systemData.length > 0 && (
                  <> */}
            <Grid item sm={12} md={5} className={classes.formTextPadding}>
              <strong>
                <span className={classes.asterisk}>*</span>{" "}
                <span className={classes.label}>Select System: </span>
              </strong>
            </Grid>
            <Form.Item
              // label="Select System: "
              name="system"
              // tooltip="This is a required field"
              rules={[{ required: true, message: "Please Select System!" }]}
            >
              <Select
                mode="multiple"
                allowClear
                style={{ width: "100%" }}
                placeholder="Please select system"
                onChange={handleChangeSystem}
                // disabled={showData ? false : true}
                onBlur={handleKeyAgenda}
                disabled={
                  readStatus || mrmEditOptions === "Edit" ? true : false
                }
              >
                {systemData.map((data) => {
                  return (
                    <Option value={data?.id} key={data?.id}>
                      {data?.name}
                    </Option>
                  );
                })}
              </Select>
            </Form.Item>
            {/* </>
                )}
              </>
            )} */}
          </Col>
        </Row>

        <Row gutter={[16, 16]}>
          <Col span={24}>
            <Grid item sm={12} md={5} className={classes.formTextPadding}>
              <strong>
                <span className={classes.asterisk}>*</span>{" "}
                <span className={classes.label}>Schedule Title </span>
              </strong>
            </Grid>
            <Form.Item
              // label="Meeting Title"
              name="meetingTitle"
              // tooltip="This is a required field"
              rules={[
                { required: true, message: "Please Select Schedule Title!" },
              ]}
            >
              <Input
                placeholder="Enter Schedule name"
                //disabled={showData ? false : true}
                onBlur={(e) =>
                  setFormData({ ...formData, meetingTitle: e.target.value })
                }
                disabled={readStatus}
              />
            </Form.Item>
          </Col>

          {/* <Col span={8}>
          <Form.Item
            label="Meeting Date: "
            name="date"
            // tooltip="This is a required field"
            rules={[{ required: true, message: "Please Select Date!" }]}
          >
            <TextField
              fullWidth
              className={classes.dateField}
              type="datetime-local"
              name="time"
              disabled={showData ? false : true}
              value={dateTime}
              defaultValue={dateTime}
              variant="outlined"
              onChange={(e) => handleChangeDateTime(e)}
              size="small"
              required
            />
          </Form.Item>
        </Col> */}
        </Row>

        <Row gutter={[16, 16]}>
          <Col span={14}>
            {mrmEditOptions === "MrmPlan" ? (
              <>
                <Grid item sm={12} md={5} className={classes.formTextPadding}>
                  <strong>
                    {/* <span className={classes.asterisk}>*</span>{" "} */}
                    <span className={classes.label}> Meeting Type:</span>
                  </strong>
                </Grid>
                <Form.Item
                  // label="Select Meeting Type: "
                  // name="meetingType"
                  // tooltip="This is a required field"
                  rules={[
                    { required: true, message: "Please Select Meeting Type!" },
                  ]}
                >
                  <Input
                    value={scheduleData?.name}
                    disabled={true}
                    placeholder={scheduleData?.name}
                  />
                </Form.Item>
              </>
            ) : (
              <>
                <Grid item sm={12} md={5} className={classes.formTextPadding}>
                  <strong>
                    <span className={classes.asterisk}>*</span>{" "}
                    <span className={classes.label}> Meeting Type:</span>
                  </strong>
                </Grid>
                <Form.Item
                  // label="Select Meeting Type: "
                  name="meetingType"
                  // tooltip="This is a required field"
                  rules={[
                    { required: true, message: "Please Select Meeting Type!" },
                  ]}
                >
                  <Select
                    // mode="single"
                    allowClear
                    style={{ width: "100%" }}
                    placeholder="Select Meeting Type"
                    //value={formData?.meetingType}
                    onChange={handleChangeMeetingType}
                    //disabled={showData ? false : true}
                    onBlur={handleKeyAgenda}
                    disabled={
                      readStatus || mrmEditOptions === "Edit" ? true : false
                    }
                  >
                    {meetingTypeData?.length &&
                      meetingTypeData?.map((data: any) => {
                        return (
                          <Option value={data?._id} key={data?._id}>
                            {data?.name}
                          </Option>
                        );
                      })}
                  </Select>
                </Form.Item>
              </>
            )}
          </Col>
          <Col span={10}>
            <Grid item sm={12} md={5} className={classes.formTextPadding}>
              <strong>
                {mrmEditOptions === "MrmPlan" ? (
                  <span className={classes.asterisk}>*</span>
                ) : (
                  ""
                )}
                <span className={classes.label}>Period</span>
              </strong>
            </Grid>
            <Form.Item
              // label="Period"
              name="period"
              // tooltip="This is a required field"
              rules={[{ required: false, message: "Please Select period!" }]}
            >
              <Select
                allowClear
                style={{ width: "100%" }}
                placeholder="Please select period"
                onChange={handleChangePeriod}
                // disabled={showData ? false : true}
                disabled={
                  readStatus || mrmEditOptions === "Edit" ? true : false
                }
              >
                {Array.isArray(allPeriods) &&
                  allPeriods?.length > 0 &&
                  allPeriods?.map((data) => {
                    return (
                      <Option value={data} key={data}>
                        {data}
                      </Option>
                    );
                  })}
              </Select>
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={[16, 16]}>
          <Col span={14}>
            <Grid item sm={12} md={5} className={classes.formTextPadding}>
              <strong>
                <span className={classes.asterisk}>*</span>{" "}
                <span className={classes.label}>Meeting Date:</span>
              </strong>
            </Grid>
            <Form.Item
              // label="Meeting Date: "
              // name="date"
              // tooltip="This is a required field"

              rules={[{ required: true, message: "Please Select Date!" }]}
            >
              <RangePicker
                format="DD-MM-YYYY"
                value={[
                  formData?.startDate ? dayjs(formData?.startDate) : null,
                  formData?.toDate ? dayjs(formData?.toDate) : null, // Static end date
                ]}
                onChange={handleDateRange}
                disabled={readStatus}
              />
            </Form.Item>
          </Col>
          <Col span={10}>
            <Grid item sm={12} md={5} className={classes.formTextPadding}>
              <strong>
                {/* <span className={classes.asterisk}>*</span>{" "} */}
                <span className={classes.label}>Organizer</span>
              </strong>
            </Grid>
            <Form.Item name="organizer">
              <Input
                value={userInfo?.userName || ""}
                disabled={true}
                placeholder={userInfo?.userName || ""}
              />
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={[16, 16]}>
          <Col span={24}>
            <Grid item sm={12} md={5} className={classes.formTextPadding}>
              <strong>
                {/* <span className={classes.asterisk}>*</span>{" "} */}
                <span className={classes.label}>Meeting Description/Notes</span>
              </strong>
            </Grid>
            <Form.Item name="meetingDesc">
              <MyEditor
                readStatus={readStatus}
                formData={formData}
                setFormData={setFormData}
                title="description"
              />
            </Form.Item>
          </Col>
        </Row>

        <Row gutter={[16, 16]}>
          <Col span={12}>
            <Grid item sm={12} md={5} className={classes.formTextPadding}>
              <strong>
                <span className={classes.label}>
                  {!!fileList.length
                    ? "Change Uploaded Files"
                    : "Attach Files: "}
                </span>
              </strong>
            </Grid>
          </Col>
          <Col
            span={12}
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "flex-end",
            }}
          >
            <Tooltip title="Upload files">
              <Button
                className={classes.submitBtn}
                href="#"
                onClick={() => addSelectedFiles(fileList)}
                disabled={readStatus}
              >
                Upload Files
              </Button>
            </Tooltip>
          </Col>
          <Col span={24}>
            <strong>
              <span
                style={{
                  color: "red",
                  fontSize: "10px",
                }}
              >
                {!!fileList.length
                  ? "!!Click on Upload files button to upload"
                  : ""}
              </span>
            </strong>
          </Col>
          <Col span={24}>
            <Form.Item
              // name="fileList"
              help={uploadFileError ? "Please upload a file!" : ""}
              validateStatus={uploadFileError ? "error" : ""}
            >
              <Dragger
                accept=".pdf,.png,.jpeg,.jpg,.docx,.bmp,.tif,.tiff,.webp"
                name="fileList"
                {...uploadFileprops}
                className={classes.uploadSection}
                showUploadList={false}
                fileList={fileList}
                multiple
              >
                <p className="ant-upload-drag-icon">
                  <InboxIcon />
                </p>
                <p className="ant-upload-text">
                  Click or drag files to this area to upload
                </p>
              </Dragger>
            </Form.Item>

            {uploadLoading ? (
              <div>Please wait while documents get uploaded</div>
            ) : (
              fileList &&
              fileList?.length > 0 &&
              fileList?.map((item: any) => (
                <div
                  style={{
                    display: "flex",
                    marginLeft: "10px",
                    alignItems: "center",
                  }}
                  key={item.uid}
                >
                  <Typography className={classes.filename}>
                    <a
                      href={`${API_LINK}${item?.url}`}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      {item?.name}
                    </a>
                  </Typography>

                  <IconButton
                    onClick={() => {
                      // console.log("item click");
                      clearFile(item);
                    }}
                  >
                    <img src={CrossIcon} alt="" />
                  </IconButton>
                </div>
              ))
            )}
          </Col>
        </Row>
      </Form>
    </>
  );
};

export default MeetingAgenda;
