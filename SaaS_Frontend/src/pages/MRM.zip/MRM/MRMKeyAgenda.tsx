import React, { useEffect, useState } from "react";
import axios from "../../apis/axios.global";
//mui
import {
  Box,
  Fab,
  Tooltip,
  Typography,
  Grid,
  FormControl,
  InputLabel,
  MenuItem,
  Paper,
  InputAdornment,
  IconButton,
} from "@material-ui/core";
import { Input, Table, Select, Popconfirm, Pagination } from "antd";
import { Select as SelectMUI } from "@material-ui/core";
import {
  Avatar,
  ListItem,
  ListItemAvatar,
  ListItemText,
  TextField,
} from "@material-ui/core";
import { Edit, Delete, Add, CheckBox } from "@material-ui/icons";
import { useNavigate } from "react-router-dom";
import DeleteIcon from "@material-ui/icons/Delete";
import AddIcon from "@material-ui/icons/Add";
import useStyles from "./MRMKeyAgenda.style";
import { Autocomplete } from "@material-ui/lab";
import getAppUrl from "../../utils/getAppUrl";
import { documentTypeFormData } from "../../recoil/atom";
import { useRecoilState, useRecoilValue } from "recoil";
import { debounce, filter } from "lodash";
import { useSnackbar } from "notistack";
import { ColumnsType } from "antd/es/table";
import { API_LINK } from "../../config";
import checkRoles from "../../utils/checkRoles";
import SearchIcon from "../../assets/SearchIcon.svg";
import CloseIcon from "@material-ui/icons/Close";
import YearComponent from "components/Yearcomponent";
import getYearFormat from "utils/getYearFormat";
import { ReactComponent as CustomDeleteICon } from "../../assets/documentControl/Delete.svg";
import DynamicFormFields from "components/DynamicFormFields";
import ScheduleDrawerAgenda from "./Drawer/ScheduleDrawerAgenda";
import { ReactComponent as CustomEditIcon } from "assets/documentControl/Edit.svg";
import { agendaDefaultData } from "schemas/agenda.schema";
import AddCircleOutlineIcon from "@material-ui/icons/AddCircleOutline";
import CheckCircleOutlineIcon from "@material-ui/icons/CheckCircleOutline";
import { InputBase, Chip } from "@material-ui/core";
import { orgFormData } from "../../recoil/atom";
import {
  createAgenda,
  deleteAgenda,
  getAgendaByMeetingType,
  updateAgenda,
} from "apis/mrmagendapi";
import index from "components/NewAuditForm/index ";
import MrmAgendaCreate from "./Drawer/MrmAgendaCreate";
import ModuleHeader from "components/Navigation/ModuleHeader";
import { ReactComponent as CreateIcon } from "../../assets/MRM/addIcon.svg";
import type { PaginationProps } from "antd";

const { TextArea } = Input;
const { Option } = Select;

var typeAheadValue: string;
var typeAheadType: string;

export interface IKeyAgenda {
  _id: string;
  name: string;
  description: string;
  owner: any;
  applicableSystem: any;
}

const allOption = { id: "All", locationName: "All" };

type Props = {
  setAddKeyAgenda?: any;
  addKeyAgenda?: boolean;
};

const MRMKeyAgenda = ({ setAddKeyAgenda, addKeyAgenda }: Props) => {
  const [dataSource, setDataSource] = useState<any[]>([]);
  const [systemData, setSystemData] = useState<any[]>([]);
  const [suggestions, setSuggestions] = React.useState([]);
  const [formData, setFormData] = useRecoilState(documentTypeFormData);
  const [currentYear, setCurrentYear] = useState<any>();
  const [showModal, setShowModal] = useState(false);
  const [meetingType, setMeetingType] = useState<any>(null);
  const [agenda, setAgenda] = useState<any[]>([]);
  const [locationOptions, setLocationOptions] = useState<any>([]);
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const [rowIndex, setRowIndex] = useState<any>();

  interface DrawerState {
    right: boolean;
  }
  const [state, setState] = React.useState<DrawerState>({
    right: false,
  });
  const realmName = getAppUrl();
  const userDetail = JSON.parse(sessionStorage.getItem("userDetails") || "{}");
  const isOrgAdmin = checkRoles("ORG-ADMIN");
  const isMR = checkRoles("MR");
  // console.log("ismr", isMR);
  const showData = isOrgAdmin || isMR;
  // console.log("showdata", showData);
  const [searchValue, setSearchValue] = useState<string>("");
  const orgData = useRecoilValue(orgFormData);
  const organizationId =
    sessionStorage.getItem("orgId") !== null &&
    sessionStorage.getItem("orgId") !== "null"
      ? sessionStorage.getItem("orgId")
      : (orgData && orgData.organizationId) ||
        (orgData && orgData.id) ||
        undefined;

  // const showHyperLink = !isOrgAdmin && !isMR;
  const { enqueueSnackbar } = useSnackbar();
  const orgId = sessionStorage.getItem("orgId");

  const [openDrawer, setOpenDrawer] = useState(false);
  const [selectedData, setSelectedData] = useState<any[]>([]);
  const [selectedId, setSelectedId] = useState<any>();
  const [buttonStatus, setButtonStatus] = useState(false);
  const [pageType, setPageType] = useState<any>(1);
  const [rowsPerPageType, setRowsPerPageType] = useState(10);
  const [countType, setCountType] = useState<number>(0);
  const [selectedLocation, setSelectedLocation] = useState<any[]>([
    userDetail?.location?.id,
  ]);

  const showTotalType: PaginationProps["showTotal"] = (total) =>
    `Total ${dataSource.length} items`;

  const handlePaginationType = async (page: any, pageSize: any) => {
    const userInfo = await axios.get("/api/user/getUserInfo");
    setPageType(page);
    setRowsPerPageType(pageSize);
    getKeyAgendaValues([userDetail?.location?.id], currentYear);
  };

  useEffect(() => {
    const userInfo = JSON.parse(
      sessionStorage.getItem("userDetails") as string
    );
    getKeyAgendaValues([userInfo?.data?.location], currentYear);
  }, [pageType, rowsPerPageType]);

  useEffect(() => {
    getAllDataMeetingType();
  }, []);

  const getAllDataMeetingType = async () => {
    // try{
    //   const getAllLocationIds = ["All"];
    //   const payloadData = {
    //     orgId: orgId,
    //     locationId: getAllLocationIds,
    //     currentYear: currentYear,
    //     page: pageType,
    //     limit: rowsPerPageType,
    //   };
    //  const res = await axios.get("/api/keyagenda/getkeyAgendaByUnit", {
    //     params: payloadData,
    //   });
    //   setReRender(false);
    // if (res.status === 200 || res.status === 201) {
    //   const data = res.data;
    //   const meetingTypeData: any = [];
    //   data.map((item: any) => {
    //     meetingTypeData.push({
    //       ...item,
    //       Status: true,
    //     });
    //   });
    //   setDataSource(meetingTypeData);
    //   setCountType(meetingTypeData?.length);
    // }
    // }catch(err){
    //  console.log("err", err)
    // }
  };
  const handlerEdit = (data: any) => {
    if (
      isOrgAdmin ||
      (isMR &&
        selectedLocation &&
        Array.isArray(selectedLocation) &&
        selectedLocation.some(
          (location) => location.id === userDetail?.location?.id
        ))
    ) {
      setButtonStatus(true);
      setSelectedId(data?._id);
      const dataUpdate = dataSource?.map((item: any) => ({
        ...item,
        Status: item._id !== data?._id,
      }));
      setDataSource(dataUpdate);
    } else {
      enqueueSnackbar(`Edit Option Is Available!`, {
        variant: "success",
      });
    }
  };
  //console.log("selectedlocation", selectedLocation);
  const handlerOpenMrmPopup = (record: any) => {
    if (
      !(
        isOrgAdmin ||
        (isMR &&
          selectedLocation &&
          Array.isArray(selectedLocation) &&
          selectedLocation.some(
            (location) => location.id === userDetail?.location?.id
          ))
      )
    ) {
      enqueueSnackbar(`You are not authorized to add agenda!`, {
        variant: "error",
      });
      setOpenDrawer(false);
    }

    setSelectedData(record);
    setOpenDrawer(true);
  };
  const handlerCloseMrmPopup = () => {
    setOpenDrawer(false);
  };

  const navigate = useNavigate();
  const classes = useStyles();

  useEffect(() => {
    getyear();
    setReRender(true);
    if (!!selectedLocation) {
      getKeyAgendaValues(
        selectedLocation.length ? selectedLocation : ["All"],
        currentYear
      );
    }
  }, [selectedLocation]);

  const [reRender, setReRender] = useState(false);

  // console.log("buttonStatus", buttonStatus);
  useEffect(() => {
    if (reRender === true && currentYear)
      getKeyAgendaValues(
        selectedLocation?.length ? selectedLocation : ["All"],
        currentYear
      );
  }, [reRender]);

  useEffect(() => {
    const data = ["All"];

    if (!!currentYear) {
      getLocationOptions();
      GetSystems(data);
      getUserInfo();
      getKeyAgendaValues(
        selectedLocation.length ? selectedLocation : ["All"],
        currentYear
      );
    }
  }, [currentYear, meetingType]);

  useEffect(() => {
    if (
      (isOrgAdmin ||
        (isMR &&
          selectedLocation &&
          Array.isArray(selectedLocation) &&
          selectedLocation.some(
            (location) => location.id === userDetail?.location?.id
          ))) &&
      addKeyAgenda
    ) {
      const newData = {
        organizationId: orgId,
        creator: userDetail?.id,
        name: "",
        description: "",
        owner: [],
        applicableSystem: [],
        location: selectedLocation.includes("All") ? [] : [...selectedLocation],
        Status: false,
      };
      setDataSource([newData, ...dataSource]);
      setAddKeyAgenda(false);
    }
  }, [addKeyAgenda]);

  const handleOpenModal = async (data: any) => {
    setShowModal(true);
    setMeetingType(data);
    const res = await axios.get(
      `api/mrm/getAgendaByMeetingType/655b3dfcb3df3176363ca24b`
    );
    setAgenda(res?.data);
  };

  const getyear = async () => {
    const currentyear = await getYearFormat(new Date().getFullYear());
    setCurrentYear(currentyear);
  };

  const DataHeaders = ["Agenda", "Action"];

  const getUserInfo = async () => {
    const userInfo = await axios.get("/api/user/getUserInfo");
    const data = ["All"];
    if (userInfo.status === 200) {
      if (
        userInfo?.data &&
        userInfo?.data?.locationId &&
        userInfo.data.locationId
      ) {
        setSelectedLocation([userInfo.data.location]);
        getKeyAgendaValues([userInfo.data.location], currentYear);
      } else {
        getKeyAgendaValues(data, currentYear);
        setSelectedLocation([allOption]);
      }
    }
  };
  const isUserAuthorized = () => {
    console.log("location", selectedLocation);
    return (
      isOrgAdmin ||
      (isMR &&
        selectedLocation &&
        Array.isArray(selectedLocation) &&
        selectedLocation.some(
          (location) => location.id === userDetail?.location?.id
        ))
    );
  };

  const columns: ColumnsType<IKeyAgenda> = [
    {
      title: "Meeting Type",
      dataIndex: "name",
      // width: '24%',
      width: 220,
      // fixed: 'left',
      render: (_: any, data: any, index: number) => (
        <Input
          placeholder="Meeting Type"
          value={data?.name}
          onChange={(event) =>
            handleChangeKeyagenda(event.target.value, data, index)
          }
          disabled={data?.Status}
          style={{ color: data?.Status ? "#808B96 " : "" }}
        />
      ),
    },
    {
      title: "Description",
      dataIndex: "description",
      width: 240,
      render: (_: any, data: any, index: number) => (
        <TextArea
          autoSize
          placeholder="Add Description"
          onChange={(e) => handleDescription(e.target.value, data, index)}
          // onBlur={() => handleUpdateKeyAgendaChanges(data)}
          value={data?.description}
          disabled={data?.Status}
          style={{ color: data?.Status ? "#808B96 " : "" }}
        />
      ),
    },
    {
      title: "Owners",
      dataIndex: "owner",
      width: 300,
      render: (_: any, data: any, index: number) =>
        suggestions && (
          <Autocomplete
            key={`owner_${index}`}
            multiple={true}
            options={suggestions}
            onChange={(e, value) => {
              handleChangeOwners(value, data, index);
            }}
            // style={{width : '300px'}}
            getOptionLabel={(option: any) => {
              return option["email"];
            }}
            getOptionSelected={(option, value) => option.id === value.id}
            limitTags={2}
            size="small"
            value={data?.owner}
            defaultValue={data?.owner}
            filterSelectedOptions
            disabled={data?.Status}
            style={{ color: data?.Status ? "#808B96 " : "" }}
            renderOption={(option) => {
              return (
                <>
                  <div>
                    <MenuItem key={option.id}>
                      <ListItemAvatar>
                        <Avatar>
                          <Avatar src={`${API_LINK}/${option.avatar}`} />
                        </Avatar>
                      </ListItemAvatar>
                      <ListItemText
                        primary={option.value}
                        secondary={option.email}
                      />
                    </MenuItem>
                  </div>
                </>
              );
            }}
            renderInput={(params) => {
              return (
                <TextField
                  {...params}
                  variant="outlined"
                  label={"Owners"}
                  placeholder={"Owners"}
                  onChange={handleTextChange}
                  size="small"
                  disabled={data?.Status}
                  style={{ color: data?.Status ? "#808B96 " : "" }}
                />
              );
            }}
          />
        ),
    },
    {
      title: "System",
      dataIndex: "applicableSystem",
      width: 300,
      // fixed: 'right',
      render: (_: any, data: any, index: number) => (
        <Select
          mode="multiple"
          allowClear
          style={{ width: "100%", color: data?.Status ? "#808B96 " : "" }}
          placeholder="Please select"
          onChange={(event) => handleChangeSystem(event, data, index)}
          // onBlur={() => handleAdd(data)}
          value={data?.applicableSystem || []}
          disabled={data?.Status}
        >
          {systemData?.length &&
            systemData?.map((data) => {
              return (
                <Option
                  value={data?.id}
                  label={data?.name}
                  key={data?.id}
                  style={{ color: data?.Status ? "#808B96 " : "" }}
                >
                  {data?.name}
                </Option>
              );
            })}
        </Select>
      ),
    },
    {
      title: "Action",
      dataIndex: "keyagenda",
      width: 50,
      // fixed: "right",
      render: (_: any, record: any, index: number) => {
        if (
          !(
            isOrgAdmin ||
            (isMR &&
              selectedLocation &&
              Array.isArray(selectedLocation) &&
              selectedLocation.some(
                (location) => location.id === userDetail?.location?.id
              ))
          )
        ) {
          return null; // Render nothing if showData is false
        }
        setRowIndex(index);
        return (
          <div style={{ display: "flex", gap: "5px" }}>
            {record?._id !== undefined && isUserAuthorized() && (
              <>
                {buttonStatus && record?._id === selectedId ? (
                  <>
                    <CheckBox
                      onClick={() => {
                        isUserAuthorized()
                          ? handleUpdateKeyAgendaChanges(record)
                          : enqueueSnackbar("not authorized to update", {
                              variant: "error",
                            });
                      }}
                      style={{ fontSize: "18px", color: "blue" }}
                    />{" "}
                  </>
                ) : (
                  <>
                    {" "}
                    <CustomEditIcon
                      onClick={() => {
                        handlerEdit(record);
                      }}
                      style={{ height: "18px" }}
                    />
                  </>
                )}

                <Popconfirm
                  placement="top"
                  title={"Are you sure to delete Meeting Type"}
                  onConfirm={() => handleDelete(record, index)}
                  okText="Yes"
                  cancelText="No"
                  disabled={!isUserAuthorized()}
                >
                  <CustomDeleteICon width={18} height={18} />
                </Popconfirm>

                <Tooltip title="Add Agenda" placement="bottom">
                  <AddCircleOutlineIcon
                    onClick={() => {
                      handlerOpenMrmPopup(record);
                    }}
                    style={{
                      color: "#1677ff",
                      fontSize: "20px",
                      cursor: "pointer",
                    }}
                  />
                </Tooltip>
              </>
            )}
          </div>
        );
      },
    },
  ];

  const toggleDrawer =
    (anchor: any, open: any, record: any, index: any) => (event: any) => {
      if (
        event.type === "keydown" &&
        (event.key === "Tab" || event.key === "Shift")
      ) {
        return;
      }
      setMeetingType(record._id);
      setState({ ...state, [anchor]: open });
    };

  const handleTextChange = (e: any) => {
    getSuggestionList(e.target.value, "normal");
  };

  const handleChangeOwners = (data: any, values: any, index: number) => {
    const newData = { ...values };
    newData.owner = [...data];
    const newDataSource = [...dataSource];
    newDataSource[index] = newData;
    setDataSource(newDataSource);
    // if (values?._id) {
    //   handleUpdateKeyAgendaChanges(newData);
    // } else {
    //   if (
    //     newData?.name &&
    //     newData?.owner.length > 0 &&
    //     newData?.applicableSystem.length > 0
    //   ) {
    //     handleAddKeyAgenda(newData);
    //   } else {
    //     if (newData?.owner.length && newData?.name.length) {
    //       enqueueSnackbar(`Please select atleast one owner!`, {
    //         variant: "error",
    //       });
    //     }
    //   }
    // }
  };

  const handleChangeSystem = (data: any, values: any, index: number) => {
    const newData = { ...values };
    newData.applicableSystem = [...data];
    const newDataSource = [...dataSource];
    newDataSource[index] = newData;
    setDataSource(newDataSource);
    // if (newData.applicableSystem.length > 1) {
    //   handleUpdateKeyAgendaChanges(newData);
    // } else {
    //   if (
    //     newData?.name.length &&
    //     newData?.owner.length &&
    //     newData?.applicableSystem.length
    //   ) {
    //     handleAddKeyAgenda(newData);
    //   } else {
    //     if (newData?.owner.length && newData?.name.length) {
    //       enqueueSnackbar(`Please select atleast one system!`, {
    //         variant: "error",
    //       });
    //     }
    //   }
    // }
  };

  const handleDelete = async (record: any, id: number) => {
    try {
      if (record?._id) {
        const res = await axios.delete(`/api/keyagenda/${record?._id}`);
        if (res.status === 200 || res.status === 201) {
          enqueueSnackbar(`Data deleted successfully!`, {
            variant: "success",
          });
        }
      }
      const newSourceData = [...dataSource];

      if (id > -1) {
        // only splice array when item is found
        newSourceData.splice(id, 1); // 2nd parameter means remove one item only
        setDataSource(newSourceData);
      }
    } catch (error: any) {
      //enqueueSnackbar(error.message, { variant: "error" });
    }
  };

  const handleUpdateKeyAgendaChanges = async (data: any) => {
    if (data?.name === "") {
      enqueueSnackbar(`Please add key agenda name!`, {
        variant: "error",
      });
    } else if (data?.owner.length === 0) {
      enqueueSnackbar(`Please add key agenda Owner!`, {
        variant: "error",
      });
    } else if (data?.applicableSystem.length === 0) {
      enqueueSnackbar(`Please add key agenda System!`, {
        variant: "error",
      });
    } else {
      if (selectedId) {
        const payload = {
          name: data?.name,
          description: data?.description,
          owner: data?.owner,
          applicableSystem: data?.applicableSystem,
        };
        if (
          payload.name &&
          payload.owner.length > 0 &&
          payload.applicableSystem.length > 0
        ) {
          const res = await axios.patch(
            `/api/keyagenda/${selectedId}`,
            payload
          );

          if (res.status === 200 || res.status === 201) {
            enqueueSnackbar(`Data Updated successfully!`, {
              variant: "success",
            });
          }
          setReRender(true);
          setButtonStatus(false);
        }
      } else {
        const payload = {
          name: data?.name,
          description: data?.description,
          owner: data?.owner,
          applicableSystem: data?.applicableSystem,
        };
        if (
          payload.name &&
          payload.owner.length > 0 &&
          payload.applicableSystem.length > 0
        ) {
          const res = await axios.patch(`/api/keyagenda/${data?._id}`, payload);
          if (res.status === 200 || res.status === 201) {
            enqueueSnackbar(`Data Updated successfully!`, {
              variant: "success",
            });
          }
          setReRender(true);
          setButtonStatus(false);
        }
      }
    }
  };

  const getKeyAgendaValues = async (data: any, currentYear: any) => {
    try {
      //get api
      let res: any;
      if (data.includes("All") || data.length === 0) {
        const payload = {
          orgId: orgId,
          currentYear: currentYear,
          page: pageType,
          limit: rowsPerPageType,
        };

        res = await axios.get("/api/keyagenda/getkeyAgendaByOrgId", {
          params: payload,
        });
        setReRender(false);
      } else {
        const locationValues = [...data].map((option: any) => option.id);
        const payloadData = {
          orgId: orgId,
          locationId: locationValues,
          currentYear: currentYear,
          page: pageType,
          limit: rowsPerPageType,
        };

        res = await axios.get(
          "/api/keyagenda/getkeyAgendaByUnitWithoutFilter",
          {
            params: payloadData,
          }
        );
        setReRender(false);
      }
      if (res.status === 200 || res.status === 201) {
        const data = res.data;
        const meetingTypeData: any = [];
        data.map((item: any) => {
          meetingTypeData.push({
            ...item,
            Status: true,
          });
        });
        setDataSource(meetingTypeData);
        setCountType(meetingTypeData?.length);
      }
    } catch (error) {
      console.log(error);
      // enqueueSnackbar(`!`, {
      //   variant: "error",
      // });
    }
  };

  const handleChangeKeyagenda = (data: any, values: any, index: number) => {
    const newData = { ...values };
    newData.name = data;
    const newDataSource = [...dataSource];
    newDataSource[index] = newData;
    setDataSource(newDataSource);
    // if (values._id) {
    //   handleUpdateKeyAgendaChanges(newData);
    // } else {
    //   if (
    //     newData?.name &&
    //     newData?.owner.length > 0 &&
    //     newData?.applicableSystem.length > 0
    //   ) {
    //     // handleAddKeyAgenda(newData);
    //   } else {
    //     if (newData?.owner.length && newData?.applicableSystem.length) {
    //       enqueueSnackbar(`Please add key agenda name!`, {
    //         variant: "error",
    //       });
    //     }
    //   }
    // }
  };

  const handleDescription = (data: any, values: any, index: number) => {
    const newData = { ...values };
    newData.description = data;
    const newDataSource = [...dataSource];
    newDataSource[index] = newData;
    setDataSource(newDataSource);
    // if (values?._id) {
    //   handleUpdateKeyAgendaChanges(newData);
    // } else {
    //   if (
    //     newData?.name &&
    //     newData?.owner.length > 0 &&
    //     newData?.applicableSystem.length > 0
    //   ) {
    //     handleAddKeyAgenda(newData);
    //   }
    // }
  };

  const getData = async (value: string, type: string) => {
    try {
      let res = await axios.get(
        `api/user/doctype/filterusers/${realmName}/${"allusers"}?email=${value}`
      );
      setSuggestions(res.data);
    } catch (err) {
      console.log(err);
    }
  };

  const debouncedSearch = debounce(() => {
    getData(typeAheadValue, typeAheadType);
  }, 400);

  const getSuggestionList = (value: any, type: string) => {
    typeAheadValue = value;
    typeAheadType = type;
    debouncedSearch();
  };

  const GetSystems = async (locationId: any) => {
    let encodedSystems: any;
    if (locationId.includes("All") || locationId.length === 0) {
      encodedSystems = encodeURIComponent(JSON.stringify(locationId));
    } else {
      const locationIdValues = [...locationId].map((option: any) => option.id);
      encodedSystems = encodeURIComponent(JSON.stringify(locationIdValues));
    }
    const { data } = await axios.get(
      `api/systems/displaySystems/${encodedSystems}`
    );
    setSystemData([...data]);
  };

  const getLocationOptions = async () => {
    await axios(`/api/location/getLocationsForOrg/${realmName}`)
      .then((res) => {
        setLocationOptions(res.data);
      })
      .catch((err) => console.error(err));
  };

  const handleAdd = async (data?: any) => {
    if (data?._id) {
      handleUpdateKeyAgendaChanges(data);
    } else if (data) {
      if (
        data?.name.length &&
        data?.applicableSystem.length > 0 &&
        data?.owner.length > 0
      ) {
        handleAddKeyAgenda(data);
      }
      //add row
      const newData = {
        organizationId: orgId,
        creator: userDetail?.id,
        name: "",
        description: "",
        owner: [],
        applicableSystem: [],
        location: selectedLocation.includes("All") ? [] : [...selectedLocation],
        Status: false,
      };
      setDataSource([...dataSource, newData]);
    } else {
      const newData = {
        organizationId: orgId,
        creator: userDetail?.id,
        name: "",
        description: "",
        owner: [],
        applicableSystem: [],
        location: [...selectedLocation],
        Status: false,
      };
      setDataSource([...dataSource, newData]);
    }
  };

  const handleLocation = (event: any, values: any) => {
    let getAllLocationIds: any = [];
    if (values.find((option: any) => option.id === "All")) {
      setSelectedLocation([allOption]);
      getAllLocationIds = ["All"];
    } else {
      const allValues = values.filter((option: any) => option.id !== "All");
      setSelectedLocation([...allValues]);
      getAllLocationIds = [...allValues];
    }
    getKeyAgendaValues([...getAllLocationIds], currentYear);
    GetSystems([...getAllLocationIds]);
  };

  const handleAddKeyAgenda = async (payload: any) => {
    if (payload?.name === "") {
      enqueueSnackbar(`Please add key agenda name!`, {
        variant: "error",
      });
    } else if (payload?.owner.length === 0) {
      enqueueSnackbar(`Please add key agenda Owner!`, {
        variant: "error",
      });
    } else if (payload?.applicableSystem.length === 0) {
      enqueueSnackbar(`Please add key agenda System!`, {
        variant: "error",
      });
    } else {
      try {
        const newPayload = { ...payload };
        let locations = newPayload?.location;
        locations = locations.map((item: any) => item.id);
        newPayload.location = locations;
        newPayload.currentYear = currentYear;

        // console.log("newPayload", newPayload);
        const res = await axios.post("/api/keyagenda", newPayload);
        setSelectedId(res.data._id);
        if (res.status === 200 || res.status === 201) {
          enqueueSnackbar(`Meeting Type Added Successfully!`, {
            variant: "success",
          });
        }
        setReRender(true);
      } catch (error) {
        enqueueSnackbar(`!`, {
          variant: "error",
        });
      }
    }
  };

  const handleCheck = async () => {
    let newPayload = {
      search: searchValue,
      orgId: orgId,
    };
    const data = ["All"];
    let res = await axios.get("/api/keyagenda/search", { params: newPayload });
    if (res.status === 200 || res.status === 201) {
      const data = res.data;
      let DataAction: any = [];
      data.map((item: any) => {
        DataAction.push({
          ...item,
          Status: true,
        });
      });
      // console.log("data in search,", DataAction);
      setDataSource(DataAction);
      setCountType(DataAction?.length);
      // setSystemData(data?.applicableSystem)
      GetSystems(data);
      // setSuggestions(DataAction.owner)
    }
  };

  const handleSearchChange = (e: any) => {
    e.preventDefault();
    setSearchValue(e.target.value);
  };

  const handleClickDiscard = () => {
    setSearchValue("");
    getKeyAgendaValues(selectedLocation, currentYear);
  };

  const createHandler = () => {
    setAddKeyAgenda(true);
  };

  return (
    <>
      <div
        style={{
          display: "flex",
          width: "100%",
          justifyContent: "space-between",
        }}
      >
        <div className={classes.topSectionLeft}>
          <>
            <Grid item xs={12} md={2}>
              <Typography color="primary" className={classes.searchBoxText}>
                <strong>Select Units</strong>
              </Typography>
            </Grid>

            <Grid item xs={12} md={6}>
              <div className={classes.locSearchBox}>
                <FormControl variant="outlined" size="small" fullWidth>
                  <div className={classes.locSearchBox}>
                    <Autocomplete
                      multiple
                      id="location-autocomplete"
                      options={[allOption, ...locationOptions]}
                      getOptionLabel={(option) => option?.locationName || ""}
                      getOptionSelected={(option, value) =>
                        option?.id === value?.id
                      }
                      size="small"
                      value={selectedLocation}
                      onChange={handleLocation}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          variant="outlined"
                          size="small"
                          // label="Units"
                          fullWidth
                          InputLabelProps={{ shrink: false }}
                        />
                      )}
                    />
                  </div>
                </FormControl>
              </div>
            </Grid>
            <YearComponent
              currentYear={currentYear}
              setCurrentYear={setCurrentYear}
            />
          </>
        </div>
        <Paper
          style={{
            width: "285px",
            height: "33px",
            float: "right",
            margin: "11px",
            borderRadius: "20px",
            border: "1px solid #dadada",
            overflow: "hidden",
          }}
          component="form"
          data-testid="search-field-container"
          elevation={0}
          variant="outlined"
          className={classes.root}
          onSubmit={(e) => {
            e.preventDefault();
            handleCheck();
          }}
        >
          <TextField
            // className={classes.input}
            name={"search"}
            value={searchValue}
            placeholder={"Search"}
            onChange={handleSearchChange}
            inputProps={{
              "data-testid": "search-field",
            }}
            InputProps={{
              disableUnderline: true,
              startAdornment: (
                <InputAdornment position="start" className={classes.iconButton}>
                  <img src={SearchIcon} alt="search" />
                </InputAdornment>
              ),
              endAdornment: (
                <>
                  {searchValue && (
                    <InputAdornment position="end">
                      <IconButton onClick={handleClickDiscard}>
                        <CloseIcon fontSize="small" />
                      </IconButton>
                    </InputAdornment>
                  )}
                </>
              ),
            }}
          />
        </Paper>
      </div>
      <div className={classes.tableContainer}>
        <Table
          // className={classes.tableContainer}
          className={classes.documentTable}
          rowClassName={() => "editable-row"}
          bordered
          dataSource={dataSource}
          columns={columns}
          pagination={false}
          // scroll={{ x: 700, }}
        />
        <div className={classes.pagination}>
          <Pagination
            size="small"
            current={pageType}
            pageSize={rowsPerPageType}
            total={countType}
            showTotal={showTotalType}
            showSizeChanger
            showQuickJumper
            onChange={(page, pageSize) => {
              handlePaginationType(page, pageSize);
            }}
          />
        </div>
      </div>
      <div>
        <MrmAgendaCreate
          open={openDrawer}
          onClose={handlerCloseMrmPopup}
          meetingType={meetingType}
          selectedData={selectedData}
        />
      </div>
    </>
  );
};

export default MRMKeyAgenda;
